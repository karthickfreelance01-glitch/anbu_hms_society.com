

<?php $__env->startSection('content'); ?>
<div class="main-wrapper">
    <?php echo $__env->make('include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('include.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="page-wrapper">
        <div class="content pb-0">

            <div class="d-flex align-items-sm-center flex-sm-row flex-column gap-2 pb-3">
                <div class="flex-grow-1">
                    <h4 class="fw-bold mb-0">Staff Masters</h4>
                </div>
                <div class="text-end">
                    <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addStaffModal">
                        Add New Staff
                    </button>
                </div>
            </div>

            <div class="row">
                <div class="col-xl-12">
                    <div class="card">
                        <div class="card-header"><h5 class="card-title">Staff Reports</h5></div>
                        <div class="card-body table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>S.NO</th>
                                        <th>Role</th>
                                        <th>Staff Name</th>
                                        <th>Contact No</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $data['staff']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $staff): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($staff->roles_title); ?></td>
                                        <td><?php echo e($staff->staff_name); ?></td>
                                        <td><?php echo e($staff->contact_no); ?></td>
                                        <td class="d-flex gap-2">
                                            <a href="<?php echo e(url('staff/view/' .$staff->id)); ?>"> 
                                                <i class="fa-solid fa-eye text-info"></i> 
                                            </a>
                                            <a href="javascript:void(0)" class="editStaffBtn" data-id="<?php echo e($staff->id); ?>">
                                                <i class="fa-solid fa-pen-to-square text-success"></i>
                                            </a>
                                            <a href="javascript:void(0)" class="deleteStaffBtn" data-url="<?php echo e(url('staff/delete/'.$staff->id)); ?>">
                                                <i class="fa-solid fa-trash text-danger"></i>
                                            </a>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>

<!-- Add Staff Modal -->
<div class="modal fade" id="addStaffModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <form id="addStaffForm" enctype="multipart/form-data"><?php echo csrf_field(); ?>
                <div class="modal-header">
                    <h5 class="modal-title">Add Staff Member</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label>Role</label>
                            <select name="roles_id" class="form-control" required>
                                <option value="">Select Role</option>
                                <?php $__currentLoopData = $data['roles']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($role->id); ?>"><?php echo e($role->roles_title); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label>Staff Name</label>
                            <input type="text" class="form-control" name="staff_name" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label>Contact No</label>
                            <input type="text" class="form-control" name="contact_no" required pattern="[0-9]{10}" maxlength="10">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label>Email</label>
                            <input type="email" class="form-control" name="email" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label>Staff Photo</label>
                            <input type="file" class="form-control" name="staff_photo" accept=".jpg,.jpeg,.png" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label>Staff Proof</label>
                            <input type="file" class="form-control" name="staff_proof" accept=".jpg,.jpeg,.png,.pdf" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label>Joined Date</label>
                            <input type="date" class="form-control" name="joined_date" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label>Salary</label>
                            <input type="number" class="form-control" name="salary" required>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-success">Add Staff</button>
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Edit Staff Modal -->
<div class="modal fade" id="editStaffModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <form id="editStaffForm" enctype="multipart/form-data"><?php echo csrf_field(); ?>
                <input type="hidden" id="edit_staff_id">
                <div class="modal-header">
                    <h5 class="modal-title">Edit Staff Member</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label>Role</label>
                            <select id="edit_roles_id" name="roles_id" class="form-control" required>
                                <option value="">Select Role</option>
                                <?php $__currentLoopData = $data['roles']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($role->id); ?>"><?php echo e($role->roles_title); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label>Staff Name</label>
                            <input type="text" id="edit_staff_name" name="staff_name" class="form-control" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label>Contact No</label>
                            <input type="text" id="edit_contact_no" name="contact_no" class="form-control" pattern="[0-9]{10}" maxlength="10" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label>Email</label>
                            <input type="email" id="edit_email" name="email" class="form-control" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label>Salary</label>
                            <input type="number" id="edit_salary" name="salary" class="form-control" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label>Joined Date</label>
                            <input type="date" id="edit_joined_date" name="joined_date" class="form-control" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label>Current Photo</label><br>
                            <img id="current_staff_photo" src="" width="100">
                            <input type="file" id="edit_staff_photo" name="staff_photo" class="form-control" accept=".jpg,.jpeg,.png">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label>Current Proof</label><br>
                            <a id="current_staff_proof" href="#" target="_blank">View Proof</a>
                            <input type="file" id="edit_staff_proof" name="staff_proof" class="form-control" accept=".jpg,.jpeg,.png,.pdf">
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-primary">Update Staff</button>
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>
$(function(){

    // Add Staff
    $("#addStaffForm").submit(function(e){
        e.preventDefault();
        var form = $(this);
        var btn = form.find("button[type=submit]");
        btn.prop("disabled", true).html('<i class="fa fa-spinner fa-spin me-1"></i> Adding...');
        var formData = new FormData(this);

        $.ajax({
            url: "<?php echo e(url('staff/store')); ?>",
            type: "POST",
            data: formData,
            processData: false,
            contentType: false,
            success: res => {
                Swal.fire('Success!', 'Staff member added successfully.', 'success')
                    .then(() => location.reload());
            },
            error: xhr => {
                let msg = "Something went wrong!";
                if(xhr.responseJSON && xhr.responseJSON.errors){
                    msg = Object.values(xhr.responseJSON.errors).flat().join("<br>");
                }
                Swal.fire('Error!', msg, 'error');
                btn.prop("disabled", false).html('Add Staff');
            }
        });
    });

    // Open Edit Modal
 $(document).on("click", ".editStaffBtn", function(){
        var id = $(this).data("id");
        $.get("<?php echo e(url('staff/edit')); ?>/"+id, function(data){
            $("#edit_staff_id").val(data.id);
            $("#edit_roles_id").val(data.role_id);
            $("#edit_staff_name").val(data.staff_name);
            $("#edit_contact_no").val(data.contact_no);
            $("#edit_email").val(data.email);
            $("#edit_salary").val(data.salary);
            $("#edit_joined_date").val(data.joined_date);

            $("#current_staff_photo").attr("src", data.staff_photo ? "<?php echo e(asset('uploads/staff/photos')); ?>/" + data.staff_photo : "https://via.placeholder.com/100");
            $("#current_staff_proof").attr("href", data.staff_proof ? "<?php echo e(asset('uploads/staff/proofs')); ?>/" + data.staff_proof : "#").text(data.staff_proof ? "View Proof" : "No Proof");

            $("#editStaffModal").modal("show");
        });
    });
    
    // Edit Staff Submit
    $("#editStaffForm").submit(function(e){
        e.preventDefault();
        var form = $(this);
        var btn = form.find("button[type=submit]");
        btn.prop("disabled", true).html('<i class="fa fa-spinner fa-spin me-1"></i> Updating...');

        var id = $("#edit_staff_id").val();
        var formData = new FormData(this);
        formData.append('id', id);

        $.ajax({
            url: "<?php echo e(url('staff/update')); ?>/" + id,
            type: "POST",
            data: formData,
            processData: false,
            contentType: false,
            success: res => {
                Swal.fire('Updated!', 'Staff member updated successfully.', 'success')
                    .then(() => location.reload());
            },
            error: xhr => {
                let msg = "Something went wrong!";
                if(xhr.responseJSON && xhr.responseJSON.errors){
                    msg = Object.values(xhr.responseJSON.errors).flat().join("<br>");
                }
                Swal.fire('Error!', msg, 'error');
                btn.prop("disabled", false).html('Update Staff');
            }
        });
    });

    // Delete Staff
    $(document).on("click", ".deleteStaffBtn", function(){
        var url = $(this).data("url");
        Swal.fire({
            title: "Confirm Delete",
            text: "This action is irreversible.",
            icon: "warning",
            showCancelButton: true,
            confirmButtonText: "Delete"
        }).then(res => {
            if(res.isConfirmed) window.location.href = url;
        });
    });

});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/furniica/public_html/deaddtiction/resources/views/masters/staff.blade.php ENDPATH**/ ?>