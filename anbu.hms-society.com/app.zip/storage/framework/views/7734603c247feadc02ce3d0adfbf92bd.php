<?php use Carbon\Carbon; ?>


<?php $__env->startSection('content'); ?>
<div class="main-wrapper">
    <?php echo $__env->make('include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('include.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="page-wrapper">
        <div class="content pb-0">
            <form method="POST" action="<?php echo e(route('patient.discharge.confirm')); ?>">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="patient_id" value="<?php echo e($patient->id); ?>">
                <input type="hidden" id="final_amount_input" value="<?php echo e($totalPending); ?>">

                <div class="card shadow-lg border-0 p-5 mt-4 mb-5 rounded-4">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <div>
                            <h2 class="fw-bold text-primary mb-1">PATIENT DISCHARGE BILL</h2>
                            <p class="text-muted">Final Billing & Discharge Summary</p>
                        </div>
                        <div>
                            <a href="<?php echo e(route('patient.discharge.pdf', $patient->id)); ?>" 
                               target="_blank" 
                               class="btn btn-outline-danger">
                                <i class="fas fa-file-pdf me-2"></i>Download PDF
                            </a>
                        </div>
                    </div>
                    <hr>

                    <!-- Patient Info -->
                    <div class="row mb-4">
                        <div class="col-md-6">
                            <table class="table table-borderless">
                                <tr><th>Patient Name:</th><td><?php echo e($patient->name); ?></td></tr>
                                <tr><th>IP Number:</th><td><?php echo e($patient->ip_number); ?></td></tr>
                                <tr><th>Gender:</th><td><?php echo e($patient->gender); ?></td></tr>
                                <tr><th>Contact No:</th><td><?php echo e($patient->contact_number); ?></td></tr>
                            </table>
                        </div>

                        <div class="col-md-6">
                            <table class="table table-borderless">
                                <tr>
                                    <th>Admission Date:</th>
                                    <td id="admission_date" data-iso="<?php echo e($admissionDate->format('Y-m-d')); ?>">
                                        <?php echo e($admissionDate->format('d-m-Y')); ?>

                                    </td>
                                </tr>
                                <tr>
                                    <th>Discharge Date:</th>
                                    <td>
                                        <input type="date" name="discharge_date" id="discharge_date"
                                               class="form-control"
                                               value="<?php echo e($dischargeDate->format('Y-m-d')); ?>" required>
                                    </td>
                                </tr>
                                <tr>
                                    <th>Months Stayed:</th>
                                    <td><span id="months_stayed"><?php echo e($monthsStayed ?? 0); ?></span> month(s)</td>
                                </tr>
                                <tr>
                                    <th>Extra Days:</th>
                                    <td><span id="extra_days"><?php echo e($totalExtraDays ?? 0); ?></span> day(s)</td>
                                </tr>
                            </table>
                        </div>
                    </div>

                    <hr>

                    <!-- Billing Table -->
                    <div class="mt-4">
                        <h5 class="fw-bold text-primary mb-3">CATEGORY-WISE BILL DETAILS</h5>
                        <div class="table-responsive">
                            <table class="table table-bordered align-middle" id="billing_table">
                                <thead class="table-primary">
                                    <tr>
                                        <th>Category</th>
                                        <th class="text-end">Total (₹)</th>
                                        <th class="text-end">Received (₹)</th>
                                        <th class="text-end">Pending (₹)</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $allBillings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e(ucfirst($bill->category)); ?></td>
                                        <td class="text-end total_amount">₹ <?php echo e(number_format($bill->total_amount, 2)); ?></td>
                                        <td class="text-end">₹ <?php echo e(number_format($bill->total_received, 2)); ?></td>
                                        <td class="text-end text-danger fw-semibold pending_amount">₹ <?php echo e(number_format($bill->total_pending, 2)); ?></td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>

                    <div class="row mt-4">
                        <div class="col-md-6"></div>
                        <div class="col-md-6">
                            <table class="table table-bordered">
                                <tr>
                                    <th>Total Amount</th>
                                    <td class="text-end">₹<span id="total_amount"><?php echo e(number_format($totalAmount, 2)); ?></span></td>
                                </tr>
                                <tr>
                                    <th>Total Received</th>
                                    <td class="text-end">₹<span id="total_received"><?php echo e(number_format($totalReceived, 2)); ?></span></td>
                                </tr>
                                <tr>
                                    <th>Total Pending</th>
                                    <td class="text-end text-danger fw-bold">₹<span id="pending_amount"><?php echo e(number_format($totalPending, 2)); ?></span></td>
                                </tr>
                                <tr class="table-success">
                                    <th>Final Amount to Pay</th>
                                    <td>
                                        <input type="number" id="final_amount_box" class="form-control text-end fw-bold fs-5"
                                               value="<?php echo e(number_format($totalPending, 2, '.', '')); ?>" 
                                               name="final_amount" min="0" step="0.01">
                                    </td>
                                </tr>
                                <tr>
                                    <th>Discount (₹)</th>
                                    <td>
                                        <input type="number" name="discount" id="discount" class="form-control text-end" value="0" min="0" step="0.01">
                                    </td>
                                </tr>
                                <tr class="table-success align-middle">
                                    <th class="fw-bold">Payment Mode</th>
                                    <td>
                                        <select name="payment_mode" id="payment_mode" class="form-select fw-bold fs-5" required>
                                            <option value="" disabled selected>-- Select Payment Mode --</option>
                                            <option value="Cash">Cash</option>
                                            <option value="Card">Card</option>
                                            <option value="UPI">UPI</option>
                                            <option value="Bank Transfer">Bank Transfer</option>
                                            <option value="Cheque">Cheque</option>
                                            <option value="Other">Other</option>
                                        </select>
                                    </td>
                                </tr>
                            </table>
                        </div>
                    </div>

                    <div class="mt-4">
                        <label for="discharge_advice" class="form-label fw-bold text-primary">Discharge Advice / Notes</label>
                        <textarea name="discharge_advice" id="discharge_advice" rows="4" class="form-control shadow-sm"
                                  placeholder="Enter doctor's discharge advice..."></textarea>
                    </div>

                    <div class="text-center mt-5">
                        <button type="submit" class="btn btn-success btn-lg px-5" id="confirmDischargeBtn">
                            <i class="fas fa-check-circle me-2"></i> Confirm Discharge
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Scripts -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>
document.addEventListener('DOMContentLoaded', function () {
    const monthlyAmount = parseFloat(<?php echo e($monthlyAmount ?? 0); ?>) || 0;
    const perDayAmount = parseFloat(<?php echo e($perDayAmount ?? 0); ?>) || 0;
    const receivedAmount = parseFloat(<?php echo e($receivedAmount ?? 0); ?>) || 0;

    const admissionIso = document.getElementById('admission_date').dataset.iso;
    const dischargeInput = document.getElementById('discharge_date');
    const monthsEl = document.getElementById('months_stayed');
    const daysEl = document.getElementById('extra_days');
    const totalAmountEl = document.getElementById('total_amount');
    const pendingEl = document.getElementById('pending_amount');
    const discountInput = document.getElementById('discount');
    const finalBox = document.getElementById('final_amount_box');
    const finalHidden = document.getElementById('final_amount_input');
    const firstRow = document.querySelector('#billing_table tbody tr:first-child');

    let totalPending = parseFloat(<?php echo e($totalPending ?? 0); ?>) || 0;

    // ✅ Recalculate stay (no 31-day logic)
    function calculateStay(admDate, disDate) {
        const adm = new Date(admDate);
        const dis = new Date(disDate);
        if (dis < adm) return { months: 0, extraDays: 0 };

        let months = 0;
        let temp = new Date(adm);
        while (true) {
            const next = new Date(temp);
            next.setMonth(next.getMonth() + 1);
            if (next <= dis) {
                months++;
                temp = next;
            } else break;
        }
        const msPerDay = 1000 * 60 * 60 * 24;
        const extraDays = Math.floor((dis - temp) / msPerDay);
        return { months, extraDays };
    }

    function recalcStay() {
        const { months, extraDays } = calculateStay(admissionIso, dischargeInput.value);
        monthsEl.innerText = months;
        daysEl.innerText = extraDays;

        const stayAmount = (months * monthlyAmount) + (extraDays * perDayAmount);
        const stayPending = Math.max(stayAmount - receivedAmount, 0);

        if (firstRow) {
            firstRow.querySelector('.total_amount').textContent = '₹ ' + stayAmount.toFixed(2);
            firstRow.querySelector('.pending_amount').textContent = '₹ ' + stayPending.toFixed(2);
        }

        let totalAmt = 0, pendingAmt = 0;
        document.querySelectorAll('#billing_table tbody tr').forEach(row => {
            totalAmt += parseFloat(row.querySelector('.total_amount')?.textContent.replace(/[^\d.]/g, '')) || 0;
            pendingAmt += parseFloat(row.querySelector('.pending_amount')?.textContent.replace(/[^\d.]/g, '')) || 0;
        });

        totalAmountEl.textContent = totalAmt.toFixed(2);
        pendingEl.textContent = pendingAmt.toFixed(2);
        totalPending = pendingAmt;
        updateFinalAmount();
    }

    function updateFinalAmount() {
        const discount = parseFloat(discountInput.value) || 0;
        let final = totalPending - discount;
        if (final < 0) final = 0;
        finalBox.value = final.toFixed(2);
        if (finalHidden) finalHidden.value = final.toFixed(2);
    }

    dischargeInput.addEventListener('change', recalcStay);
    discountInput.addEventListener('input', updateFinalAmount);
    recalcStay();
});
</script>

<script src="https://cdn.ckeditor.com/ckeditor5/41.4.2/classic/ckeditor.js"></script>
<script>
ClassicEditor.create(document.querySelector('#discharge_advice')).catch(e => console.error(e));
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/hmssocie/public_html/aaracare.hms-society.com/resources/views/patient/discharge.blade.php ENDPATH**/ ?>