

<?php $__env->startSection('content'); ?>
<div class="main-wrapper">
    <?php echo $__env->make('include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('include.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="page-wrapper">
        <div class="content pb-0">
            <!-- Page Header -->
            <div class="d-flex align-items-center justify-content-between flex-wrap gap-2 mb-3">
                <h4 class="fw-bold mb-0">Expense Subcategory Master</h4>
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="<?php echo e(url('dashboard')); ?>">Dashboard</a></li>
                    <li class="breadcrumb-item"><a href="#">Masters</a></li>
                    <li class="breadcrumb-item active">Expense Subcategory Master</li>
                </ol>
            </div>

            <!-- Card -->
            <div class="card shadow-sm border-0 rounded-4">
                <div class="card-header d-flex justify-content-between align-items-center bg-white border-bottom-0">
                    <h5 class="mb-0">Expense Subcategory List</h5>
                    <button class="btn btn-primary btn-sm rounded-pill shadow-sm" data-bs-toggle="modal" data-bs-target="#addExpenseModal">
                        <i class="fa-solid fa-plus me-1"></i> Add Expense
                    </button>
                </div>
                <div class="card-body ">
                    <table class="table table-hover mb-0" id="expenseTable">
                        <thead class="table-light">
                            <tr>
                                <th>#</th>
                                <th>Main Category</th>
                                <th>Subcategory Name</th>
                                <th class="text-center">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $expenses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $exp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="align-middle">
                                <td><?php echo e($index + 1); ?></td>
                                <td><?php echo e($exp->expensescategory); ?></td>
                                <td><?php echo e($exp->expense_name); ?></td>
                                <td class="text-center">
                                    <button class="btn btn-sm btn-success rounded-circle editExpenseBtn me-1" data-id="<?php echo e($exp->id); ?>" title="Edit">
                                        <i class="fa-solid fa-pen-to-square"></i>
                                    </button>
                                    <button class="btn btn-sm btn-danger rounded-circle deleteExpenseBtn" data-url="<?php echo e(url('expenses_delete/'.$exp->id)); ?>" title="Delete">
                                        <i class="fa-solid fa-trash"></i>
                                    </button>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>

        </div>
    </div>
</div>

<!-- Add Expense Modal -->
<div class="modal fade" id="addExpenseModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content rounded-4 shadow-sm">
            <form id="addExpenseForm">
                <?php echo csrf_field(); ?>
                <div class="modal-header border-0">
                    <h5 class="modal-title">Add Expense Subcategory</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label>Expense Maincategory</label>
                        <select name="expense_category" class="form-control form-select shadow-sm" required>
                            <option value="">Select Main Category</option>
                            <?php $__currentLoopData = $expensescat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($cat->id); ?>"><?php echo e($cat->expensescategory); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label>Expense Subcategory</label>
                        <input type="text" name="expense_name" class="form-control shadow-sm" placeholder="Enter Subcategory Name" required>
                    </div>
                </div>
                <div class="modal-footer border-0">
                    <button type="submit" class="btn btn-success rounded-pill" id="addBtn">Add</button>
                    <button type="button" class="btn btn-secondary rounded-pill" data-bs-dismiss="modal">Cancel</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Edit Expense Modal -->
<div class="modal fade" id="editExpenseModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content rounded-4 shadow-sm">
            <form id="editExpenseForm">
                <?php echo csrf_field(); ?>
                <input type="hidden" id="edit_expense_id">
                <div class="modal-header border-0">
                    <h5 class="modal-title">Edit Expense Subcategory</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label>Expense Maincategory</label>
                        <select id="edit_expense_category" name="expense_category" class="form-control form-select shadow-sm" required>
                            <option value="">Select Main Category</option>
                            <?php $__currentLoopData = $expensescat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($cat->id); ?>"><?php echo e($cat->expensescategory); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label>Expense Subcategory</label>
                        <input type="text" id="edit_expense_name" name="expense_name" class="form-control shadow-sm" placeholder="Enter Subcategory Name" required>
                    </div>
                </div>
                <div class="modal-footer border-0">
                    <button type="submit" class="btn btn-primary rounded-pill" id="updateBtn">Update</button>
                    <button type="button" class="btn btn-secondary rounded-pill" data-bs-dismiss="modal">Cancel</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Scripts -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.1/js/dataTables.buttons.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.1/js/buttons.html5.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.1/js/buttons.print.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.2.7/pdfmake.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.2.7/vfs_fonts.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js"></script>

<script>
$(document).ready(function(){
    $('#expenseTable').DataTable({
        dom: '<"d-flex justify-content-between mb-3"<"search-box"f><"dt-buttons"B>>rtip',
        buttons: ['copy','csv','excel','pdf','print'],
        pageLength: 10
    });

    // Add Expense
    $("#addExpenseForm").submit(function(e){
        e.preventDefault();
        var $btn = $("#addBtn").prop('disabled', true).html('<i class="fa-solid fa-spinner fa-spin me-1"></i> Adding...');
        $.post("<?php echo e(route('addexpenses')); ?>", $(this).serialize(), function(){
            Swal.fire("Added!", "Expense Subcategory added successfully.", "success").then(()=>location.reload());
        }).fail(function(xhr){
            Swal.fire("Error!", xhr.responseText, "error");
            $btn.prop('disabled', false).html('Add');
        });
    });

    // Edit Expense
    $(document).on('click', '.editExpenseBtn', function(){
        var id = $(this).data('id');
        $.get("<?php echo e(url('expenses_edit')); ?>/" + id, function(data){
            $('#edit_expense_id').val(data.id);
            $('#edit_expense_category').val(data.expense_category);
            $('#edit_expense_name').val(data.expense_name);
            new bootstrap.Modal('#editExpenseModal').show();
        });
    });

    // Update Expense
    // Update Expense
$('#editExpenseForm').submit(function(e){
    e.preventDefault();
    var id = $('#edit_expense_id').val();
    var $btn = $("#updateBtn").prop('disabled', true).html('<i class="fa-solid fa-spinner fa-spin me-1"></i> Updating...');

    $.ajax({
        url: "<?php echo e(url('expenses_update')); ?>/" + id,
        method: "POST",
        data: {
            _token: '<?php echo e(csrf_token()); ?>',
            expense_category: $('#edit_expense_category').val(),
            expense_name: $('#edit_expense_name').val()
        },
        success: function(){
            Swal.fire("Updated!", "Expense Subcategory updated successfully.", "success")
                .then(()=>location.reload());
        },
        error: function(xhr){
            // Show server error message
            let msg = "Something went wrong while updating.";
            if(xhr.responseJSON && xhr.responseJSON.errors){
                // Laravel validation errors
                msg = Object.values(xhr.responseJSON.errors).flat().join('<br>');
            } else if(xhr.responseJSON && xhr.responseJSON.message){
                msg = xhr.responseJSON.message;
            } else {
                msg = xhr.responseText;
            }
            Swal.fire("Error!", msg, "error");
            $btn.prop('disabled', false).html('Update');
        }
    });
});


    // Delete Expense
    $(document).on('click', '.deleteExpenseBtn', function(){
        var url = $(this).data('url');
        Swal.fire({
            title: 'Are you sure?',
            text: 'This expense Subcategory will be deleted!',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Yes, delete it!',
            customClass: { confirmButton: 'btn btn-danger rounded-pill', cancelButton: 'btn btn-secondary rounded-pill' },
            buttonsStyling: false
        }).then((result)=>{
            if(result.isConfirmed){
                window.location.href = url;
            }
        });
    });

});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\deaddtiction\resources\views/masters/expense.blade.php ENDPATH**/ ?>