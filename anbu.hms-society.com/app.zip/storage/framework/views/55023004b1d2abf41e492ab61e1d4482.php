
<?php $__env->startSection('content'); ?>
<div class="main-wrapper">
    <?php echo $__env->make('include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('include.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="page-wrapper">
        <div class="content pb-0">
            <div class="card shadow-sm">
                <div class="card-header  text-white">
                    <h4 class="mb-0">Death Register</h4>
                </div>
                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('death_register.store')); ?>" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="row g-3">

                            <!-- Patient Selection -->
                            <div class="col-md-6">
                                <label class="form-label">Patient</label>
                                <select name="patient_id" id="patient_id" class="form-control" required>
                                    <option value="">Select Patient</option>
                                    <?php $__currentLoopData = $patients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $patient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($patient->id); ?>" 
                                                data-name="<?php echo e($patient->name); ?>" 
                                                data-phone="<?php echo e($patient->contact_number); ?>">
                                            <?php echo e($patient->id); ?> - <?php echo e($patient->contact_number); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <!-- Patient Name -->
                            <div class="col-md-6">
                                <label class="form-label">Patient Name</label>
                                <input type="text" id="patient_name" class="form-control" readonly style="background:#f5f5f5">
                            </div>

                           

                            <!-- Death Date & Time -->
                            <div class="col-md-6 mb-3">
                                    <label class="form-label">Death Date & Time</label>
                                    <div class="input-group">
                                        <input type="date" name="death_date" class="form-control" required
                                            value="<?php echo e(date('Y-m-d')); ?>">
                                        <input type="text" name="death_time" class="form-control" placeholder="hh:mm AM/PM" required
                                            value="<?php echo e(date('h:i A')); ?>">
                                    </div>
                                </div>


                            <!-- Report Attachment -->
                            <div class="col-md-6">
                                <label class="form-label">Report Attachment</label>
                                <input type="file" name="report_attachment" class="form-control">
                            </div>

                            <!-- Note -->
                            <div class="col-md-12">
                                <label class="form-label">Note</label>
                                <textarea name="note" class="form-control" rows="3"></textarea>
                            </div>

                        </div>

                        <!-- Submit Button -->
                        <div class="mt-4 text-end">
                            <button type="submit" class="btn btn-success px-4">Save</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Scripts -->
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>
$(document).ready(function(){

    // Initialize Select2
    $('#patient_id').select2({
        placeholder: 'Select Patient',
        allowClear: true
    });

    // Auto-fill patient name
    $('#patient_id').on('change', function(){
        var selected = $(this).find(':selected');
        $('#patient_name').val(selected.data('name') || '');
    });

    // Populate hours (01-12)
    for(let i=1; i<=12; i++){
        $('#hour').append(`<option value="${i<10?'0'+i:i}">${i<10?'0'+i:i}</option>`);
    }

    // Populate minutes (00-59)
    for(let i=0; i<60; i++){
        $('#minute').append(`<option value="${i<10?'0'+i:i}">${i<10?'0'+i:i}</option>`);
    }

    // Convert 12-hour to 24-hour format
    function to24Hour(hour, ampm){
        hour = parseInt(hour);
        if(ampm === 'AM'){
            if(hour === 12) hour = 0;
        } else {
            if(hour !== 12) hour += 12;
        }
        return hour < 10 ? '0'+hour : hour;
    }

    // Update hidden datetime
    function updateDatetime(){
        const dateVal = $('#date').val();
        const hourVal = $('#hour').val();
        const minuteVal = $('#minute').val();
        const ampmVal = $('#ampm').val();

        if(dateVal && hourVal && minuteVal && ampmVal){
            const hour24 = to24Hour(hourVal, ampmVal);
            const datetime = `${dateVal}T${hour24}:${minuteVal}`;
            $('#admissionDatetime').val(datetime);
            $('#date-output').text(dateVal);
            $('#time-output').text(`${hourVal}:${minuteVal} ${ampmVal}`);
        }
    }

    $('#date, #hour, #minute, #ampm').on('change', updateDatetime);
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/furniica/public_html/deaddtiction/resources/views/death_register/create.blade.php ENDPATH**/ ?>