
<?php $__env->startSection('content'); ?>

<div class="main-wrapper">
<?php echo $__env->make('include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('include.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="page-wrapper">
    <div class="content pb-0">
        <div class="container-fluid">

            <!-- Header -->
            <div class="d-flex justify-content-between mb-3">
                <h4>Staff Attendance Report</h4>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(url('dashboard')); ?>">Dashboard</a></li>
                    <li class="breadcrumb-item active">Attendance Report</li>
                </ol>
            </div>

            <!-- Filter: Staff + Date Range -->
            <form method="GET" class="g-3 mb-3">
                <div class="card">
                    <div class="card-body row">
                        
                        <div class="col-md-2">
                            <input type="date" name="from_date" class="form-control" value="<?php echo e($from ?? ''); ?>">
                        </div>
                        <div class="col-md-2">
                            <input type="date" name="to_date" class="form-control" value="<?php echo e($to ?? ''); ?>">
                        </div>
                        <div class="col-md-3">
                            <select name="staff_id" class="form-select">
                                <option value="">-- All Staff --</option>
                                <?php $__currentLoopData = $allStaff; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $st): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($st->id); ?>" <?php echo e(request('staff_id')==$st->id ? 'selected' : ''); ?>>
                                        <?php echo e($st->staff_name); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="col-md-3 d-flex gap-2">
                            <button type="submit" class="btn btn-primary flex-grow-1">Filter</button>
                            <a href="<?php echo e(url('attendance/date-report')); ?>" class="btn btn-secondary flex-grow-1">Reset</a>
                        </div>
                    </div>
                </div>
            </form>

            <!-- Show message if no filter applied -->
            <?php if($staff->isEmpty()): ?>
                <div class="alert alert-info">Please select a staff or date range to view attendance.</div>
            <?php else: ?>
                <!-- Table Card -->
                <div class="card shadow-lg">
                    <div class="card-body table-responsive">
                        <table id="attendanceTable" class="table table-bordered table-striped text-center">
                            <thead class="table-light">
                                <tr>
                                    <th>Staff Name</th>
                                    <th>Total Days</th>
                                    <?php $__currentLoopData = $dates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <th><?php echo e(\Carbon\Carbon::parse($date)->format('d-m')); ?></th>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $staff; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $st): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $totalPresent = 0;
                                        $totalAbsent = 0;
                                        $totalLeave = 0;
                                        $totalHalfDay = 0;

                                        foreach($dates as $date){
                                            $status = $attendanceRecords[$st->id][$date]->status ?? '';
                                            if($status == 'Present') $totalPresent++;
                                            elseif($status == 'Absent') $totalAbsent++;
                                            elseif($status == 'Leave') $totalLeave++;
                                            elseif($status == 'Half Day') $totalHalfDay++;
                                        }
                                    ?>
                                    <tr>
                                        <td><?php echo e($st->staff_name); ?></td>
                                        <td>
                                            <span class="badge bg-success">P-<?php echo e($totalPresent); ?></span>
                                            <span class="badge bg-danger">A-<?php echo e($totalAbsent); ?></span>
                                            <span class="badge bg-warning text-dark">L-<?php echo e($totalLeave); ?></span>
                                            <span class="badge bg-primary">HD-<?php echo e($totalHalfDay); ?></span>
                                        </td>

                                        <?php $__currentLoopData = $dates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php
                                                $status = $attendanceRecords[$st->id][$date]->status ?? '';
                                                $badgeClass = match($status){
                                                    'Present' => 'badge bg-success',
                                                    'Absent' => 'badge bg-danger',
                                                    'Leave' => 'badge bg-warning text-dark',
                                                    'Half Day' => 'badge bg-primary',
                                                    default => ''
                                                };
                                            ?>
                                            <td>
                                                <?php if($status): ?>
                                                    <span class="<?php echo e($badgeClass); ?>"><?php echo e($status); ?></span>
                                                <?php endif; ?>
                                            </td>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            <?php endif; ?>

        </div>
    </div>
</div>
</div>

<!-- jQuery & DataTables -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<link rel="stylesheet" href="https://cdn.datatables.net/1.13.7/css/dataTables.bootstrap5.min.css">
<script src="https://cdn.datatables.net/1.13.7/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.7/js/dataTables.bootstrap5.min.js"></script>

<!-- DataTables Buttons -->
<link rel="stylesheet" href="https://cdn.datatables.net/buttons/2.4.1/css/buttons.bootstrap5.min.css">
<script src="https://cdn.datatables.net/buttons/2.4.1/js/dataTables.buttons.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.1/js/buttons.bootstrap5.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.1/js/buttons.html5.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.1/js/buttons.print.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.2.7/pdfmake.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.2.7/vfs_fonts.js"></script>

<script>
$(document).ready(function() {
    $('#attendanceTable').DataTable({
        pageLength: 10,
        lengthMenu: [5, 10, 25, 50, 100],
        order: [],
        dom: "<'row mb-3'<'col-sm-6'f><'col-sm-6 text-end'B>>" +
             "<'row'<'col-sm-12'tr>>" +
             "<'row mt-3'<'col-sm-5'i><'col-sm-7'p>>",
        buttons: [
            { extend: 'copy', className: 'btn btn-sm btn-primary' },
            { extend: 'csv', className: 'btn btn-sm btn-success' },
            { extend: 'excel', className: 'btn btn-sm btn-info' },
            { extend: 'pdf', className: 'btn btn-sm btn-danger' },
            { extend: 'print', className: 'btn btn-sm btn-warning' }
        ],
        responsive: true
    });
});
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/hmssocie/public_html/aaracare.hms-society.com/resources/views/attendance/date_report.blade.php ENDPATH**/ ?>