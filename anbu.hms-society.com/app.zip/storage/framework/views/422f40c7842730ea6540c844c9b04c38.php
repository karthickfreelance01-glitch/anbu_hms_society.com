<div class="sidebar" id="sidebar">

    <!-- Sidebar Logo -->
    <div class="sidebar-logo d-flex align-items-center justify-content-between">
        <a href="<?php echo e(url('dashboard')); ?>" class="d-flex align-items-center text-decoration-none">
            <img src="<?php echo e(asset('assets/img/logo.jpeg')); ?>" alt="Logo" height="55" class="me-2">
            
        </a>
        <button class="sidenav-toggle-btn btn border-0 p-0" id="toggle_btn">
            <i class="fa-solid fa-bars text-body"></i>
        </button>
        <button class="sidebar-close">
            <i class="fa-solid fa-xmark align-middle"></i>
        </button>
    </div>

    <!-- Sidebar Menu -->
    <div class="sidebar-inner" data-simplebar>
        <div id="sidebar-menu" class="sidebar-menu">
            <ul>

                <!-- Main Menu -->
                <li class="menu-title"><span>Main Menu</span></li>
                <li>
                    <a href="<?php echo e(url('dashboard')); ?>">
                        <i class="fa-solid fa-gauge-high"></i><span> Dashboard</span>
                    </a>
                </li>

                <!-- Masters -->
                <li class="submenu">
                    <a href="javascript:void(0);">
                        <i class="fa-solid fa-database"></i><span> Masters </span>
                        <span class="menu-arrow"><i class="fa-solid fa-angle-down"></i></span>
                    </a>
                    <ul>
                        <li><a href="<?php echo e(url('expenses/view')); ?>"><i class="fa-solid fa-money-bill-wave"></i> Expense</a></li>
                        <li><a href="<?php echo e(url('staff/view')); ?>"><i class="fa-solid fa-users"></i> Staff</a></li>
                        <li><a href="<?php echo e(url('medicine')); ?>"><i class="fa-solid fa-pills"></i> Medicine</a></li>
                    </ul>
                </li>

                <!-- Patient Registration -->
                <li class="menu-title"><span>Patient Registration</span></li>
                <li class="submenu">
                    <a href="javascript:void(0);">
                        <i class="fa-solid fa-hospital-user"></i><span> Patient Registration</span>
                        <span class="menu-arrow"><i class="fa-solid fa-angle-down"></i></span>
                    </a>
                    <ul>
                        <li><a href="<?php echo e(url('patients/create')); ?>"><i class="fa-solid fa-user-plus"></i> Create Patient</a></li>
                        <li><a href="<?php echo e(url('patients')); ?>"><i class="fa-solid fa-eye"></i> View Patients</a></li>
                        <li><a href="<?php echo e(url('patients/discharge/index')); ?>"><i class="fa-solid fa-bed-pulse"></i> Discharged Patients</a></li>
                    </ul>
                </li>

                <!-- Patient Billing -->
                <li class="submenu">
                    <a href="javascript:void(0);">
                        <i class="fa-solid fa-file-invoice-dollar"></i><span> Patient Bill</span>
                        <span class="menu-arrow"><i class="fa-solid fa-angle-down"></i></span>
                    </a>
                    <ul>
                        <li><a href="<?php echo e(url('patient/billing')); ?>"><i class="fa-solid fa-plus"></i> Create Bill</a></li>
                        <li><a href="<?php echo e(url('patient/billing/reports')); ?>"><i class="fa-solid fa-clipboard-list"></i> View Bills</a></li>
                    </ul>
                </li>
                <li>
                    <a href="<?php echo e(url('patient_bills_report')); ?>">
                        <i class="fa-solid fa-calendar-days"></i><span> Patient Monthly Bill</span>
                    </a>
                </li>
                <!-- Doctor Notes -->
                <li>
                    <a href="<?php echo e(url('doctor-notes')); ?>">
                        <i class="fa-solid fa-notes-medical"></i><span> Doctor Notes</span>
                    </a>
                </li>

                <!-- Discharge -->
                <!-- <li>
                    <a href="<?php echo e(url('patients/discharge/index')); ?>">
                        <i class="fa-solid fa-person-walking-arrow-right"></i><span> Discharge</span>
                    </a>
                </li> -->
                <li class="submenu">
                    <a href="javascript:void(0);">
                         <i class="fa-solid fa-person-walking-arrow-right"></i><span> Discharge</span>
                        <span class="menu-arrow"><i class="fa-solid fa-angle-down"></i></span>
                    </a>
                    <ul>
                        <li><a href="<?php echo e(url('discharge')); ?>"><i class="fa-solid fa-plus"></i> Create Discharge</a></li>
                        <li><a href="<?php echo e(url('patients/discharge/index')); ?>"><i class="fa-solid fa-clipboard-list"></i> View Discharge</a></li>
                    </ul>
                </li>

                <!-- Patient Reports -->
                <li class="submenu">
                    <a href="javascript:void(0);">
                        <i class="fa-solid fa-file-medical"></i><span>Patient Doc Reports</span>
                        <span class="menu-arrow"><i class="fa-solid fa-angle-down"></i></span>
                    </a>
                    <ul>
                        <li><a href="<?php echo e(url('reports/create')); ?>"><i class="fa-solid fa-file-circle-plus"></i> Add Reports</a></li>
                        <li><a href="<?php echo e(url('reports')); ?>"><i class="fa-solid fa-eye"></i> View Reports</a></li>
                    </ul>
                </li>

                <!-- Expenses -->
                <li class="menu-title"><span>Expenses</span></li>
                <li class="submenu">
                    <a href="javascript:void(0);">
                        <i class="fa-solid fa-wallet"></i><span> Expenses</span>
                        <span class="menu-arrow"><i class="fa-solid fa-angle-down"></i></span>
                    </a>
                    <ul>
                        <li><a href="<?php echo e(url('expenses/create')); ?>"><i class="fa-solid fa-plus"></i> Create Expense</a></li>
                        <li><a href="<?php echo e(url('expenses/index')); ?>"><i class="fa-solid fa-eye"></i> View Expenses</a></li>
                    </ul>
                </li>

                <!-- Reports -->
                <li class="menu-title"><span>Reports</span></li>
                
                <li>
                    <a href="<?php echo e(url('expenses/reports')); ?>">
                        <i class="fa-solid fa-chart-line"></i><span> Expense Reports</span>
                    </a>
                </li>
                <li>
                    <a href="<?php echo e(url('income/reports')); ?>">
                        <i class="fa-solid fa-chart-line"></i><span> Income Reports</span>
                    </a>
                </li>
                <li>
                    <a href="<?php echo e(url('doctor-notes-reports')); ?>">
                        <i class="fa-solid fa-notes-medical"></i><span>Doctor Notes Reports</span>
                    </a>
                </li>

                <!-- Registers -->
                <li class="menu-title"><span>Registers</span></li>
                <li><a href="<?php echo e(url('escape_view')); ?>"><i class="fa-solid fa-person-running"></i> Escape</a></li>
                <li><a href="<?php echo e(url('death')); ?>"><i class="fa-solid fa-skull-crossbones"></i> Death</a></li>
                <li><a href="<?php echo e(url('injuries')); ?>"><i class="fa-solid fa-hand-holding-medical"></i> Injury</a></li>
                <li><a href="<?php echo e(url('hearings')); ?>"><i class="fa-solid fa-file-signature"></i> FIR / CSR</a></li>
                <li><a href="<?php echo e(url('equipments')); ?>"><i class="fa-solid fa-stethoscope"></i> Medical Equipment</a></li>
                <li>
                    <a href="<?php echo e(url('dangerously-ill')); ?>">
                        <i class="fa-solid fa-triangle-exclamation"></i><span> Danger Illness Record</span>
                    </a>
                </li>

                <!-- Attendance -->
                <li class="menu-title"><span>Attendance</span></li>
                <li class="submenu">
                    <a href="javascript:void(0);">
                        <i class="fa-solid fa-user-check"></i><span> Staff Attendance</span>
                        <span class="menu-arrow"><i class="fa-solid fa-angle-down"></i></span>
                    </a>
                    <ul>
                        <li><a href="<?php echo e(url('attendance')); ?>"><i class="fa-solid fa-calendar-plus"></i> Mark Attendance</a></li>
                        <li><a href="<?php echo e(url('attendance/today')); ?>"><i class="fa-solid fa-eye"></i> Today Report</a></li>
                        <li><a href="<?php echo e(url('attendance/date-report')); ?>"><i class="fa-solid fa-calendar-day"></i> Attendance Report</a></li>
                    </ul>
                </li>

                <!-- Danger Illness -->
                
            </ul>
        </div>
    </div>
</div>
<?php /**PATH /home/hmssocie/public_html/gjcare.hms-society.com/resources/views/include/sidebar.blade.php ENDPATH**/ ?>