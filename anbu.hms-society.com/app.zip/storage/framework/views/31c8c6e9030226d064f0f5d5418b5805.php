

<?php $__env->startSection('content'); ?>
<div class="main-wrapper">
    <?php echo $__env->make('include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('include.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="page-wrapper">
        <div class="content">
            <div class="d-flex justify-content-between mb-3">
                <h4>Death Register</h4>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(url('dashboard')); ?>">Dashboard</a></li>
                    <li class="breadcrumb-item active">Death Register</li>
                </ol>
            </div>

            <!-- Filter -->
            <div class="card mb-3">
                <div class="card-body">
                    <form id="filterForm">
                        <div class="row">
                            <div class="col-md-3">
                                <label for="from_date">From Date</label>
                                <input type="date" id="from_date" name="from_date" class="form-control">
                            </div>
                            <div class="col-md-3">
                                <label for="to_date">To Date</label>
                                <input type="date" id="to_date" name="to_date" class="form-control">
                            </div>
                            <div class="col-md-2 d-flex align-items-end">
                                <button type="button" class="btn btn-secondary w-100" onclick="resetFilter()">Reset</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Table -->
            <div class="card">
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered" id="deathRegisterTable">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Patient ID</th>
                                    <th>Patient Name</th>
                                    <th>Death Date & Time</th>
                                    <th>Report</th>
                                    <th>Note</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody id="deathTableBody">
                                <?php $__currentLoopData = $deaths; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $death): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($death->id); ?></td>
                                    <td><?php echo e($death->patient_id); ?></td>
                                    <td><?php echo e($death->full_name); ?></td>
                                    <td><?php echo e(\Carbon\Carbon::parse($death->death_datetime)->format('d-m-Y H:i')); ?></td>
                                    <td>
                                        <?php if($death->report_attachment): ?>
                                            <a href="<?php echo e(asset('uploads/death_reports/'.$death->report_attachment)); ?>" target="_blank">View</a>
                                        <?php else: ?>
                                            N/A
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e($death->note ?? '-'); ?></td>
                                    <td>
                                        <a href="<?php echo e(url('death/edit/'.$death->id)); ?>">
                                            <i class="fa-solid fa-pen-to-square text-success"></i>
                                        </a>
                                        <a href="javascript:void(0)" class="btn btn-white deleteDeathBtn" data-id="<?php echo e($death->id); ?>">
                                            <i class="fa-solid fa-trash text-danger"></i>
                                        </a>

                                        <form id="delete-form-<?php echo e($death->id); ?>" action="<?php echo e(route('death.destroy', $death->id)); ?>" method="POST" style="display: none;">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                        </form>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <?php if($deaths->isEmpty()): ?>
                            <p class="text-center">No records found.</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>

<!-- JS -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<script>
$(document).ready(function(){

    function fetchDeaths() {
        var from_date = $('#from_date').val();
        var to_date = $('#to_date').val();

        $.ajax({
            url: "<?php echo e(url('death')); ?>",
            type: "GET",
            data: { from_date: from_date, to_date: to_date },
            dataType: "json",
            success: function(response){
                $('#deathTableBody').html(response.html);
                bindDeleteButtons();
            },
            error: function(){
                Swal.fire("Error!", "Failed to fetch records.", "error");
            }
        });
    }

    // Auto fetch when filter changes
    $('#from_date, #to_date').on('change', function(){
        fetchDeaths();
    });

    // Reset filter
    window.resetFilter = function(){
        $('#from_date, #to_date').val('');
        fetchDeaths();
    }

    // Delete button binding
    function bindDeleteButtons(){
        $('.deleteDeathBtn').off('click').on('click', function(e){
            e.preventDefault();
            var id = $(this).data("id");

            Swal.fire({
                title: "Are you sure?",
                text: "This record will be permanently deleted!",
                icon: "warning",
                showCancelButton: true,
                confirmButtonText: "Yes, delete it!",
                cancelButtonText: "Cancel"
            }).then((result) => {
                if(result.isConfirmed){
                    $("#delete-form-" + id).submit();
                }
            });
        });
    }

    // Initial fetch on page load (default today)
    fetchDeaths();

    bindDeleteButtons();
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\medical\resources\views/death_register/index.blade.php ENDPATH**/ ?>