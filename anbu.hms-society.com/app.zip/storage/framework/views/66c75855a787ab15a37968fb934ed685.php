

<?php $__env->startSection('content'); ?>
<div class="main-wrapper">
    <?php echo $__env->make('include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('include.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="page-wrapper">
        <div class="content pb-0">
            <div class="container-fluid">

                <div class="card shadow-lg border-0 rounded-4 p-4 mt-4">
                    <div class="text-center mb-4">
                        <h2 class="fw-bold text-gradient">🏥 Patient Registration Form</h2>
                        <p class="text-muted">Please fill out the required details carefully</p>
                        <hr class="mt-3 mb-4 mx-auto w-50">
                    </div>

                    <form id="patientForm" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>

                        <!-- Personal Details -->
                        <div class="section-title mb-3">👤 Personal Details</div>
                        <div class="row g-3">
                            <div class="col-md-3">
                                <label class="form-label">Registration No <span class="text-danger">*</span></label>
                                <input type="text" name="reg_no" class="form-control" value="<?php echo e($newRegNo); ?>" readonly>
                            </div>

                            <div class="col-md-3">
                                <label class="form-label">Admission Date <span class="text-danger">*</span></label>
                                <input type="date" id="date_of_admission" name="date_of_admission" class="form-control" required>
                            </div>

                            <div class="col-md-3">
                                <label class="form-label">Admission Time <span class="text-danger">*</span></label>
                                <input type="text" id="time_of_admission" name="time_of_admission" class="form-control" placeholder="hh:mm AM/PM" required>
                            </div>

                            <div class="col-md-3">
                                <label class="form-label">Patient Name <span class="text-danger">*</span></label>
                                <input type="text" name="name" class="form-control" placeholder="Full Name" required>
                            </div>

                            <div class="col-md-2">
                                <label class="form-label">Age <span class="text-danger">*</span></label>
                                <input type="number" name="age" class="form-control" min="0" required>
                            </div>

                            <div class="col-md-3">
                                <label class="form-label">Gender <span class="text-danger">*</span></label>
                                <select name="gender" class="form-select select2" required>
                                    <option value="">Select</option>
                                    <option>Male</option>
                                    <option>Female</option>
                                    <option>Other</option>
                                </select>
                            </div>

                            <div class="col-md-4">
                                <label class="form-label">Marital Status</label>
                                <select name="marital_status" class="form-select select2">
                                    <option value="">Select</option>
                                    <option>Single</option>
                                    <option>Married</option>
                                    <option>Widowed</option>
                                    <option>Divorced</option>
                                </select>
                            </div>

                            <div class="col-md-3">
                                <label class="form-label">Occupation</label>
                                <input type="text" name="occupation" class="form-control">
                            </div>

                            <div class="col-md-3">
                                <label class="form-label">Admitted By</label>
                                <input type="text" name="admitted_by" class="form-control">
                            </div>

                            <div class="col-md-3">
                                <label class="form-label">Contact Number <span class="text-danger">*</span></label>
                                <input type="tel" name="contact_number" class="form-control"
                                       placeholder="9999999999" maxlength="10" pattern="^\d{10}$"
                                       oninput="this.value=this.value.replace(/[^0-9]/g,'')" required>
                            </div>

                            <div class="col-md-3">
                                <label class="form-label">Referral Source</label>
                                <input type="text" name="referral_source" class="form-control">
                            </div>
                        </div>

                        <hr class="my-4">

                        <!-- Address & Aadhar -->
                        <div class="section-title mb-3">📍 Address & ID Details</div>
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="form-label">Present Address <span class="text-danger">*</span></label>
                                <textarea name="present_address" class="form-control" rows="2" required></textarea>
                            </div>

                            <div class="col-md-6">
                                <label class="form-label">Permanent Address</label>
                                <textarea name="permanent_address" class="form-control" rows="2"></textarea>
                            </div>

                            <div class="col-md-6">
                                <label class="form-label">Aadhar Number</label>
                                <input type="text" name="aadhar_number" class="form-control" placeholder="123456789012"
                                       pattern="\d{12}">
                            </div>

                            <div class="col-md-6">
                                <label class="form-label">Upload Photo</label>
                                <input type="file" name="photo" class="form-control" accept="image/*">
                            </div>
                        </div>

                        <hr class="my-4">

                        <!-- Billing Section -->
                        <div class="section-title mb-3">💰 Billing Information</div>
                        <div class="row g-3 mb-3">
                            <div class="col-md-4">
                                <label class="form-label fw-bold">Monthly Amount (₹)</label>
                                <input type="number" id="total_bill" name="total_bill" class="form-control" step="0.01" min="0" required>
                            </div>

                            <div class="col-md-4">
                                <label class="form-label fw-bold">Initial Payment (₹)</label>
                                <input type="number" id="initial_payment" name="initial_payment" class="form-control" step="0.01" min="0" required>
                            </div>

                            <div class="col-md-4">
                                <label class="form-label fw-bold">Pending Amount (₹)</label>
                                <input type="number" id="pending_amount" name="pending_amount" class="form-control" readonly>
                            </div>
                        </div>

                        <div class="row mb-4">
                            <div class="col-md-6">
                                <label class="form-label fw-bold">Account Type</label>
                                <select name="hospital_account" id="hospital_account" class="form-select select2" required>
                                    <option value="">-- Select Account --</option>
                                    <?php $__currentLoopData = DB::table('payment_categories')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $account): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($account->id); ?>"><?php echo e($account->payment_category); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label fw-bold">Payment Mode</label>
                                <select name="payment_mode" id="payment_mode" class="form-select select2" required>
                                    <option value="">Select</option>
                                    <option value="cash">Cash</option>
                                    <option value="card">Card</option>
                                    <option value="upi">UPI</option>
                                    <option value="net_banking">Net Banking</option>
                                </select>
                            </div>
                        </div>

                        <!-- Bill Items Table -->
                        <div class="table-responsive mb-3">
                            <table class="table table-bordered table-striped align-middle" id="billingTable">
                                <thead class="table-gradient text-white">
                                    <tr>
                                        <th class="text-center" style="width:5%">#</th>
                                        <th>Bill Title</th>
                                        <th style="width:25%">Amount (₹)</th>
                                        <th class="text-center" style="width:10%">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td class="text-center">1</td>
                                        <td><input type="text" name="bill_title[]" class="form-control" required></td>
                                        <td><input type="number" name="amount[]" class="form-control item-amount" step="0.01" min="0" required></td>
                                        <td class="text-center"><button type="button" class="btn btn-sm btn-danger removeRow">✖</button></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>

                        <div class="text-end mb-4">
                            <button type="button" id="addRow" class="btn btn-outline-primary btn-sm">+ Add Row</button>
                        </div>

                        <div class="text-center">
                            <button type="submit" class="btn btn-gradient btn-lg px-5 shadow-lg">Register Patient</button>
                        </div>
                    </form>
                </div>

            </div>
        </div>
    </div>
</div>

<!-- JS Links -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0/dist/js/select2.min.js"></script>
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0/dist/css/select2.min.css" rel="stylesheet" />
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>
$(document).ready(function () {
    $('.select2').select2({ width: '100%' });

    // ✅ Auto-fill current date and time
    const now = new Date();
    const yyyy = now.getFullYear();
    const mm = String(now.getMonth() + 1).padStart(2, '0');
    const dd = String(now.getDate()).padStart(2, '0');
    const dateToday = `${yyyy}-${mm}-${dd}`;
    $('#date_of_admission').val(dateToday);

    // Format time as hh:mm AM/PM
    let hours = now.getHours();
    const minutes = String(now.getMinutes()).padStart(2, '0');
    const ampm = hours >= 12 ? 'PM' : 'AM';
    hours = hours % 12 || 12;
    const timeNow = `${hours}:${minutes} ${ampm}`;
    $('#time_of_admission').val(timeNow);

    // --- Existing billing and validation JS ---
    let rowCount = 1;

    $('#addRow').click(function(){
        rowCount++;
        $('#billingTable tbody').append(`
            <tr>
                <td class="text-center">${rowCount}</td>
                <td><input type="text" name="bill_title[]" class="form-control" required></td>
                <td><input type="number" name="amount[]" class="form-control item-amount" step="0.01" min="0" required></td>
                <td class="text-center"><button type="button" class="btn btn-sm btn-danger removeRow">✖</button></td>
            </tr>
        `);
    });

    $(document).on('click', '.removeRow', function(){
        $(this).closest('tr').remove();
        updateRowNumbers();
        updateItemTotal();
    });

    function updateRowNumbers(){
        $('#billingTable tbody tr').each(function(i){
            $(this).find('td:first').text(i + 1);
        });
    }

    $('#total_bill, #initial_payment').on('input', function(){
        validateInitialAndTotal();
        updatePending();
        updateItemTotal();
    });

    $(document).on('input', '.item-amount', updateItemTotal);

    function validateInitialAndTotal(){
        let total = parseFloat($('#total_bill').val()) || 0;
        let initial = parseFloat($('#initial_payment').val()) || 0;
        if (initial > total) {
            Swal.fire({
                icon: 'warning',
                title: 'Invalid Input',
                text: 'Initial Payment cannot exceed Total Bill.'
            });
            $('#initial_payment').val(total.toFixed(2));
        }
    }

    function updateItemTotal(){
        let initial = parseFloat($('#initial_payment').val()) || 0;
        let totalItem = 0, lastInput = null;

        $('.item-amount').each(function(){
            let val = parseFloat($(this).val()) || 0;
            totalItem += val;
            lastInput = $(this);
        });

        if (totalItem > initial) {
            Swal.fire({
                icon: 'error',
                title: 'Exceeded Limit',
                text: 'Bill items total cannot exceed Initial Payment.'
            });
            let excess = totalItem - initial;
            let newVal = parseFloat(lastInput.val()) - excess;
            lastInput.val(newVal > 0 ? newVal.toFixed(2) : 0);
        }
    }

    function updatePending(){
        let total = parseFloat($('#total_bill').val()) || 0;
        let initial = parseFloat($('#initial_payment').val()) || 0;
        $('#pending_amount').val((total - initial).toFixed(2));
    }

    // AJAX Submit
    let isSubmitting = false;

    $('#patientForm').submit(function(e){
        e.preventDefault();
        if (isSubmitting) return;
        isSubmitting = true;

        const formData = new FormData(this);
        const submitBtn = $(this).find('button[type="submit"]');
        submitBtn.prop('disabled', true).html('<span class="spinner-border spinner-border-sm me-2"></span> Registering...');

        $.ajax({
            url: "<?php echo e(route('patients.store')); ?>",
            method: "POST",
            data: formData,
            contentType: false,
            processData: false,
            success:function(res){
                Swal.fire({ icon: 'success', title: 'Registered Successfully!', text: res.message })
                .then(() => window.location.href = "<?php echo e(route('patients.index')); ?>" );
            },
            error:function(xhr){
                isSubmitting = false;
                submitBtn.prop('disabled', false).html('Register Patient');
                if(xhr.status === 422){
                    let errors = xhr.responseJSON.errors;
                    let errMsg = '';
                    for(let key in errors){ errMsg += errors[key][0] + '<br>'; }
                    Swal.fire({ icon: 'error', title: ' Error!', html: errMsg });
                } else {
                    Swal.fire({ icon: 'error', title: 'Error!', text: xhr.responseText });
                }
            }
        });
    });
});
</script>

<style>
.text-gradient {
    background: linear-gradient(45deg, #4e73df, #1cc88a);
    -webkit-background-clip: text;
    color: transparent;
}
.table-gradient {
    background: linear-gradient(45deg, #4e73df, #1cc88a);
}
.btn-gradient {
    background: linear-gradient(135deg, #4e73df, #1cc88a);
    color: white;
    border: none;
    transition: 0.3s;
}
.btn-gradient:hover {
    transform: scale(1.03);
    box-shadow: 0 0 12px rgba(76,175,80,0.3);
}
.section-title {
    font-size: 1.2rem;
    font-weight: 700;
    color: #4e73df;
    border-left: 4px solid #1cc88a;
    padding-left: 10px;
}
.form-label {
    font-weight: 600;
    color: #333;
}
.table thead th {
    text-align: center;
    vertical-align: middle;
}
</style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\deaddtiction\resources\views/patient/create.blade.php ENDPATH**/ ?>