<div class="sidebar" id="sidebar">

    <!-- Sidebar Logo -->
    <div class="sidebar-logo">
        <div>
            <a href="<?php echo e(url('dashboard')); ?>" class="logo logo-normal">
                <h2 class="text-uppercase">Rehab Centre</h2>
            </a>
            <a href="<?php echo e(url('dashboard')); ?>" class="logo-small">
                <img src="<?php echo e(asset('assets/img/logo-small.svg')); ?>" alt="Logo">
            </a>
            <a href="<?php echo e(url('dashboard')); ?>" class="dark-logo">
                <img src="<?php echo e(asset('assets/img/logo-white.svg')); ?>" alt="Logo">
            </a>
        </div>
        <button class="sidenav-toggle-btn btn border-0 p-0 active" id="toggle_btn"> 
            <i class="fa-solid fa-bars text-body"></i>
        </button>
        <button class="sidebar-close">
            <i class="fa-solid fa-bars align-middle"></i>
        </button>
    </div>

    <!-- Sidebar Menu -->
    <div class="sidebar-inner" data-simplebar>
        <div id="sidebar-menu" class="sidebar-menu">
            <ul>
                <li class="menu-title"><span>Main Menu</span></li>

                <!-- Dashboard -->
                <li>
                    <a href="<?php echo e(url('dashboard')); ?>">
                        <i class="fa-solid fa-gauge-high"></i><span> Dashboard </span>
                    </a>
                </li>

               <li class="submenu">
                    <a href="javascript:void(0);" class="subdrop">
                        <i class="fa-solid fa-database"></i><span> Masters </span>
                        <span class="menu-arrow"><i class="fa-solid fa-angle-down"></i></span>
                    </a>
                    <ul>
                        <li><a href="<?php echo e(url('expenses-category/view')); ?>"><i class="fa-solid fa-money-bill"></i> Expenses   MainCategory</a></li>
                        <li><a href="<?php echo e(url('expenses/view')); ?>"><i class="fa-solid fa-money-bill"></i> Expenses SubCategory</a></li>
                        <li><a href="<?php echo e(url('vendors')); ?>"><i class="fa-solid fa-people-group"></i> Vendors</a></li>
                        <li><a href="<?php echo e(url('medicine-categories')); ?>"><i class="fa-solid fa-capsules"></i> Medicine Categories</a></li>
                        <li><a href="<?php echo e(url('payment-categories')); ?>"><i class="fa-solid fa-file-invoice"></i> Payment Categories</a></li>
                    </ul>
                </li>
                <li class="submenu">
                    <a href="javascript:void(0);" class="subdrop">
                        <i class="fa-solid fa-hospital-user"></i> Patient Registeration</span>
                        <span class="menu-arrow"><i class="fa-solid fa-angle-down"></i></span>
                    </a>
                    <ul>
                        <li><a href="<?php echo e(url('patients/create')); ?>"><i class="fa-solid fa-plus"></i> Create Patient</a></li>
                        <li><a href="<?php echo e(url('patients')); ?>"><i class="fa-solid fa-eye"></i> View Patient</a></li>
                        <li><a href="<?php echo e(url('patients/discharge/index')); ?>"><i class="fa-solid fa-eye"></i> View Dishcharge Patient</a></li>
                    </ul>
                </li>
                <li class="menu-title"><span>Income</span></li>
                <li class="submenu">
                    <a href="javascript:void(0);" class="subdrop">
                        <i class="fa-solid fa-file-invoice-dollar"></i><span> Patient Bill </span>
                        <span class="menu-arrow"><i class="fa-solid fa-angle-down"></i></span>
                    </a>
                    <ul>
                        <!-- <li><a href="<?php echo e(url('create_billing')); ?>"><i class="fa-solid fa-plus"></i> Create Patient Bill </a></li> -->
                        <li><a href="<?php echo e(url('billing')); ?>"><i class="fa-solid fa-eye"></i> View Patient Bill </a></li>
                    </ul>
                </li>
                <li class="submenu">
                    <a href="javascript:void(0);" class="subdrop">
                        <i class="fa-solid fa-prescription-bottle-medical"></i><span> Medicine Issue Billing</span>
                        <span class="menu-arrow"><i class="fa-solid fa-angle-down"></i></span>
                    </a>
                    <ul>
                        <li><a href="<?php echo e(url('medicine-issues/create')); ?>"><i class="fa-solid fa-plus"></i> Create Medicine Issue</a></li>
                        <li><a href="<?php echo e(url('medicine-issues')); ?>"><i class="fa-solid fa-eye"></i> View Medicine Issue</a></li>
                        <li><a href="<?php echo e(url('medicine-issues/reports')); ?>"><i class="fa-solid fa-file-lines"></i> Medicine Issue Reports</a></li>
                    </ul>
                </li>
                <li>
                    <a href="<?php echo e(url('loan/index')); ?>">
                        <i class="fa-solid fa-piggy-bank"></i><span> Loan </span>
                    </a>
                </li>
                <li class="menu-title"><span>Expenses</span></li>
                 <li class="submenu">
                    <a href="javascript:void(0);" class="subdrop">
                        <i class="fa-solid fa-wallet"></i><span> Expenses </span>
                        <span class="menu-arrow"><i class="fa-solid fa-angle-down"></i></span>
                    </a>
                    <ul>
                        <li><a href="<?php echo e(url('expenses/create')); ?>"><i class="fa-solid fa-plus"></i> Create Expenses</a></li>
                        <li><a href="<?php echo e(url('expenses/index')); ?>"><i class="fa-solid fa-eye"></i> View Expenses</a></li>
                        
                    </ul>
                </li>
                
                <li class="menu-title"><span>Medicine </span></li>
                <li class="submenu">
                    <a href="javascript:void(0);" class="subdrop">
                        <i class="fa-solid fa-pills"></i><span> Medicine Stock</span>
                        <span class="menu-arrow"><i class="fa-solid fa-angle-down"></i></span>
                    </a>
                    <ul>
                        <li><a href="<?php echo e(url('medicine/create')); ?>"><i class="fa-solid fa-plus"></i> Create Medicine</a></li>
                        <li><a href="<?php echo e(url('medicine')); ?>"><i class="fa-solid fa-eye"></i> View Medicine</a></li>
                        <li><a href="<?php echo e(url('stock')); ?>"><i class="fa-solid fa-boxes-stacked"></i> Stock</a></li>
                    </ul>
                </li>
                 <li class="">
                    <a href="<?php echo e(url('escape_view')); ?>"><i class="fa-solid fa-book-medical"></i><span>Escape Register</span></a>                                    
                </li>
                <li class="">
                    <a href="<?php echo e(url('death')); ?>"><i class="fa-solid fa-book-skull"></i><span>Death Register</span></a>                                    
                </li> 
                
                <li class="menu-title"><span>Reports </span></li>
                <li><a href="<?php echo e(url('patients/reports')); ?>"><i class="fa-solid fa-piggy-bank"></i><span> Patient Reports </span></a></li>
                <li><a href="<?php echo e(url('expenses/reports')); ?>"><i class="fa-solid fa-chart-line"></i> Expenses Reports</a></li>
                <li><a href="<?php echo e(url('accounttype/reports')); ?>"><i class="fa-solid fa-chart-line"></i> Account Type Reports</a></li>
                
                 <li class="menu-title"><span>Register </span></li>
                 <li><a href="<?php echo e(url('emergency')); ?>"><i class="fa-solid fa-piggy-bank"></i><span> Emergency Hospitalization Register </span></a></li>
                 <li><a href="<?php echo e(url('patient-expense')); ?>"><i class="fa-solid fa-piggy-bank"></i><span> Patient Expenses </span></a></li>
                 <li><a href="<?php echo e(url('emergency_call_register')); ?>"><i class="fa-solid fa-piggy-bank"></i><span> Emergency Call Register </span></a></li>

            </ul>
        </div>
    </div>

</div>
<?php /**PATH /home/furniica/public_html/deaddtiction/resources/views/include/sidebar.blade.php ENDPATH**/ ?>