

<?php $__env->startSection('content'); ?>
<div class="main-wrapper">
    <?php echo $__env->make('include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('include.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="page-wrapper">
        <div class="content">

            <div class="page-header d-flex justify-content-between align-items-center">
                <h4 class="mb-0">Loan Management</h4>
                <button class="btn btn-primary" id="addLoanBtn">
                    <i class="fa fa-plus"></i> Add Loan
                </button>
            </div>

            <div class="card mt-3">
                <div class="card-body">
                    <table id="loanTable" class="table table-bordered table-striped align-middle">
                        <thead class="">
                            <tr>
                                <th>#</th>
                                <th>Loan Amount</th>
                                <th>Bank Name</th>
                                <th>Loan Date</th>
                                <th>Loan Type</th>
                                <th>Other Details</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $loans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $loan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($key + 1); ?></td>
                                <td><?php echo e($loan->loan_amount); ?></td>
                                <td><?php echo e($loan->bank_name); ?></td>
                                <td><?php echo e($loan->loan_date); ?></td>
                                <td><?php echo e($loan->loan_type); ?></td>
                                <td><?php echo e($loan->other_details); ?></td>
                                <td>
                                    <button class="btn btn-sm btn-primary editBtn" data-id="<?php echo e($loan->id); ?>"><i class="fa fa-edit"></i></button>
                                    <button class="btn btn-sm btn-danger deleteBtn" data-id="<?php echo e($loan->id); ?>"><i class="fa fa-trash"></i></button>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>

        </div>
    </div>
</div>

<!-- ✅ Loan Modal -->
<div class="modal fade" id="loanModal" tabindex="-1" aria-labelledby="loanModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-md">
        <div class="modal-content">
            <form id="loanForm">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="loan_id" id="loan_id">

                <div class="modal-header">
                    <h5 class="modal-title" id="loanModalLabel">Add Loan</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>

                <div class="modal-body">
                    <div class="row g-3">
                        <div class="col-md-12">
                            <label>Loan Amount (₹)</label>
                            <input type="number" name="loan_amount" id="loan_amount" class="form-control" step="0.01" min="0" required>
                        </div>

                        <div class="col-md-12">
                            <label>Bank Name</label>
                            <input type="text" name="bank_name" id="bank_name" class="form-control" required>
                        </div>

                        <div class="col-md-12">
                            <label>Loan Date</label>
                            <input type="date" name="loan_date" id="loan_date" class="form-control" required>
                        </div>

                        <div class="col-md-12">
                            <label>Loan Type</label>
                            <select name="loan_type" id="loan_type" class="form-select" required>
                                <option value="">-- Select Type --</option>
                                <option value="Private">Private</option>
                                <option value="Other">Other</option>
                            </select>
                        </div>

                        <div class="col-md-12" id="other_details_box" style="display:none;">
                            <label>Enter Details / Amount</label>
                            <input type="text" name="other_details" id="other_details" class="form-control" placeholder="Enter details for 'Other'">
                        </div>
                    </div>
                </div>

                <div class="modal-footer">
                    <button type="submit" id="saveLoanBtn" class="btn btn-success">Save</button>
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                </div>
            </form>
        </div>
    </div>
</div>


<!-- ✅ Include jQuery FIRST -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<!-- ✅ Bootstrap Bundle -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

<!-- ✅ SweetAlert2 -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<!-- ✅ DataTables & Export Buttons -->
<link rel="stylesheet" href="https://cdn.datatables.net/1.13.8/css/jquery.dataTables.min.css">
<link rel="stylesheet" href="https://cdn.datatables.net/buttons/3.1.2/css/buttons.dataTables.min.css">

<script src="https://cdn.datatables.net/1.13.8/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/buttons/3.1.2/js/dataTables.buttons.min.js"></script>
<script src="https://cdn.datatables.net/buttons/3.1.2/js/buttons.html5.min.js"></script>
<script src="https://cdn.datatables.net/buttons/3.1.2/js/buttons.print.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.2.7/pdfmake.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.2.7/vfs_fonts.js"></script>

<script>
$(document).ready(function() {
    // ✅ Initialize DataTable with Export Buttons
    $('#loanTable').DataTable({
        dom: '<"d-flex justify-content-between align-items-center mb-3"Bf>rtip',
        buttons: [
            {
                extend: 'excelHtml5',
                className: 'btn btn-success btn-sm me-2',
                text: '<i class="fa fa-file-excel"></i> Excel',
                title: 'Loan Report'
            },
            {
                extend: 'csvHtml5',
                className: 'btn btn-info btn-sm me-2',
                text: '<i class="fa fa-file-csv"></i> CSV',
                title: 'Loan Report'
            },
            {
                extend: 'pdfHtml5',
                className: 'btn btn-danger btn-sm me-2',
                text: '<i class="fa fa-file-pdf"></i> PDF',
                title: 'Loan Report'
            },
            {
                extend: 'print',
                className: 'btn btn-secondary btn-sm',
                text: '<i class="fa fa-print"></i> Print',
                title: 'Loan Report'
            }
        ],
        pageLength: 10,
        responsive: true
    });
});
</script>

<!-- ✅ Loan Management Script -->
<script>
$(function() {

    // Add Loan
    $('#addLoanBtn').click(function() {
        $('#loanForm')[0].reset();
        $('#loan_id').val('');
        $('#loanModalLabel').text('Add Loan');
        $('#other_details_box').hide();
        $('#loanModal').modal('show');
    });

    // Show/Hide Other Details
    $(document).on('change', '#loan_type', function() {
        if ($(this).val() === 'Other') {
            $('#other_details_box').slideDown();
            $('#other_details').attr('required', true);
        } else {
            $('#other_details_box').slideUp();
            $('#other_details').removeAttr('required').val('');
        }
    });

    // Save Loan
    $('#loanForm').on('submit', function(e) {
        e.preventDefault();
        Swal.fire({
            title: 'Confirm Save',
            text: "Do you want to save this loan record?",
            icon: 'question',
            showCancelButton: true,
            confirmButtonText: 'Yes, Save it',
            cancelButtonText: 'Cancel'
        }).then((result) => {
            if (result.isConfirmed) {
                let id = $('#loan_id').val();
                let url = id ? "<?php echo e(url('loan/update')); ?>/" + id : "<?php echo e(url('loan/store')); ?>";
                let method = id ? 'PUT' : 'POST';

                $.ajax({
                    url: url,
                    method: method,
                    data: $(this).serialize(),
                    success: function(res) {
                        Swal.fire('Success', res.message, 'success').then(() => location.reload());
                    },
                    error: function(xhr) {
                        Swal.fire('Error', xhr.responseJSON?.message || 'Something went wrong', 'error');
                    }
                });
            }
        });
    });

    // Edit Loan
    $(document).on('click', '.editBtn', function() {
        let id = $(this).data('id');
        $.get("<?php echo e(url('loan/edit')); ?>/" + id, function(res) {
            $('#loan_id').val(res.id);
            $('#loan_amount').val(res.loan_amount);
            $('#bank_name').val(res.bank_name);
            $('#loan_date').val(res.loan_date);
            $('#loan_type').val(res.loan_type).trigger('change');
            if (res.loan_type === 'Other') {
                $('#other_details').val(res.other_details);
            }
            $('#loanModalLabel').text('Edit Loan');
            $('#loanModal').modal('show');
        });
    });

    // Delete Loan
    $(document).on('click', '.deleteBtn', function() {
        let id = $(this).data('id');
        Swal.fire({
            title: 'Are you sure?',
            text: "This will permanently delete the record.",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Yes, Delete it'
        }).then((result) => {
            if (result.isConfirmed) {
                $.ajax({
                    url: "<?php echo e(url('loan/delete')); ?>/" + id,
                    method: 'DELETE',
                    data: { _token: '<?php echo e(csrf_token()); ?>' },
                    success: function(res) {
                        Swal.fire('Deleted!', res.message, 'success').then(() => location.reload());
                    },
                    error: function() {
                        Swal.fire('Error', 'Unable to delete record', 'error');
                    }
                });
            }
        });
    });

});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/hmssocie/public_html/iyengaran.hms-society.com/resources/views/loan/index.blade.php ENDPATH**/ ?>