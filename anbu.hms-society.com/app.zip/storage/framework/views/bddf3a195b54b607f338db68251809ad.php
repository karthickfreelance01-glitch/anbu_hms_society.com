<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Patient Discharge Bill - <?php echo e($patient->name); ?></title>
  <style>
    @page { margin: 30px; }
    body {
      font-family: DejaVu Sans, sans-serif;
      font-size: 13px;
      background-color: #fff;
      color: #000;
    }
    .bill-container {
      border: 1px solid #ddd;
      border-top: 6px solid #ff0909 ;
      border-radius: 8px;
      padding: 20px 25px;
    }
    .header-table {
      width: 100%;
      border-bottom: 2px solid #007bff;
      margin-bottom: 20px;
    }
    .hospital-name {
      font-weight: bold;
      font-size: 18px;
      color: #007bff;
      margin: 0;
    }
    .hospital-address {
      font-size: 11px;
      color: #555;
    }
    .bill-title {
      text-align: center;
      font-weight: bold;
      font-size: 16px;
      margin: 10px 0 25px;
      text-transform: uppercase;
    }
    .info-table {
      width: 100%;
      margin-bottom: 15px;
      border-collapse: collapse;
    }
    .info-table td {
      padding: 4px 6px;
      vertical-align: top;
    }
    .section-title {
      font-weight: bold;
      font-size: 14px;
      color: #ff0909;
      border-bottom: 2px solid #ff0909;
      display: inline-block;
      margin: 20px 0 10px;
    }
    .table {
      width: 100%;
      border-collapse: collapse;
      margin-bottom: 15px;
    }
    .table th, .table td {
      border: 1px solid #999;
      padding: 6px;
      text-align: left;
    }
    .table th {
      background-color: #eaf2ff;
      font-weight: bold;
    }
    .summary-table {
      width: 60%;
      float: right;
      border-collapse: collapse;
    }
    .summary-table th, .summary-table td {
      border: 1px solid #999;
      padding: 6px;
    }
    .final-amount {
      background-color: #e6f4ea;
      font-weight: bold;
      color: #155724;
    }
    .footer-text {
      clear: both;
      text-align: center;
      font-size: 11px;
      color: #555;
      margin-top: 30px;
      border-top: 1px dashed #ccc;
      padding-top: 8px;
    }
  </style>
</head>
<body>
  <div class="bill-container">

    <!-- Header -->
   <table class="header-table" style="width:100%; border-bottom:2px solid #ff0909; margin-bottom:25px;">
  <tr>
    <td width="15%" style="text-align:left;">
      <img src="<?php echo e(public_path('assets/img/IMG_1774.png')); ?>" alt="Left Logo" style="width:100px;">
    </td>

    <td width="70%" style="text-align:center;">
      <div class="hospital-name" style="font-weight:800; font-size:20px; color:#ff0909; text-transform:uppercase;">
        THE MAATRAM REHABILITATION CENTER
      </div>
      <div class="hospital-sub" style="font-weight:600; color:#ff0909; font-size:15px;">
        & DE ADDICTION FOR DRUGS
      </div>
      <div class="hospital-address" style="font-size:13px; color:#000; line-height:1.5;font-weight:700">
        Govt. Regt No : 00529<br>
        SF. No : 332/5, Nehru Nagar West, Kalapatti Main Road, Sitra, Coimbatore – 641014<br>
        Ph : 94437 95265 / 97901 33349 / 98650 81843
      </div>
    </td>

    <td width="15%" style="text-align:right;">
      <img src="<?php echo e(public_path('assets/img/IMG_1775.png')); ?>" alt="Right Logo" style="width:120px;">
    </td>
  </tr>
</table>


    <h4 class="bill-title">Patient Discharge Bill Summary</h4>

    <!-- Patient Info -->
    <table class="info-table" width="100%">
      <tr>
        <td width="50%">
          <table width="100%">
            <tr><td><strong>Patient Name:</strong> <?php echo e($patient->name); ?></td></tr>
            <tr><td><strong>IP Number:</strong> <?php echo e($patient->ip_number); ?></td></tr>
            <tr><td><strong>Gender:</strong> <?php echo e($patient->gender); ?></td></tr>
            <tr><td><strong>Contact:</strong> <?php echo e($patient->contact_number); ?></td></tr>
          </table>
        </td>
        <td width="50%">
          <table width="100%">
            <tr><td><strong>Admission Date:</strong> <?php echo e($admissionDate->format('d-M-Y')); ?></td></tr>
            <tr><td><strong>Discharge Date:</strong> <?php echo e($dischargeDate->format('d-M-Y')); ?></td></tr>
            <tr><td><strong>Monthly Fess:</strong> <?php echo e($monthlyAmount); ?> </td></tr>
            <tr><td><strong>Extra Days:</strong> <?php echo e($extraDays); ?> </td></tr>
          </table>
        </td>
      </tr>
    </table>

    <!-- Billing Details -->
    <p class="section-title">Detailed Billing </p>
    <table class="table">
      <thead>
        <tr>
          <th>Category</th>
          <th align="right">Total (₹)</th>
          <th align="right">Received (₹)</th>
          <th align="right">Pending (₹)</th>
        </tr>
      </thead>
      <tbody>
        <?php $__currentLoopData = $allBillings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><?php echo e(ucfirst($b->category)); ?></td>
          <td style="text-align : right"><?php echo e(number_format($b->total_amount, 2)); ?></td>
          <td style="text-align : right"><?php echo e(number_format($b->total_received, 2)); ?></td>
          <td style="text-align : right"><?php echo e(number_format($b->total_pending, 2)); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>

    <!-- Summary -->
    <table class="summary-table">
      <tr><th>Total Amount</th><td align="right">₹<?php echo e(number_format($totalAmount, 2)); ?></td></tr>
      <tr><th>Total Received</th><td align="right">₹<?php echo e(number_format($totalReceived, 2)); ?></td></tr>
      <tr><th>Total Pending</th><td align="right">₹<?php echo e(number_format($totalPending, 2)); ?></td></tr>
      <tr class="final-amount"><th>Final Amount Payable</th><td align="right">₹<?php echo e(number_format($totalPending, 2)); ?></td></tr>
    </table>

    <div class="footer-text">
      <p><strong>Note:</strong> Please settle pending amount before discharge. For clarifications, contact billing counter.</p>
      <p>Thank you for choosing <strong>THE MAATRAM REHABILITATION CENTER & DE ADDICTION FOR DRUGS</strong>. Wishing you a speedy recovery!</p>
    </div>

  </div>
</body>
</html>
<?php /**PATH /home/hmssocie/public_html/maatram.hms-society.com/resources/views/discharge_bill.blade.php ENDPATH**/ ?>