

<?php $__env->startSection('content'); ?>
<div class="main-wrapper">
    <?php echo $__env->make('include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('include.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <div class="page-wrapper">
        <div class="content pb-0">
            <div class="card">
                <div class="card-header">
                    <h4 class="mb-0">Patient Registration</h4>
                </div>
                <div class="card-body">
                    <?php if(session('success')): ?>
                        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
                    <?php endif; ?>
                    <?php $__currentLoopData = $patient; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $patient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <form action="<?php echo e(url('patients/update/'.$patient->id)); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <!-- Left Column -->
                            <div class="col-md-6">
                                <div class="form-group mb-2">
                                    <label>Patient ID</label>
                                    <input type="text" class="form-control" name="patient_id" value="<?php echo e($patient->patient_id); ?>" readonly style="background: #f3f3f3">
                                </div>

                                <div class="form-group mb-2">
                                    <label>Full Name</label>
                                    <input type="text" class="form-control" name="full_name" value="<?php echo e($patient->full_name); ?>" required>
                                </div>

                                <div class="form-group mb-2">
                                    <label>Date of Birth</label>
                                    <input type="text" class="form-control" id="dob" name="dob" value="<?php echo e($patient->dob); ?>" placeholder="MM/DD/YYYY" maxlength="10" required>
                                </div>

                                <div class="form-group mb-2">
                                    <label>Age</label>
                                    <input type="text" class="form-control" id="age" name="age" value="<?php echo e($patient->age); ?>" readonly style="background: #f3f3f3">
                                </div>

                                <div class="form-group mb-2">
                                    <label>Gender</label>
                                    <select class="form-control" name="gender" required>
                                        <option value="">Select Gender</option>
                                        <option value="Male" <?php echo e($patient->gender == 'Male' ? 'selected' : ''); ?>>Male</option>
                                        <option value="Female" <?php echo e($patient->gender == 'Female' ? 'selected' : ''); ?>>Female</option>
                                        <option value="Other" <?php echo e($patient->gender == 'Other' ? 'selected' : ''); ?>>Other</option>
                                    </select>
                                </div>

                                <div class="form-group mb-2">
                                    <label>Height (cm)</label>
                                    <input type="number" class="form-control" name="height" value="<?php echo e($patient->height); ?>">
                                </div>

                                <div class="form-group mb-2">
                                    <label>Weight (kg)</label>
                                    <input type="number" class="form-control" name="weight" value="<?php echo e($patient->weight); ?>">
                                </div>

                                <div class="form-group mb-2">
                                    <label>BP Level</label>
                                    <input type="text" class="form-control" name="bp_level" value="<?php echo e($patient->bp_level); ?>">
                                </div>

                                <div class="form-group mb-2">
                                    <label>Sugar Level</label>
                                    <input type="text" class="form-control" name="sugar_level" value="<?php echo e($patient->sugar_level); ?>">
                                </div>
                            </div>

                            <!-- Right Column -->
                            <div class="col-md-6">
                                <div class="form-group mb-2">
                                    <label>Aadhaar Number</label>
                                    <input type="text" class="form-control" name="aadhaar_number" value="<?php echo e($patient->aadhaar_number); ?>">
                                </div>

                                <div class="form-group mb-2">
                                    <label>Aadhaar Upload</label>
                                    <input type="file" class="form-control" name="aadhaar_file">
                                    <?php if($patient->aadhaar_file): ?>
                                        <a href="<?php echo e(asset($patient->aadhaar_file)); ?>" target="_blank">View Aadhaar</a>
                                    <?php endif; ?>
                                </div>

                                <div class="form-group mb-2">
                                    <label>Contact Number</label>
                                    <input type="text" class="form-control" name="contact_number" value="<?php echo e($patient->contact_number); ?>">
                                </div>

                                <div class="form-group mb-2">
                                    <label>Address</label>
                                    <textarea class="form-control" name="address"><?php echo e($patient->address); ?></textarea>
                                </div>

                                <div class="form-group mb-2">
                                    <label>Emergency Contact Name</label>
                                    <input type="text" class="form-control" name="emergency_name" value="<?php echo e($patient->emergency_name); ?>">
                                </div>

                                <div class="form-group mb-2">
                                    <label>Emergency Contact Number</label>
                                    <input type="text" class="form-control" name="emergency_number" value="<?php echo e($patient->emergency_number); ?>">
                                </div>

                                <div class="form-group mb-2">
                                    <label>Emergency Contact Proof</label>
                                    <input type="file" class="form-control" name="emergency_proof">
                                    <?php if($patient->emergency_proof): ?>
                                        <a href="<?php echo e(asset($patient->emergency_proof)); ?>" target="_blank">View Emergency Proof</a>
                                    <?php endif; ?>
                                </div>

                                <div class="form-group mb-2">
                                    <label>Medical Reports</label>
                                    <input type="file" class="form-control" name="medical_reports[]" multiple>
                                    <?php if($patient->medical_reports): ?>
                                        <?php $__currentLoopData = json_decode($patient->medical_reports, true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <a href="<?php echo e(asset($report)); ?>" target="_blank">View Report</a><br>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </div>

                                <div class="form-group mb-2">
                                    <label>Patient Description / Notes</label>
                                    <textarea class="form-control" name="description"><?php echo e($patient->description); ?></textarea>
                                </div>
                            </div>
                        </div>

                        <button type="submit" class="btn btn-success mt-3">Update Patient</button>
                    </form>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- JS to calculate age -->
<script>
document.getElementById('dob').addEventListener('change', function(){
    var dob = new Date(this.value);
    var diff = Date.now() - dob.getTime();
    var ageDate = new Date(diff);
    document.getElementById('age').value = Math.abs(ageDate.getUTCFullYear() - 1970);
});
</script>
<script>
$(document).ready(function(){
    $('#dob').datepicker({
        format: 'yyyy-mm-dd',
        autoclose: true,
        todayHighlight: true,
        endDate: '0d', // prevent future dates
        clearBtn: true
    });

    // Age calculation on change
    $('#dob').on('change', function(){
        var dob = new Date(this.value);
        var diff = Date.now() - dob.getTime();
        var ageDate = new Date(diff);
        $('#age').val(Math.abs(ageDate.getUTCFullYear() - 1970));
    });
});
</script>
<script>
document.getElementById('dob').addEventListener('input', function(e) {
    let input = this.value.replace(/\D/g,''); // Remove non-digits

    if(input.length > 2 && input.length <= 4){
        input = input.slice(0,2) + '/' + input.slice(2);
    } else if(input.length > 4){
        input = input.slice(0,2) + '/' + input.slice(2,4) + '/' + input.slice(4,8);
    }

    this.value = input;
});
</script>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\medical\resources\views/patient/patient_edit.blade.php ENDPATH**/ ?>