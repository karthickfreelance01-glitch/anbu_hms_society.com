
<?php $__env->startSection('content'); ?>

<div class="main-wrapper">
    <?php echo $__env->make('include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('include.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="page-wrapper">
        <div class="content container-fluid">

            <h3 class="text-success fw-bold mb-4">Discharge Bill Preview</h3>

            <div class="card shadow p-4 border-0 rounded-4">
                <h5 class="fw-bold text-primary mb-3">Document Viewer (.docx)</h5>

                <!-- ✅ Embed DOCX File in iframe -->
                <div class="ratio ratio-16x9 border rounded-3">
                    <iframe 
                        src="https://view.officeapps.live.com/op/embed.aspx?src=<?php echo e(urlencode($fileUrl)); ?>" 
                        width="100%" 
                        height="700px" 
                        frameborder="0">
                    </iframe>
                </div>

                <div class="text-end mt-3">
                    <a href="<?php echo e($fileUrl); ?>" class="btn btn-primary" download>
                        <i class="fas fa-download me-2"></i>Download .docx
                    </a>
                </div>
            </div>

        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\maatram\resources\views/bill.blade.php ENDPATH**/ ?>