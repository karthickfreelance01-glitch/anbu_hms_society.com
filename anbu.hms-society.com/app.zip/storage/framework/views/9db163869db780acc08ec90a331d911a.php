

<?php $__env->startSection('content'); ?>
<div class="main-wrapper">
    <?php echo $__env->make('include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('include.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="page-wrapper">
        <div class="content pb-0">
            <!-- Page Header -->
            <div class="d-flex justify-content-between mb-3">
                <h4>Patient Master</h4>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(url('dashboard')); ?>">Dashboard</a></li>
                    <li class="breadcrumb-item active">Patient Report</li>
                </ol>
            </div>

            <!-- Patient Table -->
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h4 class="mb-0">Patient List</h4>
                    <a href="<?php echo e(url('patient/create')); ?>" class="btn btn-primary btn-sm">Add Patient</a>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table id="patientTable" class="table table-bordered">
                            <thead class="table-light">
                                <tr>
                                    <th>#</th>
                                    <th>Patient ID</th>
                                    <th>Full Name</th>
                                    <th>DOB</th>
                                    <th>Age</th>
                                    <th>Gender</th>
                                    <th>Contact No</th>
                                    <th>Emergency Contact</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody id="patientTableBody">
                                <?php $__empty_1 = true; $__currentLoopData = $data['patient']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $patient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($patient->patient_id); ?></td>
                                        <td><?php echo e($patient->full_name); ?></td>
                                        <td><?php echo e($patient->dob); ?></td>
                                        <td><?php echo e($patient->age); ?></td>
                                        <td><?php echo e($patient->gender); ?></td>
                                        <td><?php echo e($patient->contact_number); ?></td>
                                        <td><?php echo e($patient->emergency_name); ?> - <?php echo e($patient->emergency_number); ?></td>
                                        <td>
                                            <div class="d-flex">
                                                <a href="<?php echo e(url('patient/view', $patient->id)); ?>" class="btn btn-sm btn-info me-1">
                                                    <i class="fa-solid fa-eye text-primary"></i>
                                                </a>
                                                <a href="<?php echo e(url('patient/edit', $patient->id)); ?>" class="btn btn-sm btn-white">
                                                    <i class="fa-solid fa-pen-to-square text-success"></i>
                                                </a>
                                                <a href="javascript:void(0)" class="deletepatientBtn btn btn-sm btn-white" data-url="<?php echo e(url('patients/delete/'.$patient->id)); ?>">
                                                    <i class="fa-solid fa-trash text-danger"></i>
                                                </a>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>

<!-- DataTables CSS & JS -->
<link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">
<link rel="stylesheet" href="https://cdn.datatables.net/buttons/2.4.1/css/buttons.dataTables.min.css">

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.1/js/dataTables.buttons.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.1/js/buttons.html5.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.1/js/buttons.print.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.2.7/pdfmake.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.2.7/vfs_fonts.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>
$(document).ready(function(){

    var table = $('#patientTable').DataTable({
        dom: '<"d-flex justify-content-between align-items-center mb-3"<"search-box"f><"dt-buttons"B>>rtip',
        buttons: ['copy', 'csv', 'excel', 'pdf', 'print'],
        responsive: true,
        pagingType: 'simple_numbers',
        language: {
            paginate: {
                previous: '«',
                next: '»'
            },
            search: ""
        }
    });

    // Custom search box with label on left
    $('.search-box').html(`
        <label style="font-weight: bold;"> Search:</label>
        <input type="search" class="form-control form-control-sm ms-2" placeholder="Type to search..." style="display: inline-block; width: auto;">
    `);

    $('.search-box input').on('keyup', function () {
        table.search(this.value).draw();
    });

    // SweetAlert Delete Patient
    function bindDeleteButtons() {
        $('.deletepatientBtn').off('click').on('click', function(e){
            e.preventDefault();
            var url = $(this).data('url');

            Swal.fire({
                title: "Are you sure?",
                text: "This patient will be permanently deleted!",
                icon: "warning",
                showCancelButton: true,
                confirmButtonColor: "#d33",
                cancelButtonColor: "#3085d6",
                confirmButtonText: "Yes, delete it!"
            }).then((result) => {
                if(result.isConfirmed){
                    window.location.href = url;
                }
            });
        });
    }

    bindDeleteButtons();
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/furniica/public_html/deaddtiction/resources/views/patient/patient_index.blade.php ENDPATH**/ ?>