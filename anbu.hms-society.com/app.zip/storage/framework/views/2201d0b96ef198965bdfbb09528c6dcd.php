

<?php $__env->startSection('content'); ?>
<div class="main-wrapper">
    <?php echo $__env->make('include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('include.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="page-wrapper">
        <div class="content pb-0">

            <div class="d-flex align-items-sm-center flex-sm-row flex-column gap-2 pb-3">
                <div class="flex-grow-1">
                    <h4 class="fw-bold mb-0">Roles</h4>
                </div>
                <div class="text-end">
                    <ol class="breadcrumb m-0 py-0">
                        <li class="breadcrumb-item"><a href="<?php echo e(url('dashboard')); ?>">Dashboard</a></li>
                        <li class="breadcrumb-item"><a href="#">Masters</a></li>
                        <li class="breadcrumb-item active">Roles Masters</li>
                    </ol>
                </div>
            </div>

            <div class="row">

                <!-- Roles Table -->
                <div class="col-xl-6">
                    <div class="card">
                        <div class="card-header">
                            <h5 class="card-title">Roles Reports</h5>
                        </div>
                        <div class="card-body">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>S.NO</th>
                                        <th>Roles Title</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $data['roles']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($role->roles_title); ?></td>
                                        <td>
                                            <a href="javascript:void(0)" class="editRoleBtn" data-id="<?php echo e($role->id); ?>">
                                                <i class="fa-solid fa-pen-to-square text-success"></i>
                                            </a>
                                            <a href="javascript:void(0)" class="deleteRoleBtn" data-url="<?php echo e(url('roles/delete/'.$role->id)); ?>">
                                                <i class="fa-solid fa-trash text-danger"></i>
                                            </a>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <!-- Add Role Form -->
                <div class="col-xl-6">
                    <div class="card">
                        <div class="card-header"><h5>Add Role</h5></div>
                        <div class="card-body">
                            <form id="addRoleForm"><?php echo csrf_field(); ?>
                                <div class="row mb-3">
                                    <label class="col-lg-3 form-label">Roles Title</label>
                                    <div class="col-lg-9">
                                        <input type="text" class="form-control" name="roles_title" required>
                                    </div>
                                </div>  
                                <div class="text-end">
                                    <button type="submit" class="btn btn-primary">Submit</button>
                                </div>
                            </form>
                        </div>
                    </div>

                    <!-- Edit Role Modal -->
                    <div class="modal fade" id="editRoleModal" tabindex="-1" aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title">Edit Role</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                </div>
                                <div class="modal-body">
                                    <form id="editRoleForm"><?php echo csrf_field(); ?>
                                        <input type="hidden" id="edit_role_id">
                                        <div class="mb-3">
                                            <label for="edit_roles_title" class="form-label">Role Title</label>
                                            <input type="text" class="form-control" id="edit_roles_title" name="roles_title" required>
                                        </div>
                                        <button type="submit" class="btn btn-primary">Update</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>

                </div><!-- end col -->

            </div>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>
// ================= Add Role =================
$("#addRoleForm").submit(function(e){
    e.preventDefault();
    var formData = $(this).serialize();

    $.post("<?php echo e(url('roles/store')); ?>", formData, function(response){
        Swal.fire({
            icon: 'success',
            title: 'Added!',
            text: 'Role added successfully.'
        }).then(() => location.reload());
    }).fail(function(xhr){
        Swal.fire('Error!', xhr.responseText, 'error');
    });
});

// ================= Edit Role =================
$(document).on("click", ".editRoleBtn", function(){
    var roleId = $(this).data("id");

    $.get("<?php echo e(url('roles/edit')); ?>/" + roleId, function(data){
        $("#edit_role_id").val(data.id);
        $("#edit_roles_title").val(data.roles_title);
        $("#editRoleModal").modal("show");
    });
});

$("#editRoleForm").submit(function(e){
    e.preventDefault();
    var roleId = $("#edit_role_id").val();
    var formData = $(this).serialize();

    $.post("<?php echo e(url('roles/update')); ?>/" + roleId, formData, function(response){
        Swal.fire({
            icon: 'success',
            title: 'Updated!',
            text: 'Role updated successfully.'
        }).then(() => location.reload());
    }).fail(function(xhr){
        Swal.fire('Error!', xhr.responseText, 'error');
    });
});

// ================= Delete Role =================
$(document).on("click", ".deleteRoleBtn", function(e){
    e.preventDefault();
    var deleteUrl = $(this).data("url");

    Swal.fire({
        title: "Are you sure?",
        text: "This role will be permanently deleted!",
        icon: "warning",
        showCancelButton: true,
        confirmButtonText: "Yes, delete it!",
        cancelButtonText: "Cancel"
    }).then((result) => {
        if(result.isConfirmed){
            window.location.href = deleteUrl;
        }
    });
});
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\medical\resources\views/masters/roles.blade.php ENDPATH**/ ?>