

<?php $__env->startSection('content'); ?>
<div class="main-wrapper">
<?php echo $__env->make('include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('include.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="page-wrapper">
    <div class="content pb-0">
        <div class="d-flex align-items-sm-center flex-sm-row flex-column gap-2 mb-3">
                <div class="flex-grow-1">
                    <h4 class="">Therapy Master</h4>
                </div>
                <div class="text-end">
                    <ol class="breadcrumb m-0 py-0">
                        <li class="breadcrumb-item"><a href="<?php echo e(url('dashboard')); ?>">Dashboard</a></li>
                        <li class="breadcrumb-item"><a href="#">Masters</a></li>
                        <li class="breadcrumb-item active">Therapy Master</li>
                    </ol>
                </div>
            </div>
        <div class="row">
            <!-- Table -->
            <div class="col-xl-6">
                <div class="card">
                    <div class="card-header"><h5>Therapy List</h5></div>
                    <div class="card-body">
                        <table class="table">
                            <thead><tr><th>S.NO</th><th>Name</th><th>Action</th></tr></thead>
                            <tbody>
                                <?php $__currentLoopData = $data['therapy']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $therapy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td><?php echo e($therapy->therapy_name); ?></td>
                                    <td>
                                        <a href="javascript:void(0)" class="editTherapyBtn" data-id="<?php echo e($therapy->id); ?>"><i class="fa-solid fa-pen-to-square text-success"></i></a>
                                        <a href="javascript:void(0)" class="deleteTherapyBtn" data-url="<?php echo e(url('therapy/delete/'.$therapy->id)); ?>"><i class="fa-solid fa-trash text-danger"></i></a>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <!-- Add Form -->
            <div class="col-xl-6">
                <div class="card">
                    <div class="card-header"><h5>Add Therapy</h5></div>
                    <div class="card-body">
                        <form id="addTherapyForm"><?php echo csrf_field(); ?>
                            <div class="mb-2">
                                <label>Name</label>
                                <input type="text" name="therapy_name" class="form-control" required>
                            </div>
                            <button type="submit" class="btn btn-primary">Add</button>
                        </form>

                    </div>
                </div>
            </div>
        </div>
        <!-- Edit Therapy Modal -->
        <div class="modal fade" id="editTherapyModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Edit Therapy</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <form id="editTherapyForm">
                <?php echo csrf_field(); ?>
                <input type="hidden" id="edit_therapy_id" name="id">
                <div class="mb-3">
                    <label for="edit_therapy_name" class="form-label">Therapy Name</label>
                    <input type="text" class="form-control" id="edit_therapy_name" name="therapy_name" required>
                </div>
                <button type="submit" class="btn btn-primary">Update</button>
                </form>
            </div>
            </div>
        </div>
        </div>

    </div>
</div>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
$(document).ready(function(){

    // Open Edit Modal
    $(document).on('click', '.editTherapyBtn', function () {
        var id = $(this).data('id');

        // Fetch therapy data
        $.get("<?php echo e(url('therapy/edit')); ?>/" + id, function (data) {
            $("#edit_therapy_id").val(data.id);
            $("#edit_therapy_name").val(data.therapy_name);

            // Show modal
            $("#editTherapyModal").modal("show");
        });
    });

    // Submit Edit Therapy Form
    $("#editTherapyForm").submit(function (e) {
        e.preventDefault();

        var therapyId = $("#edit_therapy_id").val();
        var formData = $(this).serialize();

        $.post("<?php echo e(url('therapy/update')); ?>/" + therapyId, formData, function (response) {
            // Show success alert
            Swal.fire("Updated!", "Therapy updated successfully.", "success")
                .then(() => location.reload());
        }).fail(function (xhr) {
            Swal.fire("Error!", xhr.responseText, "error");
        });
    });

    // Delete Therapy
    $(document).on('click', '.deleteTherapyBtn', function (e) {
        e.preventDefault();
        var url = $(this).data('url');

        Swal.fire({
            title: "Are you sure?",
            text: "This therapy will be permanently deleted!",
            icon: "warning",
            showCancelButton: true,
            confirmButtonColor: "#d33",
            cancelButtonColor: "#3085d6",
            confirmButtonText: "Yes, delete it!"
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = url;
            }
        });
    });
    

});

</script>
<script>
$(document).ready(function(){

    // Add Therapy with SweetAlert
    $("#addTherapyForm").submit(function(e){
        e.preventDefault(); // prevent normal form submission
        var formData = $(this).serialize();

        $.post("<?php echo e(url('therapy/store')); ?>", formData, function(response){
            Swal.fire({
                icon: 'success',
                title: 'Added!',
                text: 'Therapy added successfully.'
            }).then(() => location.reload()); // reload page after success
        }).fail(function(xhr){
            Swal.fire({
                icon: 'error',
                title: 'Error!',
                text: xhr.responseText
            });
        });
    });

});
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\medical\resources\views/masters/therapy.blade.php ENDPATH**/ ?>