
<?php $__env->startSection('content'); ?>
<div class="main-wrapper">
    <?php echo $__env->make('include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('include.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="page-wrapper">
        <div class="content">
            <div class="card shadow-lg rounded-4 p-4 mt-4">
                <h4 class="fw-bold mb-4 text-primary">Edit Emergency Record</h4>

                <form id="editEmergencyForm">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="id" value="<?php echo e($record->id); ?>">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label>Patient</label>
                            <select name="patient_id" class="form-select" required>
                                <option value="">Select Patient</option>
                                <?php $__currentLoopData = $patients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($p->id); ?>" <?php echo e($record->patient_id == $p->id ? 'selected':''); ?>>
                                        <?php echo e($p->reg_no); ?> - <?php echo e($p->name); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="col-md-6">
                            <label>Date</label>
                            <input type="date" name="date" class="form-control" value="<?php echo e($record->date); ?>" required>
                        </div>

                        <div class="col-md-6">
                            <label>Illness</label>
                            <input type="text" name="illness" class="form-control" value="<?php echo e($record->illness); ?>">
                        </div>

                        <div class="col-md-6">
                            <label>Doctor</label>
                            <input type="text" name="doctor" class="form-control" value="<?php echo e($record->doctor); ?>">
                        </div>

                        <div class="col-md-12">
                            <label>Remarks</label>
                            <textarea name="remarks" class="form-control"><?php echo e($record->remarks); ?></textarea>
                        </div>
                    </div>

                    <div class="text-end mt-3">
                        <button type="submit" class="btn btn-primary">💾 Update</button>
                        <a href="<?php echo e(route('emergency.index')); ?>" class="btn btn-secondary">Cancel</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
$('#editEmergencyForm').submit(function(e){
    e.preventDefault();
    let id = $('input[name=id]').val();
    let formData = $(this).serialize();

    $.ajax({
        url: "<?php echo e(url('emergency_call_register')); ?>/" + id + "/update",
        type: "POST",
        data: formData,
        success: function(res){
            Swal.fire('Updated', res.message, 'success')
                 .then(()=> window.location.href="<?php echo e(route('emergency.index')); ?>");
        },
        error: function(xhr){
            let errors = xhr.responseJSON.errors;
            let errMsg = '';
            $.each(errors, function(k,v){ errMsg += v[0] + '<br>'; });
            Swal.fire('Error', errMsg, 'error');
        }
    });
});

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/furniica/public_html/deaddtiction/resources/views/emergencycallregister/edit.blade.php ENDPATH**/ ?>