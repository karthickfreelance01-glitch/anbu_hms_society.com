
<?php $__env->startSection('content'); ?>
<div class="main-wrapper">
    <?php echo $__env->make('include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('include.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="page-wrapper">
        <div class="content">
            <div class="card">
                <div class="card-header">
                    <h4>Add Escape</h4>
                </div>
                <div class="card-body">
                    <form action="<?php echo e(route('escape.store')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>

                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label>Patient</label>
                                <select name="patient_id" id="patient_id" class="form-control" required>
                                    <option value="">Select Patient</option>
                                    <?php $__currentLoopData = $patients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($p->patient_id); ?>" data-name="<?php echo e($p->full_name); ?>">
                                            <?php echo e($p->patient_id); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label>Patient Name</label>
                                <input type="text" id="patient_name" class="form-control" readonly style="background:#dfdede">
                            </div>
                        </div>

                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label>Escape Date & Time</label>
                                <input type="datetime-local" name="escape_datetime" class="form-control" required>
                            </div>

                            <div class="col-md-6">
                                <label>Video Footage (Optional)</label>
                                <input type="file" name="video_footage" class="form-control">
                            </div>
                        </div>

                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label>Police FIR Copy</label>
                                <input type="file" name="police_fir_copy" class="form-control" required>
                            </div>

                            <div class="col-md-6">
                                <label>File Attach (Optional)</label>
                                <input type="file" name="file_attach" class="form-control">
                            </div>
                        </div>

                        <button type="submit" class="btn btn-primary">Save</button>
                        <a href="<?php echo e(route('escape.index')); ?>" class="btn btn-secondary">Back</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>


<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>


<?php if(session('success')): ?>
<script>
    Swal.fire({
        title: "Success!",
        text: "<?php echo e(session('success')); ?>",
        icon: "success",
        confirmButtonText: "OK"
    });
</script>
<?php endif; ?>


<script>
    $('#patient_id').on('change', function() {
        let selected = $(this).find(':selected');
        $('#patient_name').val(selected.data('name') || '');
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\medical\resources\views/escape/create.blade.php ENDPATH**/ ?>