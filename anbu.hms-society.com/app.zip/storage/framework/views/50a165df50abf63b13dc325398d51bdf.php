
<?php $__env->startSection('content'); ?>
<div class="main-wrapper">
    <?php echo $__env->make('include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('include.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="page-wrapper">
        <div class="content pb-0">
            <div class="container-fluid">

                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h3 class="fw-bold text-primary">Expense Reports</h3>
                </div>

                <!-- Filter Form -->
                <div class="card shadow mb-4">
                    <div class="card-body">
                        <form method="GET" action="<?php echo e(route('expenses.reports')); ?>" class="row g-3 align-items-end">
                            <div class="col-md-3">
                                <label class="form-label">From Date</label>
                                <input type="date" name="from_date" class="form-control" value="<?php echo e(request('from_date')); ?>">
                            </div>
                            <div class="col-md-3">
                                <label class="form-label">To Date</label>
                                <input type="date" name="to_date" class="form-control" value="<?php echo e(request('to_date')); ?>">
                            </div>

                            <!-- Main Category -->
                            <div class="col-md-3">
                                <label class="form-label">Expense Main Category</label>
                                <select id="main_category" name="category_id" class="form-select select2" required>
                                    <option value="">-- All Main Categories --</option>
                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($id); ?>" <?php echo e(request('category_id') == $id ? 'selected' : ''); ?>><?php echo e($name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <!-- Subcategory (dependent) -->
                            <div class="col-md-3">
                                <label class="form-label">Expense Subcategory</label>
                                <select id="sub_category" name="sub_category_id" class="form-select select2">
                                    <option value="">-- All Subcategories --</option>
                                    <?php $__currentLoopData = $subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($id); ?>" <?php echo e(request('sub_category_id') == $id ? 'selected' : ''); ?>><?php echo e($name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <!-- Hospital Account -->
                            <div class="col-md-3">
                                <label class="form-label">Hospital Account</label>
                                <select name="hospital_account_id" class="form-select select2">
                                    <option value="">-- All Accounts --</option>
                                    <?php $__currentLoopData = $hospitalAccounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($id); ?>" <?php echo e(request('hospital_account_id') == $id ? 'selected' : ''); ?>><?php echo e($name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <div class="col-md-3 d-flex gap-2">
                                <button type="submit" class="btn btn-primary w-100">Filter</button>
                                <a href="<?php echo e(route('expenses.reports')); ?>" class="btn btn-secondary w-100">Reset</a>
                            </div>
                        </form>
                    </div>
                </div>

                <!-- Overall Total -->
                <div class="card shadow-sm rounded-4 mt-3">
                    <div class="card-body text-end">
                        <h5 class="fw-bold text-success">Overall Total Expenses: ₹ <?php echo e(number_format($totalAmount, 2)); ?></h5>
                    </div>
                </div>

                <!-- Expenses Table Grouped by Main Category -->
                <?php $__empty_1 = true; $__currentLoopData = $groupedExpenses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mainCategory => $expensesList): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="card shadow-lg rounded-4 mb-4">
                        <div class="card-header bg-primary text-white">
                            <h5 class="mb-0"><?php echo e($mainCategory); ?></h5>
                        </div>
                        <div class="card-body table-responsive">
                            <table class="table table-bordered table-striped align-middle">
                                <thead class="table-light">
                                    <tr>
                                        <th>#</th>
                                        <th>Expense Name</th>
                                        <th>Amount (₹)</th>
                                        <th>Date</th>
                                        <th>Hospital Account</th>
                                        <th>Payment Mode</th>
                                        <th>Notes</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $expensesList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $exp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($key + 1); ?></td>
                                            <td><?php echo e($exp->expense_name); ?></td>
                                            <td>₹ <?php echo e(number_format($exp->amount, 2)); ?></td>
                                            <td><?php echo e(\Carbon\Carbon::parse($exp->expense_date)->format('d-m-Y')); ?></td>
                                            <td><?php echo e($exp->hospital_account ?? '-'); ?></td>
                                            <td><?php echo e($exp->payment_mode ?? '-'); ?></td>
                                            <td><?php echo e($exp->notes ?? '-'); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                                <tfoot>
                                    <tr>
                                        <th colspan="2">Total for <?php echo e($mainCategory); ?></th>
                                        <th colspan="5" class="text-success fw-bold">₹ <?php echo e(number_format($expensesList->sum('amount'), 2)); ?></th>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="text-center text-muted py-5">
                        <h6>No expenses found for the selected filters</h6>
                    </div>
                <?php endif; ?>

            </div>
        </div>
    </div>
</div>

<!-- Select2 -->
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet"/>
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<script>
$(document).ready(function(){
    $('.select2').select2({ width: '100%', allowClear: true, placeholder: function(){ return $(this).data('placeholder'); } });

    // Dependent Subcategory
    
    $('#main_category').change(function(){
    let categoryId = $(this).val();
    let $sub = $('#sub_category');
    $sub.html('<option value="">Loading...</option>').trigger('change');

    if(categoryId){
        $.get('<?php echo e(url("expenses/getexpensescategory")); ?>/' + categoryId, function(data){
            let options = '<option value="">-- All Subcategories --</option>';
            data.forEach(function(exp){
                // exp.id and exp.expense_name from your controller
                options += `<option value="${exp.id}">${exp.expense_name}</option>`;
            });
            $sub.html(options).trigger('change');
        }).fail(function(){
            $sub.html('<option value="">-- All Subcategories --</option>').trigger('change');
        });
    } else {
        $sub.html('<option value="">-- All Subcategories --</option>').trigger('change');
    }
});

});
</script>

<style>
.table th { background: #f8f9fa; font-weight: 600; }
.table td { vertical-align: middle; }
</style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/furniica/public_html/deaddtiction/resources/views/expenses/reports.blade.php ENDPATH**/ ?>