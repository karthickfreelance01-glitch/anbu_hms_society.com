

<?php $__env->startSection('content'); ?>
<div class="main-wrapper">
    <?php echo $__env->make('include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('include.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="page-wrapper">
        <div class="content">
            <div class="card shadow-lg rounded-4 p-4 mt-3">
                <div class="card-header">
                    <h4 class="mb-0">Edit Escape Record</h4>
                </div>

                <div class="card-body">
                    
                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul class="mb-0">
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>

                    <form action="<?php echo e(route('escape.update', $escape->id)); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('POST'); ?>

                        <div class="row">
                            <!-- Patient ID -->
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Patient ID</label>
                                <select name="patient_id" id="patient_id" class="form-control" required>
                                    <option value="">-- Select Patient --</option>
                                    <?php $__currentLoopData = $patients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $patient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($patient->id); ?>"
                                            data-name="<?php echo e($patient->name); ?>"
                                            <?php echo e($escape->patient_id == $patient->id ? 'selected' : ''); ?>>
                                            <?php echo e($patient->id); ?> - <?php echo e($patient->reg_no); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <!-- Patient Name -->
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Patient Name</label>
                                <input type="text" id="patient_name" class="form-control" 
                                    value="<?php echo e($escape->patient_name); ?>" readonly style="background:#f3f3f3">
                            </div>

                            <!-- Escape DateTime -->
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Escape Date & Time</label>
                                <div class="input-group">
                                    <input type="date" name="escape_date" class="form-control"
                                        value="<?php echo e(date('Y-m-d', strtotime($escape->escape_datetime))); ?>" required>

                                    <input type="text" name="escape_time" class="form-control"
                                        value="<?php echo e(date('h:i A', strtotime($escape->escape_datetime))); ?>"
                                        placeholder="12:30 PM" required>
                                </div>
                            </div>

                            <!-- Video Footage -->
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Video Footage (Optional)</label>
                                <input type="file" name="video_footage" class="form-control">
                                <?php if($escape->video_footage): ?>
                                    <a href="<?php echo e(asset($escape->video_footage)); ?>" target="_blank" class="d-block mt-2 text-primary">
                                        View Video
                                    </a>
                                <?php endif; ?>
                            </div>

                            <!-- Police FIR Copy -->
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Police FIR Copy</label>
                                <input type="file" name="police_fir_copy" class="form-control">
                                <?php if($escape->police_fir_copy): ?>
                                    <a href="<?php echo e(asset($escape->police_fir_copy)); ?>" target="_blank" class="d-block mt-2 text-primary">
                                        View FIR
                                    </a>
                                <?php endif; ?>
                            </div>

                            <!-- Additional File -->
                            <div class="col-md-6 mb-3">
                                <label class="form-label">File Attachment (Optional)</label>
                                <input type="file" name="file_attach" class="form-control">
                                <?php if($escape->file_attach): ?>
                                    <a href="<?php echo e(asset($escape->file_attach)); ?>" target="_blank" class="d-block mt-2 text-primary">
                                        View File
                                    </a>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="text-end">
                            <button type="submit" class="btn btn-primary">Update</button>
                            <a href="<?php echo e(route('escape.index')); ?>" class="btn btn-secondary">Cancel</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>


<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />


<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>


<?php if(session('success')): ?>
<script>
    Swal.fire({
        title: "Success!",
        text: "<?php echo e(session('success')); ?>",
        icon: "success",
        confirmButtonText: "OK"
    });
</script>
<?php endif; ?>


<script>
$(document).ready(function() {
    $('#patient_id').select2({
        placeholder: 'Select Patient',
        allowClear: true,
        width: '100%'
    });

    $('#patient_id').on('change', function() {
        let name = $(this).find(':selected').data('name');
        $('#patient_name').val(name || '');
    });
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/furniica/public_html/deaddtiction/resources/views/escape/edit.blade.php ENDPATH**/ ?>