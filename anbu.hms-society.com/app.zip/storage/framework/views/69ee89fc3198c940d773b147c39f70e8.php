

<?php $__env->startSection('content'); ?>
<div class="main-wrapper">
    <?php echo $__env->make('include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('include.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="page-wrapper">
        <div class="content pb-0">
            <div class="d-flex align-items-sm-center flex-sm-row flex-column gap-2 pb-3">
                <div class="flex-grow-1">
                    <h4 class="fw-bold mb-0">Expense MainCategory Master</h4>
                </div>
                <div class="text-end">
                    <ol class="breadcrumb m-0 py-0">
                        <li class="breadcrumb-item"><a href="<?php echo e(url('dashboard')); ?>">Dashboard</a></li>
                        <li class="breadcrumb-item"><a href="#">Masters</a></li>
                        <li class="breadcrumb-item active">Expense MainCategory Master</li>
                    </ol>
                </div>
            </div>

            <div class="card">
                <div class="card-header d-flex justify-content-between">
                    <h4>Expense MainCategory List</h4>
                    <button class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#addExpenseModal">
                        <i class="fa-solid fa-plus"></i> Add Expense MainCategory
                    </button>
                </div>
                <div class="card-body">
                    <table class="table table-bordered table-striped" id="expenseTable">
                        <thead>
                            <tr>
                                <th>S.NO</th>
                                <th>Expense MainCategory </th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $expenses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $exp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($index + 1); ?></td>
                                <td><?php echo e($exp->expensescategory); ?></td>
                                <td>
                                    <button class="btn btn-sm btn-success editExpenseBtn" data-id="<?php echo e($exp->id); ?>">
                                        <i class="fa-solid fa-pen-to-square text-white"></i>
                                    </button>
                                    <button class="btn btn-sm btn-danger deleteExpenseBtn" data-id="<?php echo e($exp->id); ?>">
                                        <i class="fa-solid fa-trash text-white"></i>
                                    </button>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>

        </div>
    </div>
</div>

<!-- Add Expense Modal -->
<div class="modal fade" id="addExpenseModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form id="addExpenseForm">
                <?php echo csrf_field(); ?>
                <div class="modal-header">
                    <h5 class="modal-title">Add Expense MainCategory</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label>Name of the Expense MainCategory</label>
                        <input type="text" name="expense_category" class="form-control" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-success">Add</button>
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Edit Expense Modal -->
<div class="modal fade" id="editExpenseModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form id="editExpenseForm">
                <?php echo csrf_field(); ?>
                <input type="hidden" id="edit_expense_id">
                <div class="modal-header">
                    <h5 class="modal-title">Edit Expense MainCategory</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label>Expense MainCategory Name</label>
                        <input type="text" id="edit_expense_name" name="expense_category" class="form-control" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-primary">Update</button>
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Scripts -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>
$(function () {
    // Add Expense
    $("#addExpenseForm").submit(function (e) {
        e.preventDefault();
        $.ajax({
            url: "<?php echo e(route('addexpensescatgory')); ?>",
            method: "POST",
            data: $(this).serialize(),
            success: function (res) {
                if (res.success) {
                    Swal.fire("Success!", res.message, "success").then(() => location.reload());
                } else {
                    Swal.fire("Error!", res.message, "error");
                }
            },
            error: function (xhr) {
                const msg = xhr.responseJSON?.message || "Something went wrong. Please try again.";
                Swal.fire("Error!", msg, "error");
            }
        });
    });

    // Open Edit Modal
    $(document).on("click", ".editExpenseBtn", function () {
        var id = $(this).data("id");
        $.get("<?php echo e(url('expenses-category/edit')); ?>/" + id, function (data) {
            $("#edit_expense_id").val(data.id);
            $("#edit_expense_name").val(data.expensescategory);
            new bootstrap.Modal(document.getElementById("editExpenseModal")).show();
        });
    });

    // Update Expense
    $("#editExpenseForm").submit(function (e) {
        e.preventDefault();
        var id = $("#edit_expense_id").val();
        $.ajax({
            url: "<?php echo e(url('expenses-category/update')); ?>/" + id,
            method: "POST",
            data: $(this).serialize(),
            success: function (res) {
                if (res.success) {
                    Swal.fire("Updated!", res.message, "success").then(() => location.reload());
                } else {
                    Swal.fire("Error!", res.message, "error");
                }
            },
            error: function (xhr) {
                const msg = xhr.responseJSON?.message || "Something went wrong while updating.";
                Swal.fire("Error!", msg, "error");
            }
        });
    });

    // Delete Expense
    $(document).on("click", ".deleteExpenseBtn", function () {
        var id = $(this).data("id");
        Swal.fire({
            title: "Are you sure?",
            text: "This expense MainCategory will be deleted!",
            icon: "warning",
            showCancelButton: true,
            confirmButtonText: "Yes, delete it!"
        }).then((result) => {
            if (result.isConfirmed) {
                $.ajax({
                    url: "<?php echo e(url('expenses-category/delete')); ?>/" + id,
                    method: "DELETE",
                    data: { _token: "<?php echo e(csrf_token()); ?>" },
                    success: function (res) {
                        if (res.success) {
                            Swal.fire("Deleted!", res.message, "success").then(() => location.reload());
                        } else {
                            Swal.fire("Error!", res.message, "error");
                        }
                    },
                    error: function (xhr) {
                        const msg = xhr.responseJSON?.message || "Unable to delete record. Please try again.";
                        Swal.fire("Error!", msg, "error");
                    }
                });
            }
        });
    });
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/furniica/public_html/deaddtiction/resources/views/masters/expensescatgory.blade.php ENDPATH**/ ?>