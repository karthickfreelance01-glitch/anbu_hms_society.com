

<?php $__env->startSection('content'); ?>
<div class="main-wrapper">
    <?php echo $__env->make('include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('include.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="page-wrapper">
        <div class="content pb-0">

            
            <?php if(session('success')): ?>
                <div class="alert alert-success"><?php echo e(session('success')); ?></div>
            <?php endif; ?>

            <?php if(session('error')): ?>
                <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
            <?php endif; ?>

            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul class="mb-0">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            <div class="card shadow-sm">
                <div class="card-header text-white ">
                    <h4 class="mb-0">Edit Admission</h4>
                </div>

                <div class="card-body">
                    <form id="admissionForm" method="POST" action="<?php echo e(route('admissions.update', $admission->id)); ?>">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="row g-3">

                            
                            <div class="col-md-6">
                                <label for="patient_id" class="form-label">Patient</label>
                                <select name="patient_id" id="patient_id" class="form-control select2" required>
                                    <option value="">Select Patient</option>
                                    <?php $__currentLoopData = $patients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $patient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($patient->patient_id); ?>" 
                                            data-name="<?php echo e($patient->full_name); ?>"
                                            <?php echo e($admission->patient_id == $patient->patient_id ? 'selected' : ''); ?>>
                                            <?php echo e($patient->patient_id); ?> - <?php echo e($patient->contact_number); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <div class="col-md-6">
                                <label for="patient_name" class="form-label">Patient Name</label>
                                <input type="text" id="patient_name" class="form-control" readonly style="background:#f8f9fa;" 
                                       value="<?php echo e($admission->patient_name_from_master ?? ''); ?>">
                            </div>

                            
                            <div class="col-md-6">
                                <label for="symptoms_title" class="form-label">Disease Title</label>
                                <select name="symptoms_title" id="symptoms_title" class="form-control" required>
                                    <option value="<?php echo e($admission->symptoms_title); ?>"><?php echo e($admission->symptoms_title); ?></option>
                                    <?php $__currentLoopData = $symptoms->unique('symptoms_title'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $symptom): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($symptom->symptoms_title); ?>"><?php echo e($symptom->symptoms_title); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            
                             <div class="col-md-6">
                                <label for="admission_date" class="form-label">Admission Date</label>
                                <input type="date" id="admission_date" name="admission_date" value="<?php echo e(\Carbon\Carbon::parse($admission->admission_datetime)->format('Y-m-d')); ?>" class="form-control" required min="<?php echo e(date('Y-m-d')); ?>">
                                <small class="form-text text-muted mt-2">
                                    Selected Date: <span id="date-output">YYYY-MM-DD</span>
                                </small>
                            </div>

                            
                            <div class="col-md-6">
                                <label for="ward_no" class="form-label">Ward No</label>
                                <select name="ward_no" class="form-control" required>
                                    <?php $__currentLoopData = $ward; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $w): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($w->ward_no); ?>" <?php echo e($admission->ward_no == $w->ward_no ? 'selected' : ''); ?>><?php echo e($w->ward_no); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            
                            <div class="col-md-6">
                                <label for="doctor_id" class="form-label">Consultant Doctor</label>
                                <select name="doctor_id" class="form-control select2" required>
                                    <option value="">Select Doctor</option>
                                    <?php $__currentLoopData = $doctors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($doc->id); ?>" <?php echo e($admission->consultant_doctor_id == $doc->id ? 'selected' : ''); ?>><?php echo e($doc->staff_name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            
                            <div class="col-md-6">
                                <label for="nurse_id" class="form-label">Consultant Nurse</label>
                                <select name="nurse_id" class="form-control select2" >
                                    <option value="">Select Nurse</option>
                                    <?php $__currentLoopData = $nurses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($n->id); ?>" <?php echo e($admission->consultant_nurse_id == $n->id ? 'selected' : ''); ?>><?php echo e($n->staff_name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            
                            <div class="col-md-6">
                                <label for="therapy" class="form-label">Therapy</label>
                                <select name="therapy[]" class="form-control select2" multiple required>
                                    <?php $__currentLoopData = $therapies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($t->id); ?>" <?php echo e(in_array($t->id, $selectedTherapyIds ?? []) ? 'selected' : ''); ?>><?php echo e($t->therapy_name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            
                            <div class="col-md-6">
                                <label for="duration" class="form-label">Duration (Months)</label>
                                <select name="duration" id="duration" class="form-control" required>
                                    <?php $__currentLoopData = [1,2,3,4,5,6,12]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $month): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($month); ?>" <?php echo e($admission->duration == $month ? 'selected' : ''); ?>><?php echo e($month); ?> Month(s)</option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <div class="col-md-6">
                                <label for="monthly_amount" class="form-label">Monthly Amount</label>
                                <input type="number" name="monthly_amount" id="monthly_amount" class="form-control" value="<?php echo e($admission->monthly_amount); ?>" required>
                            </div>

                            <div class="col-md-6">
                                <label for="total_amount" class="form-label">Total Amount</label>
                                <input type="text" id="total_amount" class="form-control" value="<?php echo e($admission->duration * $admission->monthly_amount); ?>" readonly>
                            </div>

                            
                            <div class="col-md-6">
                                <label for="initial_fees" class="form-label">Initial Amount</label>
                                <input type="number" name="initial_fees" class="form-control" value="<?php echo e($admission->initial_fees); ?>" required>
                            </div>

                            
                            <div class="col-md-6">
                                <label for="payment_mode" class="form-label">Payment Mode</label>
                                <select name="payment_mode" class="form-control" required>
                                    <option value="CASH" <?php echo e($admission->payment_mode == 'CASH' ? 'selected' : ''); ?>>Cash</option>
                                    <option value="CARD" <?php echo e($admission->payment_mode == 'CARD' ? 'selected' : ''); ?>>Card</option>
                                    <option value="ONLINE" <?php echo e($admission->payment_mode == 'ONLINE' ? 'selected' : ''); ?>>Online</option>
                                </select>
                            </div>

                            
                            <div class="col-md-6">
                                <label for="payment_status" class="form-label">Payment Status</label>
                                <select name="payment_status" class="form-control" required>
                                    <option value="PAID" <?php echo e($admission->payment_status == 'PAID' ? 'selected' : ''); ?>>Paid</option>
                                    <option value="PENDING" <?php echo e($admission->payment_status == 'PENDING' ? 'selected' : ''); ?>>Pending</option>
                                </select>
                            </div>

                        </div>

                        <div class="mt-4 text-end">
                            <button type="submit" class="btn btn-success">Update Admission</button>
                        </div>
                    </form>
                </div>
            </div>

        </div>
    </div>
</div>


<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>

<script>
$(document).ready(function(){

    $('.select2').select2({ placeholder: "Select options" });

    $('#patient_id').on('change', function(){
        let selected = $(this).find(':selected');
        $('#patient_name').val(selected.data('name') || '');
    });

    $('#admission_date').on('input', function(){
        let dateVal = $(this).val();
        $('#date-output').text(dateVal || 'YYYY-MM-DD');
    });

    const duration = $('#duration');
    const monthlyAmount = $('#monthly_amount');
    const totalAmount = $('#total_amount');

    function calculateTotal(){
        const months = parseInt(duration.val()) || 0;
        const monthly = parseFloat(monthlyAmount.val()) || 0;
        totalAmount.val((months * monthly).toFixed(2));
    }

    duration.on('change', calculateTotal);
    monthlyAmount.on('input', calculateTotal);

});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/furniica/public_html/deaddtiction/resources/views/admissions/edit.blade.php ENDPATH**/ ?>