

<?php $__env->startSection('content'); ?>
<div class="main-wrapper">
    <?php echo $__env->make('include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('include.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="page-wrapper">
        <div class="content">
            <div class="d-flex justify-content-between mb-3">
                <h4>Dishcharge Report   </h4>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(url('dashboard')); ?>">Dashboard</a></li>
                    <li class="breadcrumb-item active">Dishcharge Report</li>
                </ol>
            </div>
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h4 class="fw-bold">Discharge Report</h4>
                    <a href="<?php echo e(url('discharges/create')); ?>" class="btn btn-primary btn-sm">New Discharge</a>
                </div>

                <div class="card-body">

                    <!-- Filter Form -->
                    <form id="filterForm" class="mb-3">
                        <div class="row">
                            <div class="col-md-3">
                                <input type="date" name="from_date" id="from_date" class="form-control" value="<?php echo e(request('from_date')); ?>">
                            </div>
                            <div class="col-md-3">
                                <input type="date" name="to_date" id="to_date" class="form-control" value="<?php echo e(request('to_date')); ?>">
                            </div>
                            <div class="col-md-2 d-flex">
                                <button type="submit" class="btn btn-primary me-2 w-100">Filter</button>
                                <button type="button" class="btn btn-secondary w-100" id="resetFilter">Reset</button>
                            </div>
                        </div>
                    </form>

                    <!-- Discharge Table -->
                    <div class="table-responsive">
                        <table class="table table-bordered" id="dischargeTable">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Patient ID</th>
                                    <th>Patient Name</th>
                                    <th>Admission Date</th>
                                    <th>Duration</th>
                                    <th>Admission Fees</th>
                                    <th>Therapy</th>
                                    <th>Medicine</th>
                                    <th>Bed</th>
                                    <th>Food</th>
                                    <th>Other</th>
                                    <th>Total Fees</th>
                                    <th>Payment Mode</th>
                                    <th>Payment Status</th>
                                    <th>Bill & Summary</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $discharges; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $discharge): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e($index + 1); ?></td>
                                        <td><?php echo e($discharge->patient_code); ?></td>
                                        <td><?php echo e($discharge->full_name); ?></td>
                                        <td><?php echo e($discharge->admission_datetime); ?></td>
                                        <td><?php echo e($discharge->duration); ?></td>
                                        <td><?php echo e(number_format($discharge->admission_fees,2)); ?></td>
                                        <td><?php echo e(number_format($discharge->therapy_fees,2)); ?></td>
                                        <td><?php echo e(number_format($discharge->medicine_fees,2)); ?></td>
                                        <td><?php echo e(number_format($discharge->bed_fees,2)); ?></td>
                                        <td><?php echo e(number_format($discharge->food_fees,2)); ?></td>
                                        <td><?php echo e(number_format($discharge->other_expenses,2)); ?></td>
                                        <td><?php echo e(number_format($discharge->total_fees,2)); ?></td>
                                        <td><?php echo e($discharge->payment_mode); ?></td>
                                        <td><?php echo e($discharge->payment_status); ?></td>
                                        <td>
                                            <a href="<?php echo e(url('discharges/summary/'.$discharge->id)); ?>" target="_blank" class="btn btn-info btn-sm mb-2">📝 Print Summary</a>
                                            <a href="<?php echo e(url('discharges/bill/'.$discharge->id)); ?>" target="_blank" class="btn btn-primary btn-sm">💰 Print Bill</a>
                                        </td>
                                        <td class="d-flex">
                                            <a href="<?php echo e(url('discharges/edit/'.$discharge->id)); ?>" class="btn btn-sm btn-warning mb-1">
                                                <i class="fa-solid fa-pen-to-square"></i>
                                            </a>
                                            <button class="btn btn-sm btn-danger delete-discharge mb-1" data-id="<?php echo e($discharge->id); ?>">
                                                <i class="fa-solid fa-trash"></i>
                                            </button>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="16" class="text-center">No discharges found.</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>

                </div>
            </div>

        </div>
    </div>
</div>

<!-- jQuery & SweetAlert -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>
$(document).ready(function(){

    // Filter AJAX
    $('#filterForm').submit(function(e){
        e.preventDefault();
        let formData = $(this).serialize();

        $.ajax({
            url: "<?php echo e(url('discharges/filter')); ?>",
            type: "POST",
            data: formData + '&_token=<?php echo e(csrf_token()); ?>',
            success: function(res){
                $('#dischargeTable tbody').html(res.html);
            },
            error: function(err){
                alert('Failed to fetch discharges.');
                console.error(err);
            }
        });
    });

    // Reset filter
    $('#resetFilter').click(function(){
        $('#from_date').val('');
        $('#to_date').val('');
        $('#filterForm').submit(); // Trigger filter form to reload today discharges
    });

    // Delete discharge
    $(document).on('click', '.delete-discharge', function(){
        let id = $(this).data('id');

        Swal.fire({
            title: 'Are you sure?',
            text: "This discharge record will be deleted!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, delete it!'
        }).then((result) => {
            if(result.isConfirmed){
                $.ajax({
                    url: "<?php echo e(url('discharges/delete')); ?>/" + id,
                    type: 'DELETE',
                    data: {_token:'<?php echo e(csrf_token()); ?>'},
                    success: function(response){
                        Swal.fire('Deleted!', response.message, 'success').then(() => location.reload());
                    },
                    error: function(){ Swal.fire('Error!', 'Failed to delete record', 'error'); }
                });
            }
        });
    });

});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\medical\resources\views/discharges/index.blade.php ENDPATH**/ ?>