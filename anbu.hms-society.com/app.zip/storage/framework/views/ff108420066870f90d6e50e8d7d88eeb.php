

<?php $__env->startSection('content'); ?>
<div class="main-wrapper">
    <?php echo $__env->make('include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('include.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="page-wrapper">
        <div class="content pb-0">

            <!-- Page Header -->
            <div class="d-flex justify-content-between mb-3">
                <h4>Patient Master</h4>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(url('dashboard')); ?>">Dashboard</a></li>
                    <li class="breadcrumb-item active">Patient Report</li>
                </ol>
            </div>

            <!-- Filter Form -->
            <div class="card mb-3">
                <div class="card-body">
                    <form id="filterForm">
                        <div class="row">
                            <div class="col-md-3">
                                <label for="from_date">From Date</label>
                                <input type="date" id="from_date" name="from_date" value="<?php echo e($data['from_date']); ?>" class="form-control">
                            </div>
                            <div class="col-md-3">
                                <label for="to_date">To Date</label>
                                <input type="date" id="to_date" name="to_date" value="<?php echo e($data['to_date']); ?>" class="form-control">
                            </div>
                            <div class="col-md-2 d-flex align-items-end">
                                <button type="button" class="btn btn-secondary w-100" onclick="resetFilter()">Reset</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Patient Table -->
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h4 class="mb-0">Patient List</h4>
                    <a href="<?php echo e(url('patient/create')); ?>" class="btn btn-primary btn-sm">Add Patient</a>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered ">
                            <thead class="table-light">
                                <tr>
                                    <th>#</th>
                                    <th>Patient ID</th>
                                    <th>Full Name</th>
                                    <th>DOB / Age</th>
                                    <th>Gender</th>
                                    <th>Contact</th>
                                    <th>Emergency Contact</th>
                                    <th>Documents</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody id="patientTableBody">
                                <?php $__empty_1 = true; $__currentLoopData = $data['patient']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $patient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($patient->patient_id); ?></td>
                                        <td><?php echo e($patient->full_name); ?></td>
                                        <td><?php echo e($patient->dob); ?> / <?php echo e($patient->age); ?></td>
                                        <td><?php echo e($patient->gender); ?></td>
                                        <td><?php echo e($patient->contact_number); ?></td>
                                        <td><?php echo e($patient->emergency_name); ?> - <?php echo e($patient->emergency_number); ?></td>
                                        <td>
                                            <?php if($patient->aadhaar_file): ?>
                                                <a href="<?php echo e(asset($patient->aadhaar_file)); ?>" target="_blank">Aadhaar</a><br>
                                            <?php endif; ?>
                                            <?php if($patient->emergency_proof): ?>
                                                <a href="<?php echo e(asset($patient->emergency_proof)); ?>" target="_blank">Emergency Proof</a><br>
                                            <?php endif; ?>
                                            <?php if($patient->medical_reports): ?>
                                                <?php $__currentLoopData = json_decode($patient->medical_reports); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <a href="<?php echo e(asset($report)); ?>" target="_blank">Report</a><br>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                        </td>
                                        <td class="d-flex">
                                            <a href="<?php echo e(url('patient/edit', $patient->id)); ?>" class="btn btn-sm btn-white">
                                                <i class="fa-solid fa-pen-to-square text-success"></i>
                                            </a>
                                            <a href="javascript:void(0)" class="deletepatientBtn btn btn-sm btn-white" data-url="<?php echo e(url('patients/delete/'.$patient->id)); ?>">
                                                <i class="fa-solid fa-trash text-danger"></i>
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="9" class="text-center">No patients found.</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>

<!-- Scripts -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>
$(document).ready(function(){

    function fetchPatients() {
        var from_date = $('#from_date').val();
        var to_date = $('#to_date').val();

        $.ajax({
            url: "<?php echo e(route('patient_view')); ?>",
            type: "GET",
            data: { from_date: from_date, to_date: to_date },
            dataType: "json",
            success: function(response) {
                $('#patientTableBody').html(response.html);
                bindDeleteButtons(); // re-bind delete buttons
            }
        });

    }

    // Trigger AJAX on date change
    $('#from_date, #to_date').on('change', function(){
        fetchPatients();
    });

    // Reset filter
    window.resetFilter = function() {
        $('#from_date').val('');
        $('#to_date').val('');
        fetchPatients();
    }

    // SweetAlert delete
    function bindDeleteButtons() {
        $('.deletepatientBtn').off('click').on('click', function(e){
            e.preventDefault();
            var url = $(this).data('url');

            Swal.fire({
                title: "Are you sure?",
                text: "This Patient will be permanently deleted!",
                icon: "warning",
                showCancelButton: true,
                confirmButtonColor: "#d33",
                cancelButtonColor: "#3085d6",
                confirmButtonText: "Yes, delete it!"
            }).then((result) => {
                if(result.isConfirmed){
                    window.location.href = url;
                }
            });
        });
    }

    bindDeleteButtons(); // Initial binding

});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\medical\resources\views/patient/patient_reports.blade.php ENDPATH**/ ?>