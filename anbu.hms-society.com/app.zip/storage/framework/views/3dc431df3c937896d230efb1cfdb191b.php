
<?php $__env->startSection('content'); ?>

<style>
.page-wrapper { background: #f0f2f5; min-height: 100vh; padding: 20px; }
.staff-card { 
    background: #fff; border-radius: 12px; box-shadow: 0 4px 15px rgba(0,0,0,0.05); 
    padding: 15px; margin-bottom: 15px; display: flex; justify-content: space-between; align-items: center;
    transition: transform 0.2s, box-shadow 0.2s; width: 100%;
}
.staff-card:hover { transform: translateY(-3px); box-shadow: 0 8px 25px rgba(0,0,0,0.1); }
.staff-name { font-weight: 600; font-size: 1rem; color: #1f2937; }
.status-btns { display: flex; gap: 8px; }
.status-btns button { width: 38px; height: 38px; border-radius: 50%; border: none; font-weight: 600; color: #fff; cursor: pointer; transition: all 0.2s; position: relative; }
.status-btns button:hover { transform: scale(1.1); }
.status-btns button.active::after { content: '✔'; position: absolute; right: -5px; bottom: -5px; background: #000; width: 18px; height: 18px; border-radius: 50%; font-size: 12px; text-align: center; line-height: 18px; color: #fff; }
.status-present { background: #10b981; }
.status-absent { background: #ef4444; }
.status-leave { background: #f59e0b; }
.status-half { background: #3b82f6; }
.staff-list { max-height: 70vh; overflow-y: auto; }
.save-btn { border-radius: 8px; font-weight: 600; padding: 8px 30px; }
.search-box { margin-bottom: 15px; max-width: 300px; }
</style>

<div class="main-wrapper">
    <?php echo $__env->make('include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('include.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="page-wrapper">
        <div class="content">
            <?php if(session('success')): ?>
                <div class="alert alert-success"><?php echo e(session('success')); ?></div>
            <?php endif; ?>

            <h3 class="mb-4 text-dark">Staff Attendance - <?php echo e(\Carbon\Carbon::parse($today)->format('d-m-Y')); ?></h3>

            <!-- Search box -->
            <input type="text" id="staffSearch" class="form-control search-box" placeholder="Search Staff Name...">

            <form action="<?php echo e(route('attendance.bulkStore')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="attendance_date" value="<?php echo e($today); ?>">
                <div class="staff-list" id="staffList">
                    <?php $__currentLoopData = $staff; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $st): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $status = $attendance[$st->id] ?? ''; ?>
                    <div class="staff-card" data-staff-id="<?php echo e($st->id); ?>">
                        <div class="staff-name"><?php echo e($st->staff_name); ?></div>
                        <div class="status-btns">
                            <button type="button" class="status-present <?php echo e($status=='Present' ? 'active' : ''); ?>" data-status="Present">P</button>
                            <button type="button" class="status-absent <?php echo e($status=='Absent' ? 'active' : ''); ?>" data-status="Absent">A</button>
                            <button type="button" class="status-half <?php echo e($status=='Half Day' ? 'active' : ''); ?>" data-status="Half Day">H</button>
                        </div>
                        <input type="hidden" name="attendance[<?php echo e($st->id); ?>]" value="<?php echo e($status); ?>">
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <div class="mt-4 text-end">
                    <button type="submit" class="btn btn-primary save-btn">Save Attendance</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
$(function(){
    // Handle status button click
    $('.status-btns button').click(function(){
        var parent = $(this).closest('.staff-card');
        parent.find('.status-btns button').removeClass('active');
        $(this).addClass('active');
        parent.find('input[type=hidden]').val($(this).data('status'));
    });

    // Staff search filter
    $('#staffSearch').on('keyup', function(){
        var search = $(this).val().toLowerCase();
        $('#staffList .staff-card').each(function(){
            var name = $(this).find('.staff-name').text().toLowerCase();
            $(this).toggle(name.indexOf(search) > -1);
        });
    });
});
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/hmssocie/public_html/iyengaran.hms-society.com/resources/views/attendance/mark.blade.php ENDPATH**/ ?>