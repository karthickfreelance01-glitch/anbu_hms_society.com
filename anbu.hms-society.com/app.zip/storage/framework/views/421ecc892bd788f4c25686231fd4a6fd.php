<!DOCTYPE html>
<html>
<head>
    <title>Patient Bill</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 30px; }
        .header { text-align: center; border-bottom: 2px solid #000; padding-bottom: 10px; margin-bottom: 20px; }
        .title { font-size: 22px; font-weight: bold; text-align: center; margin-bottom: 20px; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        table, th, td { border: 1px solid black; }
        th, td { padding: 10px; text-align: left; }
        .total { font-weight: bold; text-align: right; }
        .footer { margin-top: 50px; text-align: right; }
    </style>
</head>
<body>
    <div class="header">
        <h2>🏥 Hospital Name</h2>
        <p>Address, City, Phone</p>
    </div>

    <div class="title">Patient Bill</div>

    <p><strong>Patient Name:</strong> <?php echo e($discharge->patient_name); ?></p>
    <p><strong>Patient ID:</strong> <?php echo e($discharge->patient_id); ?></p>
    <p><strong>Discharge Date:</strong> <?php echo e($discharge->created_at); ?></p>

    <table>
        <tr>
            <th>Particulars</th>
            <th>Amount (₹)</th>
        </tr>
        <tr>
            <td>Room Charges</td>
            <td><?php echo e($discharge->bed_fees); ?></td>
        </tr>
        <tr>
            <td>Doctor Fees</td>
            <td><?php echo e($discharge->admission_fees); ?></td>
        </tr>
        <tr>
            <td>Food Charges</td>
            <td><?php echo e($discharge->food_fees); ?></td>
        </tr>
        <tr>
            <td>Other Expenses</td>
            <td><?php echo e($discharge->other_expenses); ?></td>
        </tr>
        <tr>
            <td class="total">Total</td>
            <td class="total"><?php echo e($discharge->total_fees); ?></td>
        </tr>
    </table>

    <div class="footer">
        <p>Authorized Signature ___________________</p>
    </div>

    <script>
        window.print();
    </script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\medical\resources\views/discharges/print_bill.blade.php ENDPATH**/ ?>