<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Hospital Bill - <?php echo e($bill->patient_name); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { font-family: 'DejaVu Sans', sans-serif; background: #fff; color: #000; font-size: 14px; }
        .bill-container { max-width: 800px; margin: 30px auto; border: 1px solid #ccc; padding: 30px; border-radius: 10px; }
        .bill-header { text-align: center; border-bottom: 2px solid #198754; padding-bottom: 10px; margin-bottom: 20px; }
        .bill-header h4 { margin: 0; color: #198754; font-weight: bold; }
        .bill-header p { margin: 0; font-size: 13px; }
        .table th, .table td { vertical-align: middle; }
        .amount-summary td { font-weight: bold; }
        .footer-note { margin-top: 30px; text-align: center; font-size: 13px; color: #666; }
        @media print {
            .no-print { display: none; }
            body { background: white; }
        }
    </style>
</head>
<body>
<div class="bill-container">
    <div class="bill-header">
        <img src="<?php echo e(asset('assets/img/logo.jpg')); ?>" width="10%">
        <h4>Aara Care Foundation</h4>
        <p>No.05, C.P.T.Complex, S.K.Nagar Seelanaickenpatti, Opp.Dharan Hospital, Salem-636201 
            <br>PH: 9487676111, Email: aaracarefoundation2022@gmail.com</p>
        <p><strong>Patient Invoice</strong></p>
    </div>

    <div class="row mb-3">
        <div class="col-md-6">
            <p><strong>Patient Name:</strong> <?php echo e($bill->patient_name); ?></p>
            <p><strong>IP Number:</strong> <?php echo e($bill->ip_number); ?></p>
        </div>
        <div class="col-md-6 text-end">
            <p><strong>Bill Date:</strong> <?php echo e(\Carbon\Carbon::parse($bill->bill_date)->format('d-m-Y')); ?></p>
            <p><strong>Bill No:</strong> <?php echo e($bill->bill_id); ?></p>
        </div>
    </div>

    <table class="table table-bordered">
        <thead class="table-success">
            <tr>
                <th>#</th>
                <th>Category</th>
                <th>Amount (₹)</th>
                <th>Received (₹)</th>
                <th>Pending (₹)</th>
                <th>Payment Mode</th>
                <th>Date</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $billingRecords; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($index + 1); ?></td>
                    <td><?php echo e(ucfirst(str_replace('_', ' ', $item->category))); ?></td>
                    <td>₹<?php echo e(number_format($item->amount, 2)); ?></td>
                    <td>₹<?php echo e(number_format($item->received_amount, 2)); ?></td>
                    <td>₹<?php echo e(number_format($item->amount - $item->received_amount, 2)); ?></td>
                    <td><?php echo e($item->payment_mode ?? '-'); ?></td>
                    <td><?php echo e(\Carbon\Carbon::parse($item->created_at)->format('d-m-Y')); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <table class="table amount-summary">
        <tr><td>Total Amount</td><td class="text-end">₹<?php echo e(number_format($bill->total_amount, 2)); ?></td></tr>
        <tr><td>Total Received</td><td class="text-end text-success">₹<?php echo e(number_format($bill->total_received, 2)); ?></td></tr>
        <tr><td>Total Pending</td><td class="text-end text-danger">₹<?php echo e(number_format($bill->total_pending, 2)); ?></td></tr>
    </table>

    <div class="footer-note">
        <p>Thank you for choosing Aara Care Foundation. Wishing you a speedy recovery!</p>
        <button class="btn btn-success no-print" onclick="window.print()">🖨 Print Bill</button>
        <a href="<?php echo e(url('patient/billing/reports')); ?>" class="btn btn-secondary no-print">⬅ Back</a>
    </div>
</div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\gjcare\resources\views/patient/bill_view.blade.php ENDPATH**/ ?>