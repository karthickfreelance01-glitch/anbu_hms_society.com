

<?php $__env->startSection('content'); ?>
<div class="main-wrapper">
    <?php echo $__env->make('include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('include.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="page-wrapper">
        <div class="content">
            <div class="card">
                <div class="card-header">
                    <h4>Add Escape</h4>
                </div>
                <div class="card-body">
                    <form action="<?php echo e(route('escape.store')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>

                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label>Patient</label>
                                <select name="patient_id" id="patient_id" class="form-control" required>
                                    <option value="">Select Patient</option>
                                    <?php $__currentLoopData = $patients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($p->id); ?>" data-name="<?php echo e($p->reg_no); ?>">
                                            <?php echo e($p->id); ?> - <?php echo e($p->reg_no); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label>Patient Name</label>
                                <input type="text" id="patient_name" class="form-control" readonly style="background:#dfdede">
                            </div>
                        </div>

                        <div class="row mb-3">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Escape Date & Time</label>
                                <div class="input-group">
                                    <input type="date" name="escape_date" class="form-control" required>
                                    <input type="text" name="escape_time" class="form-control" required placeholder="12:30 PM">
                                </div>
                            </div>

                            <div class="col-md-6">
                                <label>Video Footage (Optional)</label>
                                <input type="file" name="video_footage" class="form-control">
                            </div>
                        </div>

                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label>Police FIR Copy</label>
                                <input type="file" name="police_fir_copy" class="form-control" required>
                            </div>

                            <div class="col-md-6">
                                <label>File Attach (Optional)</label>
                                <input type="file" name="file_attach" class="form-control">
                            </div>
                        </div>
                        <div class="text-end">
                            <button type="submit" class="btn btn-primary">Save</button>
                            <a href="<?php echo e(route('escape.index')); ?>" class="btn btn-secondary">Back</a>
                        </div>
                        
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>


<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />


<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>


<?php if(session('success')): ?>
<script>
    Swal.fire({
        title: "Success!",
        text: "<?php echo e(session('success')); ?>",
        icon: "success",
        confirmButtonText: "OK"
    });
</script>
<?php endif; ?>


<script>
$(document).ready(function() {
    $('#patient_id').select2({
        placeholder: 'Select Patient',
        allowClear: true,
        width: '100%'
    });

    $('#patient_id').on('change', function() {
        let selected = $(this).find(':selected');
        $('#patient_name').val(selected.data('name') || '');
    });
});
</script>
<script>
$(document).ready(function(){

    // Populate Hours (01 to 12)
    for(let i = 1; i <= 12; i++){
        $('#hour').append(`<option value="${i<10 ? '0'+i : i}">${i<10 ? '0'+i : i}</option>`);
    }

    // Populate Minutes (00 to 59)
    for(let i = 0; i < 60; i++){
        $('#minute').append(`<option value="${i<10 ? '0'+i : i}">${i<10 ? '0'+i : i}</option>`);
    }

    function to24Hour(hour, ampm){
        hour = parseInt(hour);
        if(ampm === 'AM'){
            if(hour === 12) hour = 0;
        } else {
            if(hour !== 12) hour += 12;
        }
        return hour < 10 ? '0' + hour : hour;
    }

    function updateDatetime(){
        const dateVal = $('#date').val();
        const hourVal = $('#hour').val();
        const minuteVal = $('#minute').val();
        const ampmVal = $('#ampm').val();

        if(dateVal && hourVal && minuteVal && ampmVal){
            const hour24 = to24Hour(hourVal, ampmVal);
            const datetime = `${dateVal}T${hour24}:${minuteVal}`;
            $('#admissionDatetime').val(datetime);
            $('#date-output').text(dateVal);
            $('#time-output').text(`${hourVal}:${minuteVal} ${ampmVal}`);
        }
    }

    $('#date, #hour, #minute, #ampm').on('change', updateDatetime);

});
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/furniica/public_html/deaddtiction/resources/views/escape/create.blade.php ENDPATH**/ ?>