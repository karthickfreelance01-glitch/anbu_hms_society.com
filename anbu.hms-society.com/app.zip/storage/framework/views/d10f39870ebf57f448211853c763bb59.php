<?php
use Carbon\Carbon;
?>


<?php $__env->startSection('content'); ?>
<div class="main-wrapper">
    <?php echo $__env->make('include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('include.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="page-wrapper">
        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12 col-md-8">
                        <div class="card shadow-sm border-0 rounded-4 p-3">
                            <div class="card-header d-flex justify-content-between align-items-center">
                                <h4 class="mb-0 fw-bold text-primary">Patient Bill Reports</h4>
                            </div>

                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-bordered table-striped table-hover" id="billingTable">
                                        <thead class="table-light">
                                            <tr>
                                                <th>#</th>
                                                <th>IP Number</th>
                                                <th>Patient Name</th>
                                                <th>Date of Admission</th>
                                                <th>Calculated Amount (₹)</th>
                                                <th>Received (₹)</th>
                                                <th>Pending (₹)</th>
                                                <th>Payment Mode</th>
                                                <th>View Details</th>
                                                <th>Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php
                                                    $admissionDate = \Carbon\Carbon::parse($bill->date_of_admission);
                                                ?>
                                                <tr>
                                                    <td><?php echo e($loop->iteration); ?></td>
                                                    <td><?php echo e($bill->ip_number); ?></td>
                                                    <td><?php echo e($bill->name); ?></td>
                                                    <td><?php echo e($admissionDate->format('d-m-Y')); ?></td>
                                            
                                                    <td>
                                                        ₹<?php echo e(number_format($bill->monthly_amount, 2)); ?> × <?php echo e($bill->months_stayed); ?> mo
                                                        <?php if($bill->extra_days > 0): ?>
                                                            + <?php echo e($bill->extra_days); ?> days 
                                                            (₹<?php echo e(number_format($bill->extra_days_amount, 2)); ?>)
                                                        <?php endif; ?>
                                                        <br>
                                                        <strong>Total: ₹<?php echo e(number_format($bill->total_amount, 2)); ?></strong>
                                                    </td>
                                            
                                                    <td>₹<?php echo e(number_format($bill->received_total, 2)); ?></td>
                                            
                                                    <td class="<?php echo e($bill->pending_amount > 0 ? 'text-danger fw-bold' : 'text-success fw-bold'); ?>">
                                                        ₹<?php echo e(number_format($bill->pending_amount, 2)); ?>

                                                    </td>
                                            
                                                    <td><?php echo e($bill->payment_mode ?? '—'); ?></td>
                                            
                                                    <td>
                                                        <button class="btn btn-info btn-sm"
                                                                onclick="showPaymentHistoryModal('<?php echo e($bill->name); ?>', '<?php echo e($bill->ip_number); ?>', '<?php echo e($bill->payments ?? '[]'); ?>')">
                                                            View
                                                        </button>
                                                    </td>
                                            
                                                    <td>
                                                        <button class="btn btn-success btn-sm"
                                                                onclick="showAddPaymentModal(<?php echo e($bill->patient_id); ?>, <?php echo e($bill->pending_amount); ?>)">
                                                            Add
                                                        </button>
                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- ✅ Add Payment Modal -->
<div class="modal fade" id="addPaymentModal" tabindex="-1">
    <div class="modal-dialog">
        <form id="paymentForm">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="patient_id" id="modal_patient_id">
            <input type="hidden" id="modal_pending_amount">
            <div class="modal-content rounded-4 shadow-lg">
                <div class="modal-header bg-success text-white">
                    <h5 class="modal-title">Add Payment</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body p-4">
                    <div class="mb-3">
                        <label class="form-label fw-bold">Received Amount (₹)</label>
                        <input type="number" step="0.01" name="received_amount" id="received_amount" class="form-control" required>
                        <small class="text-muted">Max allowed: ₹<span id="maxPendingText">0.00</span></small>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold">Payment Date</label>
                        <input type="date" name="payment_date" class="form-control" required value="<?php echo e(date('Y-m-d')); ?>">
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold">Payment Mode</label>
                        <select name="payment_mode" class="form-select" required>
                            <option value="">-- Select Mode --</option>
                            <option value="Cash">Cash</option>
                            <option value="Card">Card</option>
                            <option value="UPI">UPI</option>
                            <option value="NetBanking">Net Banking</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold">Remarks</label>
                        <input type="text" name="remarks" class="form-control" placeholder="Enter remarks (optional)">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-success px-4">Save Payment</button>
                    <button type="button" class="btn btn-secondary px-4" data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </form>
    </div>
</div>

<!-- ✅ Payment History Modal -->
<div class="modal fade" id="paymentHistoryModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content rounded-4 shadow-lg">
            <div class="modal-header bg-info text-white">
                <h5 class="modal-title">Payment History</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="mb-3">
                    <h6 id="patientDetails" class="fw-bold text-primary"></h6>
                </div>
                <div class="table-responsive">
                    <table class="table table-bordered" id="historyTable">
                        <thead class="table-light">
                            <tr>
                                <th>#</th>
                                <th>Amount (₹)</th>
                                <th>Payment Date</th>
                                <th>Mode</th>
                                <th>Remarks</th>
                                <th>Print</th>
                            </tr>
                        </thead>
                        <tbody id="historyBody"></tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- ✅ Printable Hospital Bill Template -->
<div id="printTemplate" style="display:none;">
    <div style="font-family:'Segoe UI',Arial; padding:25px; border:1px solid #ccc; border-radius:10px;">
        <div style="text-align:center;">
            <img src="<?php echo e(asset('assets/img/logo.jpg')); ?>" alt="Logo" style="height:80px;">
            <h2 style="margin:5px 0;color:#007bff;">AARA CARE HOSPITAL</h2>
            p>No.05, C.P.T.Complex, S.K.Nagar Seelanaickenpatti, Opp.Dharan Hospital, Salem-636201 
            <br>PH: 9487676111, Email: aaracarefoundation2022@gmail.com</p>
        </div>
        <hr style="border:1px solid #007bff;margin:15px 0;">
        <h4 style="text-align:center;text-decoration:underline;">Payment Receipt</h4>
        <table style="width:100%;margin-top:10px;font-size:15px;">
            <tr>
                <td><strong>Patient Name:</strong></td>
                <td id="printPatientName"></td>
                <td><strong>IP Number:</strong></td>
                <td id="printIpNumber"></td>
            </tr>
            <tr>
                <td><strong>Payment Date:</strong></td>
                <td id="printDate"></td>
                <td><strong>Payment Mode:</strong></td>
                <td id="printMode"></td>
            </tr>
            <tr>
                <td><strong>Amount Paid (₹):</strong></td>
                <td colspan="3" id="printAmount" style="font-weight:bold;font-size:16px;color:#28a745;"></td>
            </tr>
            <tr>
                <td><strong>Remarks:</strong></td>
                <td colspan="3" id="printRemarks"></td>
            </tr>
        </table>
        <hr style="border:1px dashed #aaa;margin:15px 0;">
        <div style="margin-top:40px;display:flex;justify-content:space-between;font-size:14px;">
            <div>
                <p>__________________________<br><strong>Authorized Signature</strong></p>
            </div>
            <div style="text-align:right;">
                <p><strong>Date:</strong> <span id="todayDate"></span></p>
            </div>
        </div>
        <hr style="border:1px solid #007bff;">
        <p style="text-align:center;font-size:13px;margin:5px 0;">Thank you for choosing <strong>AARA CARE HOSPITAL</strong>. Wishing you good health!</p>
    </div>
</div>

<!-- ✅ Scripts -->
<link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">
<link rel="stylesheet" href="https://cdn.datatables.net/buttons/2.4.1/css/buttons.dataTables.min.css">
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.1/js/dataTables.buttons.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.1/js/buttons.html5.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.1/js/buttons.print.min.js"></script>

<script>
$(document).ready(function(){
    $('#billingTable').DataTable({
        buttons: ['copy', 'csv', 'excel', 'pdf', 'print'],
        order: [[3,'desc']],
        dom: "<'row mb-3'<'col-sm-6'f><'col-sm-6 text-end'B>>" +
             "<'row'<'col-sm-12'tr>>" +
             "<'row mt-3'<'col-sm-5'i><'col-sm-7'p>>",
        pageLength: 10
    });
});

// ✅ Show Add Payment Modal
function showAddPaymentModal(patientId, pendingAmount){
    $('#modal_patient_id').val(patientId);
    $('#modal_pending_amount').val(pendingAmount);
    $('#maxPendingText').text(pendingAmount.toFixed(2));
    $('#received_amount').val('');
    $('#addPaymentModal').modal('show');
}

// ✅ Limit input
$(document).on('input', '#received_amount', function(){
    let maxPending = parseFloat($('#modal_pending_amount').val()) || 0;
    let entered = parseFloat($(this).val()) || 0;
    if(entered > maxPending){
        Swal.fire({
            icon: 'warning',
            title: 'Limit Exceeded',
            text: `You cannot enter more than ₹${maxPending.toFixed(2)}`
        });
        $(this).val(maxPending.toFixed(2));
    }
});

// ✅ Show Payment History Modal
function showPaymentHistoryModal(patientName, ipNumber, paymentsJson){
    let payments = [];
    if(paymentsJson){
        payments = JSON.parse(paymentsJson.replace(/&quot;/g,'"'));
    }
    let tbody = '';
    payments.forEach((p,index)=>{
        tbody += `<tr>
                    <td>${index+1}</td>
                    <td>₹${parseFloat(p.amount).toFixed(2)}</td>
                    <td>${p.date}</td>
                    <td>${p.mode}</td>
                    <td>${p.remarks ?? ''}</td>
                    <td><button class="btn btn-outline-primary btn-sm" onclick="printBill('${patientName}','${ipNumber}','${p.amount}','${p.date}','${p.mode}','${p.remarks ?? ''}')">Print Bill</button></td>
                  </tr>`;
    });
    $('#historyBody').html(tbody);
    $('#patientDetails').text(`Patient: ${patientName} | IP No: ${ipNumber}`);
    $('#paymentHistoryModal').modal('show');
}

// ✅ Print Bill (Hospital Style)
function printBill(patientName, ipNumber, amount, date, mode, remarks){
    $('#printPatientName').text(patientName);
    $('#printIpNumber').text(ipNumber);
    $('#printDate').text(date);
    $('#printAmount').text(parseFloat(amount).toFixed(2));
    $('#printMode').text(mode);
    $('#printRemarks').text(remarks);
    $('#todayDate').text(new Date().toLocaleDateString());

    let printWindow = window.open('', '_blank', 'width=800,height=600');
    printWindow.document.write('<html><head><title>Payment Receipt</title>');
    printWindow.document.write('<style>body{font-family:Arial;margin:0;padding:20px;background:#f9f9f9;} hr{border:1px solid #007bff;} table td{padding:6px 8px;vertical-align:top;} </style>');
    printWindow.document.write('</head><body>');
    printWindow.document.write($('#printTemplate').html());
    printWindow.document.write('</body></html>');
    printWindow.document.close();
    printWindow.print();
}

// ✅ Handle Add Payment Form
$('#paymentForm').submit(function(e){
    e.preventDefault();
    let maxPending = parseFloat($('#modal_pending_amount').val()) || 0;
    let entered = parseFloat($('#received_amount').val()) || 0;

    if(entered > maxPending){
        Swal.fire({
            icon:'error',
            title:'Invalid Amount',
            text:`You cannot enter more than ₹${maxPending.toFixed(2)}`
        });
        return;
    }

    $.ajax({
        url: "<?php echo e(url('billing/add-payment')); ?>",
        method: "POST",
        data: $(this).serialize(),
        success: function(res){
            Swal.fire({ icon:'success', title:'Payment Added', text:res.message }).then(()=>location.reload());
        },
        error: function(xhr){
            Swal.fire({ icon:'error', title:'Error', text:xhr.responseText });
        }
    });
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\gjcare\resources\views/patient/patient_bills.blade.php ENDPATH**/ ?>