
<?php $__env->startSection('content'); ?>
<div class="main-wrapper">
    <?php echo $__env->make('include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('include.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="page-wrapper">
        <div class="content pb-0">
            <div class="container-fluid">

                <div class="card shadow-lg rounded-4 p-4 mt-4">
                    <h3 class="card-title text-center mb-4 text-success fw-bold">Patient Billing Form</h3>

                    <form id="billingForm">
                        <?php echo csrf_field(); ?>

                        <!-- Select Patient -->
                        <div class="row g-3 mb-4">
                            <div class="col-md-4">
                                <label class="form-label">Patient</label>
                                <select name="patient_id" id="patient_id" class="form-select" required>
                                    <option value="">Select Patient</option>
                                    <?php $__currentLoopData = $patients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($pat->id); ?>"><?php echo e($pat->reg_no); ?> - <?php echo e($pat->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <div class="col-md-4">
                                <label class="form-label">Reg. No</label>
                                <input type="text" id="reg_no" class="form-control" readonly>
                            </div>

                            <div class="col-md-4">
                                <label class="form-label">Patient Name</label>
                                <input type="text" id="patient_name" class="form-control" readonly>
                            </div>
                        </div>

                        <!-- Total & Initial Payment -->
                        <div class="row mb-4">
                            <div class="col-md-4">
                                <label class="form-label fw-bold">Total Bill Amount (₹)</label>
                                <input type="number" id="total_bill" name="total_bill" class="form-control fw-bold text-primary" placeholder="Enter total bill" required>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label fw-bold">Initial Payment (₹)</label>
                                <input type="number" id="initial_payment" name="initial_payment" class="form-control fw-bold text-success" value="0">
                            </div>
                            <div class="col-md-4">
                                <label class="form-label fw-bold">Pending Amount (₹)</label>
                                <input type="text" id="pending_amount" class="form-control fw-bold text-danger" readonly>
                            </div>
                        </div>

                        <!-- Bill Date & Payment Mode -->
                        <div class="row mb-4">
                            <div class="col-md-6">
                                <label class="form-label fw-bold">Bill Date</label>
                                <input type="date" id="bill_date" name="bill_date" class="form-control" required>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label fw-bold">Payment Mode</label>
                                <select name="payment_mode" id="payment_mode" class="form-select" required>
                                    <option value="">Select Payment Mode</option>
                                    <option value="cash">Cash</option>
                                    <option value="card">Card</option>
                                    <option value="upi">UPI</option>
                                    <option value="net_banking">Net Banking</option>
                                </select>
                            </div>
                        </div>

                        <!-- Hospital Payment Category -->
                        <div class="row mb-4">
                            <div class="col-md-6">
                                <label class="form-label fw-bold">Hospital Payment Category</label>
                                <select name="payment_category" id="payment_category" class="form-select" required>
                                    <option value="">Select Category</option>
                                    <?php $__currentLoopData = $payment_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($category->payment_category); ?>"><?php echo e($category->payment_category); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>

                        <!-- Billing Table -->
                        <table class="table table-bordered align-middle" id="billingTable">
                            <thead class="table-light">
                                <tr>
                                    <th style="width:5%">S.No</th>
                                    <th style="width:60%">Bill Item</th>
                                    <th style="width:25%">Amount (₹)</th>
                                    <th style="width:10%">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td class="text-center">1</td>
                                    <td><input type="text" name="bill_title[]" class="form-control" required></td>
                                    <td><input type="number" name="amount[]" class="form-control amount" step="0.01" required></td>
                                    <td class="text-center">
                                        <button type="button" class="btn btn-danger btn-sm removeRow">X</button>
                                    </td>
                                </tr>
                            </tbody>
                        </table>

                        <div class="text-end mb-3">
                            <button type="button" class="btn btn-secondary btn-sm" id="addRow">+ Add Row</button>
                        </div>

                        <div class="text-center">
                            <button type="submit" class="btn btn-success btn-lg px-5 shadow">Save Bill</button>
                        </div>
                    </form>
                </div>

            </div>
        </div>
    </div>
</div>

<!-- Scripts -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
$(document).ready(function () {
    let rowCount = 1;

    // Auto-fill patient details
    $('#patient_id').change(function(){
        let patientId = $(this).val();
        if(patientId){
            $.ajax({
                url: "<?php echo e(url('admissions/get-details/')); ?>/" + patientId,
                method: "GET",
                success:function(res){
                    $('#reg_no').val(res.reg_no);
                    $('#patient_name').val(res.name);
                }
            });
        }
    });

    // Add new row
    $('#addRow').click(function(){
        rowCount++;
        let row = `<tr>
            <td class="text-center">${rowCount}</td>
            <td><input type="text" name="bill_title[]" class="form-control" required></td>
            <td><input type="number" name="amount[]" class="form-control amount" step="0.01" required></td>
            <td class="text-center"><button type="button" class="btn btn-danger btn-sm removeRow">X</button></td>
        </tr>`;
        $('#billingTable tbody').append(row);
    });

    // Remove row
    $(document).on('click', '.removeRow', function(){
        $(this).closest('tr').remove();
    });

    // Calculate pending amount (only total - initial)
    $(document).on('input', '#total_bill, #initial_payment', function(){
        let totalBill = parseFloat($('#total_bill').val()) || 0;
        let initialPayment = parseFloat($('#initial_payment').val()) || 0;
        let pending = totalBill - initialPayment;
        $('#pending_amount').val(pending.toFixed(2));
    });

    // Submit Form
    $('#billingForm').submit(function(e){
        e.preventDefault();
        $.ajax({
            url: "<?php echo e(route('billing.store')); ?>",
            method: "POST",
            data: $(this).serialize(),
            success:function(res){
                Swal.fire({ icon: 'success', title: 'Bill Saved!', text: res.message })
                .then(()=> location.reload());
            },
            error:function(xhr){
                Swal.fire({ icon: 'error', title: 'Error!', text: xhr.responseText });
            }
        });
    });
});
</script>

<style>
.card { border: none; border-radius: 15px; box-shadow: 0 8px 20px rgba(0,0,0,0.15); }
.form-label { font-weight: 600; color: #444; }
.btn-success { background: linear-gradient(135deg,#1cc88a,#28a745); border: none; }
</style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\deaddtiction\resources\views/patient/patient_bills.blade.php ENDPATH**/ ?>