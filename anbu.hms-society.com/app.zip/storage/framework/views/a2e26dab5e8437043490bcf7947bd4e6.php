
<?php $__env->startSection('content'); ?>
<div class="main-wrapper">
    <?php echo $__env->make('include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('include.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="page-wrapper">
        <div class="content">
            <div class="d-flex justify-content-between mb-3">
                <h4>Billing List</h4>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(url('dashboard')); ?>">Dashboard</a></li>
                    <li class="breadcrumb-item active">Billing</li>
                </ol>
            </div>

            <div class="card mb-3">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <h4>Billing List</h4>
                        <a href="<?php echo e(route('billing.create')); ?>" class="btn btn-primary">Add Billing</a>
                    </div>

                    <!-- Filters -->
                    <form id="filterForm" class="row g-2 mb-3">
                        <div class="col-md-2">
                            <label>From Date</label>
                            <input type="date" id="from_date" class="form-control">
                        </div>
                        <div class="col-md-2">
                            <label>To Date</label>
                            <input type="date" id="to_date" class="form-control">
                        </div>
                        <div class="col-md-2">
                            <label>Patient ID</label>
                            <input type="text" id="patient_id" class="form-control" placeholder="Patient ID">
                        </div>
                        <div class="col-md-3">
                            <label>Patient Name</label>
                            <input type="text" id="patient_name" class="form-control" placeholder="Patient Name">
                        </div>
                        <div class="col-md-2">
                            <label>Contact No</label>
                            <input type="text" id="contact_no" class="form-control" placeholder="Contact No">
                        </div>
                        <div class="col-md-1 d-flex align-items-end">
                            <button type="button" id="resetFilter" class="btn btn-secondary w-100">
                                <i class="fa-solid fa-rotate-right"></i>
                            </button>
                        </div>
                    </form>

                    <!-- Table -->
                    <div class="table-responsive">
                        <table class="table table-bordered" id="billingTable">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Patient ID</th>
                                    <th>Patient Name</th>
                                    <th>Contact No</th>
                                    <th>Doctor Name</th>
                                    <th>Doctor Fees</th>
                                    <th>Medication Fees</th>
                                    <th>Extra Charge</th>
                                    <th>Total Bill</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody id="billingTableBody">
                                <?php $__empty_1 = true; $__currentLoopData = $billings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e($bill->id); ?></td>
                                        <td><?php echo e($bill->patient_id); ?></td>
                                        <td><?php echo e($bill->patient_name); ?></td>
                                        <td><?php echo e($bill->contact_number); ?></td>
                                        <td><?php echo e($bill->doctor_name); ?></td>
                                        <td><?php echo e($bill->doctor_fees); ?></td>
                                        <td><?php echo e($bill->medication_fees); ?></td>
                                        <td><?php echo e($bill->extra_charge); ?></td>
                                        <td><?php echo e($bill->total_bill); ?></td>
                                        <td>
                                            <a href="<?php echo e(route('billing.edit',$bill->id)); ?>" class="btn btn-sm btn-warning mb-1"><i class="fa-solid fa-pen-to-square"></i></a>
                                            <form action="<?php echo e(route('billing.destroy',$bill->id)); ?>" method="POST" style="display:inline;">
                                                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                                <button class="btn btn-sm btn-danger" onclick="return confirm('Delete this billing?')"><i class="fa-solid fa-trash"></i></button>
                                            </form>
                                            <a href="<?php echo e(route('billing.print',$bill->id)); ?>" target="_blank" class="btn btn-sm btn-info mt-1"><i class="fa-solid fa-print"></i> Print</a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>

                </div>
            </div>

        </div>
    </div>
</div>

<!-- JS -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
$(function(){
    function fetchBillings(){
        var data = {
            from_date: $('#from_date').val(),
            to_date: $('#to_date').val(),
            patient_id: $('#patient_id').val(),
            patient_name: $('#patient_name').val(),
            contact_no: $('#contact_no').val()
        };

        $.ajax({
            url: "<?php echo e(route('billing.reports')); ?>",
            type: "GET",
            data: data,
            dataType: "json",
            success: function(response){
                if(response.html !== undefined){
                    $('#billingTableBody').html(response.html);
                } else {
                    alert('Invalid server response');
                }
            },
            error: function(xhr){
                console.error(xhr.responseText);
                alert('Failed to fetch billing records');
            }
        });
    }

    // Filters change
    $('#from_date, #to_date, #patient_id, #patient_name, #contact_no').on('change keyup', fetchBillings);

    // Reset
    $('#resetFilter').on('click', function(){
        $('#filterForm')[0].reset();
        fetchBillings();
    });
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/furniica/public_html/deaddtiction/resources/views/billing/billing_reports.blade.php ENDPATH**/ ?>