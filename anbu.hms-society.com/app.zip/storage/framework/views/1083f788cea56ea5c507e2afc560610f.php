

<?php $__env->startSection('content'); ?>
<div class="main-wrapper">
<?php echo $__env->make('include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('include.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="page-wrapper">
    <div class="content pb-0">
        <div class="d-flex justify-content-between mb-3">
            <h4>Medicine  Master</h4>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="http://localhost/medical/public/dashboard">Dashboard</a></li>
                <li class="breadcrumb-item"><a href="#">Masters</a></li>
                <li class="breadcrumb-item active">Medicine Master</li>
            </ol>
        </div>
        <div class="row">
           
            <!-- Add Form -->
            <div class="col-xl-12">
                <div class="card">
                    <div class="card-header"><h5>Add Medicine</h5></div>
                    <div class="card-body">
                        <!-- Add Form -->
                        <form id="addMedicineForm"><?php echo csrf_field(); ?>
                            <div class="mb-2">
                                <label>Name</label>
                                <input type="text" name="medicine_name" class="form-control" required>
                            </div>
                            <div class="mb-2">
                                <label>Dosage</label>
                                <input type="text" name="medicine_dosage" class="form-control" required>
                            </div>
                            <div class="mb-2">
                                <label>Brand</label>
                                <input type="text" name="medicine_brand" class="form-control" required>
                            </div>
                            <div class="mb-2">
                                <label>Disease</label>
                                <input type="text" name="medicine_disease" class="form-control" required>
                            </div>
                           <div class="mb-2">
                                <label>Medicine Type</label>
                                <select name="medicine_type" class="form-control" required>
                                    <option value="">-- Select Type --</option>
                                    <option value="Tablet">Tablet</option>
                                    <option value="Capsule">Capsule</option>
                                    <option value="Syrup">Syrup</option>
                                    <option value="Injection">Injection</option>
                                    <option value="Ointment">Ointment</option>
                                    <option value="Drops">Drops</option>
                                    <option value="Powder">Powder</option>
                                    <option value="Inhaler">Inhaler</option>
                                </select>
                            </div>

                            <button type="submit" class="btn btn-primary">Add</button>
                        </form>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>



<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>
$(document).ready(function(){

   

    // Open Edit Modal
   $(document).on('click', '.editMedicineBtn', function () {
    var id = $(this).data('id');

    $.get("<?php echo e(url('medicine/edit')); ?>/" + id, function(data){
        $("#edit_medicine_id").val(data.id);
        $("#edit_medicine_name").val(data.medicine_name);
        $("#edit_medicine_dosage").val(data.medicine_dosage);
        $("#edit_medicine_brand").val(data.medicine_brand);
        $("#edit_medicine_disease").val(data.medicine_disease);
        $("#edit_medicine_type").val(data.medicine_type);

        $("#editMedicineModal").modal('show');
    });
});


    // Submit Edit Form
    $("#editMedicineForm").submit(function(e){
        e.preventDefault();
        var id = $("#edit_medicine_id").val();
        var formData = $(this).serialize();

        $.post("<?php echo e(url('medicine/update')); ?>/" + id, formData, function(response){
            Swal.fire("Updated!", "Medicine updated successfully.", "success")
                .then(() => location.reload());
        }).fail(function(xhr){
            Swal.fire("Error!", xhr.responseText, "error");
        });
    });

    // Delete Medicine
    $(document).on('click', '.deleteMedicineBtn', function(e){
        e.preventDefault();
        var url = $(this).data('url');
        Swal.fire({
            title:"Are you sure?",
            text:"This medicine will be deleted!",
            icon:"warning",
            showCancelButton:true,
            confirmButtonColor:"#d33",
            cancelButtonColor:"#3085d6",
            confirmButtonText:"Yes, delete it!"
        }).then((result)=>{
            if(result.isConfirmed){
                window.location.href = url;
            }
        });
    });

});

// Add Medicine with SweetAlert
$("#addMedicineForm").submit(function(e){
    e.preventDefault(); // Prevent normal form submission

    var formData = $(this).serialize(); // Serialize form data

    $.post("<?php echo e(url('medicine/store')); ?>", formData, function(response){
        Swal.fire({
            icon: 'success',
            title: 'Added!',
            text: 'Medicine added successfully.'
        }).then(() => {
            // Redirect to medicine list page
            window.location.href = "<?php echo e(url('medicine')); ?>";
        });
    }).fail(function(xhr){
        Swal.fire({
            icon: 'error',
            title: 'Error!',
            text: xhr.responseText
        });
    });
});
   

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/furniica/public_html/deaddtiction/resources/views/masters/medicine_add.blade.php ENDPATH**/ ?>