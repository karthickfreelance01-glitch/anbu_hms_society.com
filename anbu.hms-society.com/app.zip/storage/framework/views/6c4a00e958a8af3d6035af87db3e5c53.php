
<?php $__env->startSection('content'); ?>
<div class="main-wrapper">
    <?php echo $__env->make('include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('include.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="page-wrapper">
        <div class="content pb-0">
            <div class="container-fluid">

                <h3 class="text-primary fw-bold mb-4">Edit Medicine</h3>

                <div class="card shadow-lg rounded-4 p-4">
                    <form action="<?php echo e(route('medicine.update', $medicine->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="form-label">Drug Name</label>
                                <input type="text" name="drug_name" class="form-control" value="<?php echo e($medicine->drug_name); ?>" required>
                            </div>

                            <div class="col-md-6">
                                <label class="form-label">Category</label>
                                <select name="category_id" class="form-select select2" required>
                                    <option value="">-- Select Category --</option>
                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($id); ?>" <?php echo e($medicine->category_id == $id ? 'selected' : ''); ?>><?php echo e($name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <div class="col-md-6">
                                <label class="form-label">Manufactured Date</label>
                                <input type="date" name="manufactured_date" class="form-control" value="<?php echo e($medicine->manufactured_date); ?>" required>
                            </div>

                            <div class="col-md-6">
                                <label class="form-label">Expiry Date</label>
                                <input type="date" name="expiry_date" class="form-control" value="<?php echo e($medicine->expiry_date); ?>" required>
                            </div>

                            <div class="col-md-6">
                                <label class="form-label">Price (₹)</label>
                                <input type="number" step="0.01" name="price" id="price" class="form-control" value="<?php echo e($medicine->price); ?>" required>
                            </div>

                            <div class="col-md-6">
                                <label class="form-label">Selling Price (₹)</label>
                                <input type="number" step="0.01" name="selling_price" id="selling_price" class="form-control" value="<?php echo e($medicine->selling_price); ?>" readonly>
                            </div>

                            <div class="col-12 mt-3">
                                <button type="submit" class="btn btn-primary">Update Medicine</button>
                                <a href="<?php echo e(route('medicine.index')); ?>" class="btn btn-secondary">Cancel</a>
                            </div>
                        </div>
                    </form>
                </div>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    $('.select2').select2({ width: '100%' });

    $('#price').on('input', function() {
        let price = parseFloat($(this).val()) || 0;
        $('#selling_price').val((price * 1.25).toFixed(2));
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/furniica/public_html/deaddtiction/resources/views/medicine/edit.blade.php ENDPATH**/ ?>