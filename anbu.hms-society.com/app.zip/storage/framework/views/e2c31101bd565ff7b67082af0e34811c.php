
<?php $__env->startSection('content'); ?>
<div class="main-wrapper">
    <?php echo $__env->make('include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('include.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="page-wrapper">
        <div class="content pb-0">
            <div class="container-fluid">

                <h3 class="text-primary fw-bold mb-4">Re-enter Stock</h3>

                <div class="card shadow-lg rounded-4 p-4">
                    <form action="<?php echo e(route('medicine.stock.update', $medicine->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="form-label">Drug Name</label>
                                <input type="text" class="form-control" value="<?php echo e($medicine->drug_name); ?>" readonly>
                            </div>

                            <div class="col-md-6">
                                <label class="form-label">Current Stock</label>
                                <input type="number" class="form-control" value="<?php echo e($medicine->current_stock); ?>" readonly>
                            </div>

                            <div class="col-md-6">
                                <label class="form-label">Add Stock</label>
                                <input type="number" name="stock" class="form-control" value="0" required>
                            </div>

                            <div class="col-12 mt-3">
                                <button type="submit" class="btn btn-success">Update Stock</button>
                                <a href="<?php echo e(route('medicine.index')); ?>" class="btn btn-secondary">Cancel</a>
                            </div>
                        </div>
                    </form>
                </div>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/furniica/public_html/deaddtiction/resources/views/medicine/stock.blade.php ENDPATH**/ ?>