
<?php $__env->startSection('content'); ?>
<div class="main-wrapper">
    <?php echo $__env->make('include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('include.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="page-wrapper">
        <div class="content">
            <div class="d-flex justify-content-between mb-3">
                <h4>Escape Register List</h4>
                <a href="<?php echo e(route('escape.create')); ?>" class="btn btn-primary">Add Escape</a>
            </div>

            <!-- Filter -->
            <div class="card mb-3">
                <div class="card-body">
                    <form id="filterForm" class="row g-2">
                        <div class="col-md-2">
                            <label for="from_date">From Date</label>
                            <input type="date" id="from_date" name="from_date" class="form-control">
                        </div>
                        <div class="col-md-2">
                            <label for="to_date">To Date</label>
                            <input type="date" id="to_date" name="to_date" class="form-control">
                        </div>
                        <div class="col-md-2">
                            <label for="patient_id">Patient ID</label>
                            <input type="text" id="patient_id" name="patient_id" class="form-control" placeholder="Patient ID">
                        </div>
                        <div class="col-md-3">
                            <label for="patient_name">Patient Name</label>
                            <input type="text" id="patient_name" name="patient_name" class="form-control" placeholder="Patient Name">
                        </div>
                        <div class="col-md-2">
                            <label for="contact_no">Contact No</label>
                            <input type="text" id="contact_no" name="contact_no" class="form-control" placeholder="Contact No">
                        </div>
                        <div class="col-md-1 d-flex align-items-end">
                            <button type="button" class="btn btn-secondary w-100" id="resetFilter">Reset</button>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Table -->
            <div class="card">
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered" id="escapeRegisterTable">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Patient ID</th>
                                    <th>Patient Name</th>
                                    <th>Contact No</th>
                                    <th>Escape Date & Time</th>
                                    <th>Video</th>
                                    <th>Police FIR</th>
                                    <th>File Attach</th>
                                    <th>Actions</th>
                                </tr>
                                </thead>

                                <tbody id="escapeTableBody">
                                <?php $__empty_1 = true; $__currentLoopData = $escapes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $escape): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($escape->id); ?></td>
                                    <td><?php echo e($escape->patient_code ?? '-'); ?></td>
                                    <td><?php echo e($escape->full_name ?? '-'); ?></td>
                                    <td><?php echo e($escape->contact_number ?? '-'); ?></td>
                                    <td><?php echo e(\Carbon\Carbon::parse($escape->escape_datetime)->format('d-m-Y H:i')); ?></td>
                                    <td>
                                        <?php if($escape->video_footage): ?>
                                            <a href="<?php echo e(asset($escape->video_footage)); ?>" target="_blank">View Video</a>
                                        <?php else: ?> N/A <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if($escape->police_fir_copy): ?>
                                            <a href="<?php echo e(asset($escape->police_fir_copy)); ?>" target="_blank">View FIR</a>
                                        <?php else: ?> N/A <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if($escape->file_attach): ?>
                                            <a href="<?php echo e(asset($escape->file_attach)); ?>" target="_blank">View File</a>
                                        <?php else: ?> N/A <?php endif; ?>
                                    </td>
                                    <td>
                                        <a href="<?php echo e(route('escape.edit', $escape->id)); ?>" class="btn btn-sm btn-warning"><i class="fa-solid fa-pen-to-square"></i></a>
                                        <form id="delete-form-<?php echo e($escape->id); ?>" action="<?php echo e(route('escape.destroy', $escape->id)); ?>" method="POST" style="display:inline;">
                                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                            <button type="button" class="btn btn-sm btn-danger deleteEscapeBtn" data-id="<?php echo e($escape->id); ?>">
                                                <i class="fa-solid fa-trash"></i>
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr><td colspan="9" class="text-center">No records found</td></tr>
                                <?php endif; ?>
                                </tbody>

                        </table>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>

<!-- JS -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>
$(function(){
    function fetchEscapes() {
        var data = {
            from_date: $('#from_date').val(),
            to_date: $('#to_date').val(),
            patient_id: $('#patient_id').val(),
            patient_name: $('#patient_name').val(),
            contact_no: $('#contact_no').val()
        };
        $.get("<?php echo e(url('escape/reports')); ?>", data, function(response){
            if(response.html) $('#escapeTableBody').html(response.html);
        });
    }

    $('#from_date, #to_date, #patient_id, #patient_name, #contact_no').on('change keyup', fetchEscapes);
    $('#resetFilter').on('click', function(){
        $('#filterForm')[0].reset();
        fetchEscapes();
    });

    $(document).on('click', '.deleteEscapeBtn', function(){
        var id = $(this).data('id');
        Swal.fire({
            title: "Are you sure?",
            text: "This record will be permanently deleted!",
            icon: "warning",
            showCancelButton: true,
            confirmButtonText: "Yes, delete it!"
        }).then((result)=>{
            if(result.isConfirmed) $('#delete-form-'+id).submit();
        });
    });
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/furniica/public_html/deaddtiction/resources/views/escape/reports.blade.php ENDPATH**/ ?>