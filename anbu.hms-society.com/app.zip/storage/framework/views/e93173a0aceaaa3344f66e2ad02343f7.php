

<?php $__env->startSection('content'); ?>
<div class="main-wrapper">
<?php echo $__env->make('include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('include.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="page-wrapper">
    <div class="content pb-0">
        <div class="d-flex justify-content-between mb-3">
                <h4>Medicine  Master</h4>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="http://localhost/medical/public/dashboard">Dashboard</a></li>
                     <li class="breadcrumb-item"><a href="#">Masters</a></li>
                    <li class="breadcrumb-item active">Medicine Master</li>
                </ol>
            </div>
        <div class="row">
            <!-- Table -->
            <div class="col-xl-6">
                <div class="card">
                    <div class="card-header">
                        <h5>Medicine List</h5>
                    </div>
                    <div class="card-body">
                        <table class="table">
                            <thead>
                                <tr><th>S.NO</th><th>Name</th><th>Dosage</th><th>Action</th></tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $data['medicine']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $med): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td><?php echo e($med->medicine_name); ?></td>
                                    <td><?php echo e($med->medicine_dosage); ?></td>
                                    <td>
                                        <a href="javascript:void(0)" class="editMedicineBtn" data-id="<?php echo e($med->id); ?>"><i class="fa-solid fa-pen-to-square text-success"></i></a>
                                        <a href="javascript:void(0)" class="deleteMedicineBtn" data-url="<?php echo e(url('medicine/delete/'.$med->id)); ?>"><i class="fa-solid fa-trash text-danger"></i></a>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <!-- Add Form -->
            <div class="col-xl-6">
                <div class="card">
                    <div class="card-header"><h5>Add Medicine</h5></div>
                    <div class="card-body">
                        <!-- Add Form -->
                        <form id="addMedicineForm"><?php echo csrf_field(); ?>
                            <div class="mb-2">
                                <label>Name</label>
                                <input type="text" name="medicine_name" class="form-control" required>
                            </div>
                            <div class="mb-2">
                                <label>Dosage</label>
                                <input type="text" name="medicine_dosage" class="form-control" required>
                            </div>
                            <button type="submit" class="btn btn-primary">Add</button>
                        </form>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Edit Modal -->
<div class="modal fade" id="editMedicineModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Edit Medicine</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <form id="editMedicineForm">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" id="edit_medicine_id" name="id">
                    <div class="mb-3">
                        <label for="edit_medicine_name" class="form-label">Name</label>
                        <input type="text" class="form-control" id="edit_medicine_name" name="medicine_name" required>
                    </div>
                    <div class="mb-3">
                        <label for="edit_medicine_dosage" class="form-label">Dosage</label>
                        <input type="text" class="form-control" id="edit_medicine_dosage" name="medicine_dosage" required>
                    </div>
                    <button type="submit" class="btn btn-primary">Update</button>
                </form>
            </div>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>
$(document).ready(function(){

   

    // Open Edit Modal
    $(document).on('click', '.editMedicineBtn', function () {
        var id = $(this).data('id');
        $.get("<?php echo e(url('medicine/edit')); ?>/" + id, function(data){
            $("#edit_medicine_id").val(data.id);
            $("#edit_medicine_name").val(data.medicine_name);
            $("#edit_medicine_dosage").val(data.medicine_dosage);
            $("#editMedicineModal").modal('show');
        });
    });

    // Submit Edit Form
    $("#editMedicineForm").submit(function(e){
        e.preventDefault();
        var id = $("#edit_medicine_id").val();
        var formData = $(this).serialize();

        $.post("<?php echo e(url('medicine/update')); ?>/" + id, formData, function(response){
            Swal.fire("Updated!", "Medicine updated successfully.", "success")
                .then(() => location.reload());
        }).fail(function(xhr){
            Swal.fire("Error!", xhr.responseText, "error");
        });
    });

    // Delete Medicine
    $(document).on('click', '.deleteMedicineBtn', function(e){
        e.preventDefault();
        var url = $(this).data('url');
        Swal.fire({
            title:"Are you sure?",
            text:"This medicine will be deleted!",
            icon:"warning",
            showCancelButton:true,
            confirmButtonColor:"#d33",
            cancelButtonColor:"#3085d6",
            confirmButtonText:"Yes, delete it!"
        }).then((result)=>{
            if(result.isConfirmed){
                window.location.href = url;
            }
        });
    });

});

// Add Medicine with SweetAlert
$("#addMedicineForm").submit(function(e){
    e.preventDefault(); // Prevent normal form submission

    var formData = $(this).serialize(); // Serialize form data

    $.post("<?php echo e(url('medicine/store')); ?>", formData, function(response){
        Swal.fire({
            icon: 'success',
            title: 'Added!',
            text: 'Medicine added successfully.'
        }).then(() => location.reload()); // Reload after success
    }).fail(function(xhr){
        Swal.fire({
            icon: 'error',
            title: 'Error!',
            text: xhr.responseText
        });
    });
});

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\medical\resources\views/masters/medicine.blade.php ENDPATH**/ ?>