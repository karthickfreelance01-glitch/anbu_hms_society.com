

<?php $__env->startSection('content'); ?>
<div class="main-wrapper">
    <?php echo $__env->make('include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('include.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="page-wrapper">
        <div class="content pb-0">
            <div class="d-flex justify-content-between mb-3">
                <h4>Symptoms Master</h4>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="http://localhost/medical/public/dashboard">Dashboard</a></li>
                     <li class="breadcrumb-item"><a href="#">Masters</a></li>
                    <li class="breadcrumb-item active">Symptoms</li>
                </ol>
            </div>

            <div class="row">
                <!-- Symptoms Table -->
                <div class="col-xl-6">
                    <div class="card">
                        <div class="card-header"><h5>Symptoms List</h5></div>
                        <div class="card-body">
                            <table class="table table-nowrap">
                                <thead>
                                    <tr>
                                        <th>S.NO</th>
                                        <th>Type</th>
                                        <th>Title</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $data['symptoms']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $symptom): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($symptom->symptoms_type); ?></td>
                                        <td><?php echo e($symptom->symptoms_title); ?></td>
                                        <td>
                                            <a href="javascript:void(0)" class="editSymptomBtn" data-id="<?php echo e($symptom->id); ?>"><i class="fa-solid fa-pen-to-square text-success"></i></a>
                                            <a href="javascript:void(0)" class="deleteSymptomBtn" data-url="<?php echo e(url('symptoms/delete/'.$symptom->id)); ?>"><i class="fa-solid fa-trash text-danger"></i></a>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <!-- Add Symptoms Form -->
                <div class="col-xl-6">
                    <div class="card">
                        <div class="card-header"><h5>Add Symptom</h5></div>
                        <div class="card-body">
                            <form id="addSymptomsForm"><?php echo csrf_field(); ?>
                                <div class="mb-2">
                                    <label>Type</label>
                                    <select name="symptoms_type" class="form-control" required>
                                        <option value="">Select Type</option>
                                        <option value="Physical">Physical problem</option>
                                        <option value="Mental">Mental problem</option>
                                    </select>
                                </div>
                                <div class="mb-2">
                                    <label>Title</label>
                                    <input type="text" name="symptoms_title" class="form-control" required>
                                </div>
                                <button type="submit" class="btn btn-primary">Add</button>
                            </form>

                        </div>
                    </div>

                    <!-- Edit Modal -->
                    <div class="modal fade" id="editSymptomModal" tabindex="-1">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5>Edit Symptom</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                </div>
                                <div class="modal-body">
                                    <form id="editSymptomForm">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" id="edit_symptom_id" name="id">
                                        <div class="mb-2">
                                            <label>Type</label>
                                            <select id="edit_symptoms_type" name="symptoms_type" class="form-control"></select>
                                        </div>
                                        <div class="mb-2">
                                            <label>Title</label>
                                            <input type="text" id="edit_symptoms_title" name="symptoms_title" class="form-control">
                                        </div>
                                        <button type="submit" class="btn btn-primary">Update</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>

        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
$(document).on('click', '.editSymptomBtn', function(){
    var id = $(this).data('id');
    $.get("<?php echo e(url('symptoms/edit')); ?>/"+id, function(data){
        $("#edit_symptom_id").val(data.id);
        $("#edit_symptoms_type").html('<option value="Physical" '+(data.symptoms_type=='Physical'?'selected':'')+'>Physical problem</option><option value="Mental" '+(data.symptoms_type=='Mental'?'selected':'')+'>Mental problem</option>');
        $("#edit_symptoms_title").val(data.symptoms_title);
        $("#editSymptomModal").modal('show');
    });
});

// Submit update form via AJAX with SweetAlert
$("#editSymptomForm").submit(function (e) {
    e.preventDefault();

    var symptomId = $("#edit_symptom_id").val();
    var formData = $(this).serialize();

    $.post("<?php echo e(url('symptoms/update')); ?>/" + symptomId, formData, function (response) {
        Swal.fire("Updated!", "Symptom updated successfully.", "success")
            .then(() => location.reload()); // reload page after success
    }).fail(function (xhr) {
        Swal.fire("Error!", xhr.responseText, "error");
    });
});


$(document).on('click', '.deleteSymptomBtn', function(e){
    e.preventDefault();
    var url = $(this).data('url');
    Swal.fire({title:"Are you sure?",text:"Delete this symptom?",icon:"warning",showCancelButton:true,confirmButtonText:"Yes"}).then((result)=>{if(result.isConfirmed){window.location.href=url;}});
});
</script>
<script>
$(document).ready(function(){

    // Add Symptoms with SweetAlert
    $("#addSymptomsForm").submit(function(e){
        e.preventDefault(); // prevent normal form submission
        var formData = $(this).serialize();

        $.post("<?php echo e(url('symptoms/store')); ?>", formData, function(response){
            Swal.fire({
                icon: 'success',
                title: 'Added!',
                text: 'Symptoms added successfully.'
            }).then(() => location.reload()); // reload page after success
        }).fail(function(xhr){
            Swal.fire({
                icon: 'error',
                title: 'Error!',
                text: xhr.responseText
            });
        });
    });

});
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\medical\resources\views/masters/symptoms.blade.php ENDPATH**/ ?>