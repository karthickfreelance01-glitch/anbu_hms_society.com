

<?php $__env->startSection('content'); ?>
<div class="main-wrapper">
    <?php echo $__env->make('include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('include.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="page-wrapper">
        <div class="content pb-0">
            <div class="container-fluid">

                <!-- Header -->
                <div class="d-flex justify-content-between mb-3">
                    <h4>Doctor Notes Reports</h4>
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(url('dashboard')); ?>">Dashboard</a></li>
                        <li class="breadcrumb-item active">Doctor Notes</li>
                    </ol>
                </div>

                <!-- Table Card -->
                <div class="card shadow-lg">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h4 class="mb-0">Doctor Notes List</h4>
                        <a href="<?php echo e(route('doctornotes.create')); ?>" class="btn btn-outline-primary btn-sm">
                            <i class="fas fa-plus-circle me-1"></i> Add
                        </a>
                    </div>

                    <div class="card-body">
                        <div class="table-responsive">
                            <table id="doctorNotesTable" class="table table-bordered table-striped text-center align-middle">
                                <thead class="table-light">
                                    <tr>
                                        <th>#</th>
                                        <th>Patient Name</th>
                                        <th>Date</th>
                                        <th>BP</th>
                                        <th>Temp</th>
                                        <th>SpO₂</th>
                                        <th>Notes</th>
                                        <th>Document</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $doctorNotes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $note): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr id="row-<?php echo e($note->id); ?>">
                                        <td><?php echo e($index + 1); ?></td>
                                        <td><?php echo e($note->patient_name); ?></td>
                                        <td><?php echo e(\Carbon\Carbon::parse($note->note_date)->format('d-m-Y')); ?></td>
                                        <td><?php echo e($note->bp); ?></td>
                                        <td><?php echo e($note->temp); ?></td>
                                        <td><?php echo e($note->spo2); ?></td>
                                        <td><?php echo e(\Illuminate\Support\Str::limit($note->notes, 30)); ?></td>

                                        <!-- Document View -->
                                        <td>
                                            <?php if($note->document): ?>
                                                <?php
                                                    $ext = pathinfo($note->document, PATHINFO_EXTENSION);
                                                ?>
                                                <?php if(in_array($ext, ['jpg','jpeg','png'])): ?>
                                                    <a href="<?php echo e(asset($note->document)); ?>" target="_blank">
                                                        <img src="<?php echo e(asset($note->document)); ?>" alt="doc" width="40" height="40" class="rounded border">
                                                    </a>
                                                <?php elseif($ext === 'pdf'): ?>
                                                    <a href="<?php echo e(asset($note->document)); ?>" target="_blank" class="btn btn-sm btn-outline-danger">
                                                        <i class="fa-solid fa-file-pdf"></i> View PDF
                                                    </a>
                                                <?php else: ?>
                                                    <a href="<?php echo e(asset($note->document)); ?>" target="_blank" class="btn btn-sm btn-outline-secondary">
                                                        <i class="fa-solid fa-file"></i> View File
                                                    </a>
                                                <?php endif; ?>
                                            <?php else: ?>
                                                <span class="text-muted">No File</span>
                                            <?php endif; ?>
                                        </td>

                                        <!-- Actions -->
                                        <td class="d-flex justify-content-center gap-1">
                                            <!-- View Modal Trigger -->
                                            <button type="button" class="btn btn-sm btn-info view-note-btn"
                                                data-note='<?php echo json_encode($note, 15, 512) ?>'>
                                                <i class="fa-solid fa-eye"></i> View
                                            </button>

                                            <a href="<?php echo e(route('doctornotes.edit', $note->id)); ?>" class="btn btn-sm btn-primary">
                                                <i class="fa-solid fa-pen-to-square"></i> Edit
                                            </a>

                                            <form action="<?php echo e(route('doctornotes.destroy', $note->id)); ?>" method="POST" style="display:inline;">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-sm btn-danger"
                                                    onclick="return confirm('Are you sure you want to delete this note?')">
                                                    <i class="fa-solid fa-trash"></i> Delete
                                                </button>
                                            </form>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>

<!-- Modal -->
<div class="modal fade" id="viewNoteModal" tabindex="-1" aria-labelledby="viewNoteModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content border-0 shadow-lg rounded-4">
            <div class="modal-header bg-gradient text-white">
                <h5 class="modal-title fw-bold" id="viewNoteModalLabel">Doctor Note Details</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body px-4 py-3">
                <div id="modalContent">
                    <!-- Dynamically filled -->
                </div>
            </div>
        </div>
    </div>
</div>

<!-- JS -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.datatables.net/1.13.7/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.7/js/dataTables.bootstrap5.min.js"></script>
<link rel="stylesheet" href="https://cdn.datatables.net/1.13.7/css/dataTables.bootstrap5.min.css">

<script>
$(document).ready(function() {
    $('#doctorNotesTable').DataTable({
        pageLength: 10,
        lengthMenu: [5, 10, 25, 50, 100],
        order: [[0, 'asc']],
        columnDefs: [{ orderable: false, targets: [8] }],
        responsive: true
    });

    // View Modal
    $(document).on('click', '.view-note-btn', function() {
        const note = $(this).data('note');
        let docHtml = '';

        if (note.document) {
            const ext = note.document.split('.').pop().toLowerCase();
            const fileUrl = "<?php echo e(url('/')); ?>/" + note.document;

            if (['jpg','jpeg','png'].includes(ext)) {
                docHtml = `<img src="${fileUrl}" class="img-fluid rounded shadow-sm mt-2" alt="Document">`;
            } else if (ext === 'pdf') {
                docHtml = `<iframe src="${fileUrl}" width="100%" height="400" class="border rounded mt-2"></iframe>`;
            } else {
                docHtml = `<a href="${fileUrl}" target="_blank" class="btn btn-outline-secondary mt-2">
                              <i class="fa-solid fa-file"></i> View Document
                           </a>`;
            }
        } else {
            docHtml = `<p class="text-muted mt-2">No document attached.</p>`;
        }

        $('#modalContent').html(`
            <div class="row mb-3">
                <div class="col-md-6"><strong>Patient:</strong> ${note.patient_name}</div>
                <div class="col-md-6"><strong>Date:</strong> ${note.note_date}</div>
                <div class="col-md-4"><strong>Height:</strong> ${note.height ?? '-'}</div>
                <div class="col-md-4"><strong>Weight:</strong> ${note.weight ?? '-'}</div>
                <div class="col-md-4"><strong>BP:</strong> ${note.bp ?? '-'}</div>
                <div class="col-md-4"><strong>PR:</strong> ${note.pr ?? '-'}</div>
                <div class="col-md-4"><strong>Temp:</strong> ${note.temp ?? '-'}</div>
                <div class="col-md-4"><strong>SpO₂:</strong> ${note.spo2 ?? '-'}</div>
            </div>
            <hr>
            <h6 class="fw-bold text-primary">Notes:</h6>
            <p>${note.notes ?? '-'}</p>
            <h6 class="fw-bold text-primary mt-3">Attached Document:</h6>
            ${docHtml}
        `);

        $('#viewNoteModal').modal('show');
    });
});
</script>

<style>
.bg-gradient {
    background: linear-gradient(90deg, #4e73df, #1cc88a);
}
.btn-outline-primary.btn-sm {
    font-size: 0.85rem;
}
.modal-content {
    border-radius: 1rem;
    overflow: hidden;
}
</style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/hmssocie/public_html/iyengaran.hms-society.com/resources/views/doctornotes/index.blade.php ENDPATH**/ ?>